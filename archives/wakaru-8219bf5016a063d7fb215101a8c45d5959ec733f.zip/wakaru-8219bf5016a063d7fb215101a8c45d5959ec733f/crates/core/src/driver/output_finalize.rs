use swc_core::ecma::ast::{
    Expr, Lit, MetaPropExpr, MetaPropKind, Module, ModuleDecl, ModuleItem, Stmt,
};
use swc_core::ecma::visit::{Visit, VisitWith};

use crate::output_validate::{filename_source_goal, SourceGoal};

/// Remove an otherwise empty top-level `"use strict"` body, or remove top-level
/// `"use strict"` expressions when the final output has a trusted Module goal.
/// Function-level directives are intentionally outside this finalization pass
/// and remain available to every rewrite rule.
pub(super) fn strip_redundant_module_use_strict(
    module: &mut Module,
    filename: &str,
    bare_imports_are_stable: bool,
) {
    if !module.body.is_empty() && module.body.iter().all(is_use_strict_item) {
        module.body.clear();
        return;
    }

    if !is_definitely_module(module, filename, bare_imports_are_stable) {
        return;
    }

    module.body.retain(|item| !is_use_strict_item(item));
}

fn is_use_strict_item(item: &ModuleItem) -> bool {
    matches!(
        item,
        ModuleItem::Stmt(Stmt::Expr(statement))
            if matches!(
                statement.expr.as_ref(),
                Expr::Lit(Lit::Str(value))
                    if value.value.as_str() == Some("use strict")
            )
    )
}

fn is_definitely_module(module: &Module, filename: &str, bare_imports_are_stable: bool) -> bool {
    match filename_source_goal(filename) {
        // An explicit script extension conflicts with module-only AST syntax.
        // Preserve source rather than guessing which signal the caller meant.
        SourceGoal::Script => return false,
        SourceGoal::Module => return true,
        SourceGoal::Ambiguous => {}
    }

    if module.body.iter().any(|item| match item {
        ModuleItem::ModuleDecl(ModuleDecl::Import(import)) => {
            bare_imports_are_stable || !import.specifiers.is_empty()
        }
        ModuleItem::ModuleDecl(_) => true,
        ModuleItem::Stmt(_) => false,
    }) {
        return true;
    }

    let mut finder = ImportMetaFinder::default();
    module.visit_with(&mut finder);
    finder.found
}

#[derive(Default)]
struct ImportMetaFinder {
    found: bool,
}

impl Visit for ImportMetaFinder {
    fn visit_meta_prop_expr(&mut self, expression: &MetaPropExpr) {
        if expression.kind == MetaPropKind::ImportMeta {
            self.found = true;
        }
    }
}
