//! Two-phase multi-module pipeline: fact collection (Phase 1) and output
//! decompilation with the cross-module late pass (Phase 2).

use std::sync::Arc;

use anyhow::{bail, Result};
use swc_core::common::{sync::Lrc, Globals, Mark, SourceMap, SyntaxContext, DUMMY_SP, GLOBALS};
use swc_core::ecma::ast::{
    AssignExpr, AssignOp, AssignTarget, Expr, ExprStmt, Ident, IdentName, MemberExpr, MemberProp,
    Module, ModuleDecl, ModuleItem, ObjectLit, SimpleAssignTarget, Stmt,
};
use swc_core::ecma::transforms::base::resolver;
use swc_core::ecma::visit::{Visit, VisitMutWith, VisitWith};

use super::super::diagnostics::{
    collect_commonjs_export_residual_warnings, collect_input_parse_warnings,
    collect_output_diagnostics,
};
use super::super::io::{
    apply_fixer, build_output_sourcemap, parse_js, parse_js_with_recovery, print_js,
    print_js_with_srcmap, ParseDiagnostic,
};
use super::super::output_finalize::strip_redundant_module_use_strict;
use super::super::types::{
    DecompileOptions, PreparedInputId, PreparedModuleOutput, PreparedModuleProvenance,
    PreparedUnpackOutput, UnpackWarning, UnpackWarningKind,
};
use super::super::unpack_cycles::collect_import_cycle_warnings;
use super::dead_module::{collect_import_report, eliminate_dead_helper_modules, ImportReport};
use super::filename_recovery::{
    build_rename_map, harvest_suggested_filename, rewrite_import_sources,
};
use super::merge::{
    apply_filename_rewrites, apply_numeric_rewrites, NumericRewritePlan, PreparedUnpackModule,
};
use super::schedule::par_map_largest_first;
use super::source_index::{build_composed_output_sourcemap, InputOrigin};
use super::webpack_commonjs_runtime::normalize_webpack_commonjs_runtime;
use super::{recover_late_esm_from_factory_iifes, LateEsmRecoveryOptions};
use crate::commonjs_default_object_composition::{
    run_commonjs_default_object_composition, CommonJsDefaultObjectCompositionPlan,
};
use crate::facts::{
    collect_commonjs_default_attached_properties, collect_commonjs_default_object,
    collect_marks_es_module, collect_module_facts, collect_require_returns_exports_object,
    collect_whole_require_sources, collect_wildcard_require_sources, ModuleFactsMap,
};
use crate::namespace_decomposition::run_namespace_decomposition;
use crate::provider_import_repair::run_provider_import_repair;
use crate::provider_namespace_repair::run_provider_namespace_repair;
use crate::reexport_consolidation::run_reexport_consolidation;
use crate::rules::cross_module_interop_import::run_cross_module_interop_imports;
use crate::rules::eval_utils::DirectEvalAnalyzer;
use crate::rules::expr_utils::is_unresolved_ident;
use crate::rules::lowered_dynamic_import::run_cross_module_lowered_dynamic_imports;
use crate::rules::{
    apply_rules, apply_rules_to_recovered_module, contains_local_self_require, ImportDedup,
    RewriteLevel, RulePipelineOptions, SimplifySequence, UnAssignmentMerging, UnConditionals,
    UnConditionalsAssignmentOnly, UnImportRename, UnOptionalChaining,
};
use crate::sourcemap_rename::{apply_sourcemap_renames, parse_sourcemap};
use crate::synthetic_import_cleanup::downgrade_unused_synthetic_imports;
use crate::unpacker::{
    arrow_iife_call, module_stmts_have_function_level_special_bindings,
    stmts_have_function_level_return, stmts_have_function_level_special_bindings,
    DetectedModuleFailure, DetectedModuleNote, InputOffsets, TurbopackContextUse,
};

#[derive(Debug, PartialEq, Eq)]
enum BoundaryRestoration {
    /// Restoration was disabled or the module has no function-level return
    /// at module scope; the module is already valid ESM at this boundary.
    NotNeeded,
    /// The lifted statements were wrapped back into a callable boundary.
    Restored,
    /// A function-level return remains at module scope but the module cannot
    /// be wrapped (recovered exports would move outside the guarded flow).
    /// Emitting this module as ESM would not parse.
    Declined,
}

fn restore_lifted_function_boundary(module: &mut Module, enabled: bool) -> BoundaryRestoration {
    if !enabled {
        return BoundaryRestoration::NotNeeded;
    }
    let statements = module
        .body
        .iter()
        .filter_map(|item| match item {
            ModuleItem::Stmt(statement) => Some(statement.clone()),
            ModuleItem::ModuleDecl(_) => None,
        })
        .collect::<Vec<_>>();
    if !stmts_have_function_level_return(&statements) {
        return BoundaryRestoration::NotNeeded;
    }
    if module.body.iter().any(|item| {
        matches!(
            item,
            ModuleItem::ModuleDecl(decl) if !matches!(decl, ModuleDecl::Import(_))
        )
    }) {
        return BoundaryRestoration::Declined;
    }
    // The restored arrow boundary inherits module-scope `this` (undefined),
    // has no `arguments`, and cannot provide a valid `new.target`. A lifted
    // body observing any of them would break at parse time or runtime. Fail
    // closed to the extracted-source fallback instead.
    if stmts_have_function_level_special_bindings(&statements) {
        return BoundaryRestoration::Declined;
    }

    let mut restored = std::mem::take(&mut module.body)
        .into_iter()
        .filter(|item| matches!(item, ModuleItem::ModuleDecl(ModuleDecl::Import(_))))
        .collect::<Vec<_>>();
    restored.push(ModuleItem::Stmt(Stmt::Expr(ExprStmt {
        span: DUMMY_SP,
        expr: Box::new(arrow_iife_call(statements)),
    })));
    module.body = restored;
    BoundaryRestoration::Restored
}

fn detector_failure_warning(filename: &str, failure: DetectedModuleFailure) -> UnpackWarning {
    match failure {
        DetectedModuleFailure::WebpackRuntimeParameterReuse => UnpackWarning::new(
            filename,
            UnpackWarningKind::WebpackFactoryRecoveryFailed,
            "webpack factory runtime-parameter reuse could not be normalized; preserving the opaque factory body",
        ),
        DetectedModuleFailure::WebpackFreeNameCapture => UnpackWarning::new(
            filename,
            UnpackWarningKind::WebpackFactoryRecoveryFailed,
            "webpack factory could not take the `module`/`exports`/`require` parameter names without capturing a free reference; preserving the opaque factory body",
        ),
        DetectedModuleFailure::TranslatedFactoryNormalization => UnpackWarning::new(
            filename,
            UnpackWarningKind::WebpackFactoryRecoveryFailed,
            "translated factory could not be normalized; preserving the opaque factory body",
        ),
        DetectedModuleFailure::TurbopackUnsupportedRuntime(context_use) => UnpackWarning::new(
            filename,
            UnpackWarningKind::DecompileFailed,
            match context_use {
                TurbopackContextUse::Member(member) => format!(
                    "Turbopack factory uses runtime context member `{member}` without a known translation; preserving the opaque factory body"
                ),
                TurbopackContextUse::Dirname => "Turbopack factory reads its `__dirname` context binding; preserving the opaque factory body".to_string(),
                TurbopackContextUse::Other => "Turbopack factory uses its runtime context without a known translation; preserving the opaque factory body".to_string(),
            },
        ),
    }
}

fn detector_note_warning(filename: &str, note: DetectedModuleNote) -> UnpackWarning {
    match note {
        DetectedModuleNote::TurbopackRuntimeResidual(letter) => UnpackWarning::new(
            filename,
            UnpackWarningKind::RuntimeResidual,
            format!(
                "Turbopack runtime member `{letter}` is kept as a call through `__turbopack_context__`, which the split output does not define"
            ),
        ),
    }
}

struct Phase1PreparedModule {
    globals: Globals,
    module: Module,
    unresolved_mark: Mark,
}

struct Phase1Module {
    filename: String,
    facts: crate::facts::ModuleFacts,
    prepared: Option<Phase1PreparedModule>,
    warning: Option<UnpackWarning>,
    input_parse_warnings: Vec<UnpackWarning>,
    /// Original source filename recovered from provenance markers (Sentry
    /// `data-sentry-source-file`), if any. Used at the barrier to rename the
    /// module's output file and rewrite importers' references.
    suggested_filename: Option<String>,
}

/// Restore the default object that webpack creates before invoking a CommonJS
/// factory. Empty factories carry this detector fact directly. A non-empty
/// self-requiring factory may use the same fact only when its complete body
/// cannot observe the original wrapper-created object through a runtime alias.
/// Raw output never calls this normal-pipeline helper.
fn restore_webpack_factory_default(
    module: &mut Module,
    unresolved_mark: Mark,
    implicit_empty_default: bool,
    webpack_commonjs_runtime: bool,
    current_filename: &str,
) {
    let restore_empty = implicit_empty_default && module.body.is_empty();
    let restore_self_required = webpack_commonjs_runtime
        && !module.body.is_empty()
        && !module
            .body
            .iter()
            .any(|item| matches!(item, ModuleItem::ModuleDecl(_)))
        && contains_local_self_require(module, unresolved_mark, Some(current_filename))
        && !observes_webpack_factory_environment(module, unresolved_mark);
    if !restore_empty && !restore_self_required {
        return;
    }

    let insert_at = module
        .body
        .iter()
        .take_while(|item| is_directive_prologue_item(item))
        .count();
    let module_ident = Ident::new(
        "module".into(),
        DUMMY_SP,
        SyntaxContext::empty().apply_mark(unresolved_mark),
    );
    module.body.insert(
        insert_at,
        ModuleItem::Stmt(Stmt::Expr(ExprStmt {
            span: DUMMY_SP,
            expr: Box::new(Expr::Assign(AssignExpr {
                span: DUMMY_SP,
                op: AssignOp::Assign,
                left: AssignTarget::Simple(SimpleAssignTarget::Member(MemberExpr {
                    span: DUMMY_SP,
                    obj: Box::new(Expr::Ident(module_ident)),
                    prop: MemberProp::Ident(IdentName::new("exports".into(), DUMMY_SP)),
                })),
                right: Box::new(Expr::Object(ObjectLit {
                    span: DUMMY_SP,
                    props: Vec::new(),
                })),
            })),
        })),
    );
}

fn is_directive_prologue_item(item: &ModuleItem) -> bool {
    matches!(item, ModuleItem::Stmt(Stmt::Expr(statement))
        if matches!(statement.expr.as_ref(), Expr::Lit(swc_core::ecma::ast::Lit::Str(_))))
}

/// Replacing webpack's initial exports object at the first executable
/// statement is unobservable unless the factory body retained an alias to the
/// original object. Reject every explicit wrapper binding and the dynamic
/// mechanisms that can recover one.
fn observes_webpack_factory_environment(module: &Module, unresolved_mark: Mark) -> bool {
    let mut observer = WebpackFactoryEnvironmentObserver {
        unresolved_mark,
        observed: false,
    };
    module.visit_with(&mut observer);
    if observer.observed {
        return true;
    }
    if module_stmts_have_function_level_special_bindings(module) {
        return true;
    }

    let mut eval = DirectEvalAnalyzer::default();
    module.visit_with(&mut eval);
    eval.unknown_direct_eval || !eval.known_direct_eval_sources.is_empty()
}

struct WebpackFactoryEnvironmentObserver {
    unresolved_mark: Mark,
    observed: bool,
}

impl Visit for WebpackFactoryEnvironmentObserver {
    fn visit_ident(&mut self, ident: &Ident) {
        if is_unresolved_ident(ident, "module", self.unresolved_mark)
            || is_unresolved_ident(ident, "exports", self.unresolved_mark)
        {
            self.observed = true;
        }
    }
}

/// Multi-module unpack with cross-module late pass.
///
/// Phase 1: obtain a resolved AST + through-UnEsm range + fact recovery/collection
/// Phase 2: resume the retained AST + late pass + UnTemplateLiteral-through-UnReturn range
///
/// Normal unpack retains each Phase 1 AST together with its `Globals` and
/// unresolved mark across the facts barrier. Webpack5 detectors can provide an
/// already-resolved, bundler-normalized AST, avoiding their intermediate emit
/// and this phase's parse/resolver. Source-map mode deliberately materializes
/// detector ASTs and uses the parser path so output mappings keep parser-owned
/// source coordinates.
///
/// # Best-effort semantics
///
/// Individual extracted modules that fail to parse are preserved as raw code
/// rather than aborting the entire unpack. The extraction process can
/// produce module bodies that are not valid standalone JS (e.g. incomplete
/// slicing, runtime wrapper residue). Hard-failing on those would discard
/// all other successfully extracted modules, which is worse for both
/// interactive and automated users. Failures are reported via
/// `PreparedUnpackOutput::warnings` so callers can surface them without silent
/// swallowing.
///
/// Both phases run via rayon. On targets without threading support, Rayon falls
/// back to sequential execution.
#[cfg(test)]
pub(super) fn unpack_multi_module(
    modules: Vec<crate::unpacker::UnpackedModule>,
    options: DecompileOptions,
) -> Result<PreparedUnpackOutput> {
    let modules = modules
        .into_iter()
        .map(PreparedUnpackModule::plain)
        .collect();
    unpack_multi_module_with_plan(modules, NumericRewritePlan::default(), options, &[])
}

pub(super) fn unpack_multi_module_with_plan(
    mut modules: Vec<PreparedUnpackModule>,
    numeric_rewrite_plan: NumericRewritePlan,
    options: DecompileOptions,
    origins: &[Option<Arc<InputOrigin>>],
) -> Result<PreparedUnpackOutput> {
    if options.sourcemap.is_some() {
        bail!(
            "input source maps are not supported with unpacking because extracted module coordinates differ from bundle coordinates; use --emit-source-map for output maps"
        );
    }
    let span = tracing::info_span!("unpack_multi_module", count = modules.len());
    let _enter = span.enter();
    let report_import_cycle_warnings = modules
        .iter()
        .all(|module| module.report_import_cycle_warnings);
    let reserved_public_paths = modules
        .iter()
        .filter(|module| module.reserved_public_path)
        .map(|module| module.module.filename.clone())
        .collect::<crate::collections::HashSet<_>>();

    // Stash per-module provenance (byte ranges into the original input)
    // keyed by provisional filename. Final provenance is built after dead
    // module elimination and filename recovery, so only surviving modules
    // appear with their final names.
    let provenance_by_provisional: crate::collections::HashMap<
        String,
        (
            Option<PreparedInputId>,
            Vec<(u32, u32)>,
            Vec<(u32, u32)>,
            bool,
        ),
    > = modules
        .iter()
        .map(|prepared| {
            (
                prepared.module.filename.clone(),
                (
                    prepared.input,
                    prepared.module.source_ranges.clone(),
                    prepared.module.inspection_context_ranges.clone(),
                    prepared.module.is_entry,
                ),
            )
        })
        .collect();

    // Parse the sourcemap once before the loop.
    let parsed_sourcemap = options
        .sourcemap
        .as_deref()
        .map(parse_sourcemap)
        .transpose()?;
    let can_reuse_phase1_ast = parsed_sourcemap.is_none() && !options.emit_source_map;
    // Filename recovery from provenance markers is a readability rewrite, gated
    // to standard+ like other speculative recovery.
    let recover_filenames = !matches!(options.level, RewriteLevel::Minimal);
    // Dead helper-module elimination is dead-code cleanup: it relies on the
    // binding->side-effect import downgrade that only runs when DCE is on, and
    // dropping a module is structural, so gate it to standard+ as well.
    let eliminate_dead_modules =
        options.dce_mode.is_enabled() && !matches!(options.level, RewriteLevel::Minimal);

    // Phase 1: collect facts. Run the through-UnEsm normalization range on each
    // module and extract import/export facts. For normal unpacking, keep that
    // normalized AST so Phase 2 can resume after the facts barrier. Source-map
    // mode still reparses in Phase 2 because sourcemap renaming depends on the
    // original parser SourceMap.
    let collect_facts = |unpacked: &mut PreparedUnpackModule| -> Phase1Module {
        if let Some(failure) = unpacked.detector_failure {
            // The factory loader's later lifetime is unproven. Running any
            // require-aware transform or fact collector over this body could
            // turn an ordinary local call into a fabricated module edge.
            unpacked.prepared = None;
            return Phase1Module {
                filename: unpacked.module.filename.clone(),
                facts: crate::facts::ModuleFacts::default(),
                prepared: None,
                warning: Some(detector_failure_warning(&unpacked.module.filename, failure)),
                input_parse_warnings: Vec::new(),
                suggested_filename: None,
            };
        }
        let (globals, prepared_input, input_parse_warnings) = match unpacked.prepared.take() {
            Some(prepared) => {
                let filename = unpacked.module.filename.clone();
                let errors = prepared
                    .recoverable_parse_errors
                    .into_iter()
                    .map(|error| ParseDiagnostic {
                        filename: filename.clone(),
                        line: error.line,
                        column: error.column,
                        message: error.message,
                    })
                    .collect::<Vec<_>>();
                let warnings = collect_input_parse_warnings(&errors);
                (
                    prepared.globals,
                    Some((prepared.module, prepared.unresolved_mark)),
                    warnings,
                )
            }
            None => (Globals::new(), None, Vec::new()),
        };
        let (facts, prepared_parts, warning, suggested_filename) =
            GLOBALS.set(&globals, || {
            let (mut module, unresolved_mark) = match prepared_input {
                Some((mut module, _detector_mark)) => {
                    // The detector's contexts describe its own surgery; give
                    // the rules resolver-derived ones.
                    let span = tracing::info_span!("phase1: reresolve prepared");
                    let _enter = span.enter();
                    let unresolved_mark = crate::unpacker::resolve_prepared_module(&mut module);
                    (module, unresolved_mark)
                }
                None => {
                    let cm: Lrc<SourceMap> = Default::default();
                    let mut module = {
                        let span = tracing::info_span!("phase1: parse");
                        let _enter = span.enter();
                        match parse_js(
                            &unpacked.module.code,
                            &unpacked.module.filename,
                            cm.clone(),
                        ) {
                            Ok(module) => module,
                            Err(e) => {
                                return (
                                    crate::facts::ModuleFacts::default(),
                                    None,
                                    Some(UnpackWarning::new(
                                        unpacked.module.filename.clone(),
                                        UnpackWarningKind::FactCollectionParseFailed,
                                        format!(
                                            "parse failed during fact collection, using empty facts: {e}"
                                        ),
                                    )),
                                    None,
                                );
                            }
                        }
                    };
                    let unresolved_mark = {
                        let span = tracing::info_span!("phase1: resolver");
                        let _enter = span.enter();
                        let unresolved_mark = Mark::new();
                        let top_level_mark = Mark::new();
                        module.visit_mut_with(&mut resolver(
                            unresolved_mark,
                            top_level_mark,
                            false,
                        ));
                        unresolved_mark
                    };
                    (module, unresolved_mark)
                }
            };
            // Harvest the original filename from provenance markers before any
            // rule mutates the AST. The marker is still a props-object property
            // here (UnJsx has not run), so this does not depend on JSX recovery.
            let suggested_filename = if recover_filenames {
                harvest_suggested_filename(&module)
            } else {
                None
            };
            apply_filename_rewrites(
                &mut module,
                unresolved_mark,
                unpacked.filename_rewrite.as_ref(),
            );
            apply_numeric_rewrites(
                &mut module,
                unresolved_mark,
                unpacked.numeric_rewrite.as_ref(),
                &numeric_rewrite_plan,
            );
            normalize_webpack_commonjs_runtime(
                &mut module,
                unresolved_mark,
                unpacked.webpack_commonjs_runtime,
                unpacked.webpack_numeric_module_id,
                unpacked.webpack_legacy_module_i,
            );
            restore_webpack_factory_default(
                &mut module,
                unresolved_mark,
                unpacked.implicit_commonjs_default_object,
                unpacked.webpack_commonjs_runtime,
                &unpacked.module.filename,
            );
            let commonjs_default_object =
                collect_commonjs_default_object(&module, unresolved_mark);
            let commonjs_default_attached_properties =
                collect_commonjs_default_attached_properties(&module, unresolved_mark);
            let require_returns_exports_object =
                collect_require_returns_exports_object(&module, unresolved_mark);
            let whole_require_sources = collect_whole_require_sources(&module, unresolved_mark);
            let marks_es_module = collect_marks_es_module(&module, unresolved_mark);
            let wildcard_require_sources =
                collect_wildcard_require_sources(&module, unresolved_mark);
            {
                let span = tracing::info_span!("phase1: rules");
                let _enter = span.enter();
                apply_rules(
                    &mut module,
                    unresolved_mark,
                    RulePipelineOptions::until("UnEsm")
                        .with_current_filename(&unpacked.module.filename),
                );
            }
            // ESM recovery mutates the AST heavily (UnIife, factory-IIFE
            // rewrites, renames) to expose import/export declarations that
            // `collect_module_facts` reads. Phase 2 resumes from the
            // *pre-recovery* through-UnEsm barrier state and runs its own
            // recovery later at `options.level`, so it needs the unmodified
            // `module`. When the AST will be reused (no-sourcemap path), clone
            // before recovering for facts. When it won't be reused (sourcemap
            // path discards `module`), recover in place and skip the clone.
            let (mut facts, prepared) = if can_reuse_phase1_ast {
                let mut facts_module = module.clone();
                {
                    let span = tracing::info_span!("phase1: fact recovery");
                    let _enter = span.enter();
                    recover_late_esm_from_factory_iifes(
                        &mut facts_module,
                        unresolved_mark,
                        RewriteLevel::Standard,
                        &unpacked.module.filename,
                        LateEsmRecoveryOptions::default(),
                    );
                }
                let mut facts = collect_module_facts(&facts_module);
                // Class recovery runs on this pre-late AST. Probing the
                // late-renamed clone misses IIFEs Phase 2 still converts.
                facts.import_call_edges = crate::rules::collect_import_call_edges(
                    &module,
                    unresolved_mark,
                    options.level,
                );
                (facts, Some((module, unresolved_mark)))
            } else {
                // Edges read the pre-late AST, as above. Collect them before
                // recovering in place so this path still skips the clone.
                let import_call_edges = crate::rules::collect_import_call_edges(
                    &module,
                    unresolved_mark,
                    options.level,
                );
                {
                    let span = tracing::info_span!("phase1: fact recovery");
                    let _enter = span.enter();
                    recover_late_esm_from_factory_iifes(
                        &mut module,
                        unresolved_mark,
                        RewriteLevel::Standard,
                        &unpacked.module.filename,
                        LateEsmRecoveryOptions::default(),
                    );
                }
                let mut facts = collect_module_facts(&module);
                facts.import_call_edges = import_call_edges;
                (facts, None)
            };
            facts.commonjs_default_object = commonjs_default_object;
            facts.commonjs_default_attached_properties =
                commonjs_default_attached_properties;
            facts.require_returns_exports_object = require_returns_exports_object;
            facts.whole_require_sources = whole_require_sources;
            facts.marks_es_module = marks_es_module;
            facts.wildcard_require_sources = wildcard_require_sources;
            (facts, prepared, None, suggested_filename)
        });
        let prepared = prepared_parts.map(|(module, unresolved_mark)| Phase1PreparedModule {
            globals,
            module,
            unresolved_mark,
        });
        Phase1Module {
            filename: unpacked.module.filename.clone(),
            facts,
            prepared,
            warning,
            input_parse_warnings,
            suggested_filename,
        }
    };

    let phase1: Vec<_> = {
        let span = tracing::info_span!("phase1_collect_facts");
        let _enter = span.enter();
        par_map_largest_first(
            modules.iter_mut().collect(),
            |module: &&mut PreparedUnpackModule| module.module.code.len(),
            collect_facts,
        )
    };

    let mut module_facts = ModuleFactsMap::new();
    let mut prepared_modules = Vec::with_capacity(phase1.len());
    let mut prepared_parse_warnings = Vec::with_capacity(phase1.len());
    let mut warnings = Vec::new();
    let mut rename_entries = Vec::with_capacity(phase1.len());
    for phase1_module in phase1 {
        rename_entries.push((
            phase1_module.filename.clone(),
            phase1_module.suggested_filename,
        ));
        module_facts.insert(&phase1_module.filename, phase1_module.facts);
        prepared_modules.push(phase1_module.prepared);
        prepared_parse_warnings.push(phase1_module.input_parse_warnings);
        if let Some(w) = phase1_module.warning {
            warnings.push(w);
        }
    }

    let commonjs_default_object_composition_plan =
        CommonJsDefaultObjectCompositionPlan::build(&module_facts);
    let call_required_plan = crate::rules::CallRequiredPlan::build(&module_facts);

    // Cross-module barrier: resolve recovered filenames into a final rename
    // table. Kept separate from the fact map so the pipeline (facts, numeric
    // rewrites, namespace decomposition) keeps operating on provisional names;
    // only the final emit step swaps names and rewrites import sources.
    let rename_map = if recover_filenames {
        build_rename_map(&rename_entries, &reserved_public_paths)
    } else {
        crate::collections::HashMap::default()
    };

    // Phase 2: output pipeline with late pass. Each module is parsed from
    // the original source only when Phase 1 failed to prepare an AST; otherwise
    // it continues from the Phase 1 normalized AST after the facts barrier.
    let facts_ref = &module_facts;
    let composition_plan_ref = &commonjs_default_object_composition_plan;
    let call_required_plan_ref = &call_required_plan;
    let sm_ref = &parsed_sourcemap;
    let rename_ref = &rename_map;
    let phase2_inputs: Vec<_> = modules
        .into_iter()
        .zip(prepared_modules)
        .zip(prepared_parse_warnings)
        .map(|((module, prepared), warnings)| (module, prepared, warnings))
        .collect();

    let decompile_module = |(unpacked, prepared, prepared_parse_warnings): (
        PreparedUnpackModule,
        Option<Phase1PreparedModule>,
        Vec<UnpackWarning>,
    )|
     -> (
        String,
        String,
        Vec<UnpackWarning>,
        Option<ImportReport>,
        Option<String>,
    ) {
        if unpacked.detector_failure.is_some() {
            return (
                unpacked.module.filename,
                unpacked.module.code,
                Vec::new(),
                None,
                None,
            );
        }
        let run_phase2_tail = |mut module: Module,
                               cm: Lrc<SourceMap>,
                               unresolved_mark: Mark,
                               input_parse_warnings: Vec<UnpackWarning>|
         -> Result<(
            String,
            Option<String>,
            Vec<UnpackWarning>,
            Option<ImportReport>,
        )> {
            let rules_span = tracing::info_span!("phase2: rules");
            let rules_enter = rules_span.enter();
            // Late pass at the barrier
            run_commonjs_default_object_composition(
                &mut module,
                composition_plan_ref,
                Some(&unpacked.module.filename),
                unresolved_mark,
            );
            run_provider_import_repair(&mut module, facts_ref, Some(&unpacked.module.filename));
            run_provider_namespace_repair(
                &mut module,
                facts_ref,
                Some(&unpacked.module.filename),
                unresolved_mark,
                true,
            );
            run_reexport_consolidation(&mut module, facts_ref, Some(&unpacked.module.filename));
            run_cross_module_lowered_dynamic_imports(
                &mut module,
                facts_ref,
                Some(&unpacked.module.filename),
                unresolved_mark,
            );
            run_cross_module_interop_imports(
                &mut module,
                facts_ref,
                Some(&unpacked.module.filename),
                unresolved_mark,
            );
            run_namespace_decomposition(
                &mut module,
                facts_ref,
                Some(&unpacked.module.filename),
                unresolved_mark,
            );
            downgrade_unused_synthetic_imports(&mut module);
            // Late helper-through-UnReturn range.
            apply_rules_to_recovered_module(
                &mut module,
                unresolved_mark,
                RulePipelineOptions::between("UnObjectSpread2", "UnReturn")
                    .with_dce_mode(options.dce_mode)
                    .with_rewrite_level(options.level)
                    .with_module_facts(facts_ref)
                    .with_current_filename(&unpacked.module.filename)
                    .with_call_required_plan(call_required_plan_ref),
            );
            // Later rules can expose sequence expressions. The old unpack
            // path cleaned those by running a second full module pipeline;
            // keep only the syntax cleanup needed after the split.
            module.visit_mut_with(&mut SimplifySequence::new_with_level(
                unresolved_mark,
                options.level,
            ));
            module.visit_mut_with(&mut UnAssignmentMerging::new(unresolved_mark));
            // UnIife2 can expose webpack export helpers that were hidden in
            // factory wrappers at the Stage 2 barrier. Recover just that ESM
            // shape without restoring the old full second pass.
            recover_late_esm_from_factory_iifes(
                &mut module,
                unresolved_mark,
                options.level,
                &unpacked.module.filename,
                LateEsmRecoveryOptions::default(),
            );
            module.visit_mut_with(&mut UnOptionalChaining::new(unresolved_mark, options.level));
            module.visit_mut_with(&mut UnConditionalsAssignmentOnly);
            // Unpack counterpart of the pipeline's UnConditionals2 cleanup pass.
            module.visit_mut_with(&mut UnConditionals::with_nested_actions());

            // Source-map-enhanced passes
            if let Some(sm) = sm_ref {
                module.visit_mut_with(&mut ImportDedup);
                apply_sourcemap_renames(&mut module, sm, &cm, unresolved_mark);
                module.visit_mut_with(&mut UnImportRename::new(unresolved_mark));
            }

            // A module that still carries a function-level return at module
            // scope after a declined restoration would not parse as ESM.
            // Preserve the extracted body and report the module as failed
            // instead of claiming a successful unpack over invalid output.
            if restore_lifted_function_boundary(
                &mut module,
                unpacked.restore_lifted_function_boundary,
            ) == BoundaryRestoration::Declined
            {
                let mut fallback_warnings = input_parse_warnings.clone();
                fallback_warnings.push(UnpackWarning::new(
                    &unpacked.module.filename,
                    UnpackWarningKind::DecompileFailed,
                    "lifted function boundary could not be restored around a module-scope return; preserving the extracted body",
                ));
                return Ok((unpacked.module.code.clone(), None, fallback_warnings, None));
            }
            drop(rules_enter);
            drop(rules_span);

            let mut diag_warnings = input_parse_warnings;
            // Import sources are still provisional here, so they resolve
            // against the same fact keys the plan was built from.
            for (source, imported) in call_required_plan_ref.mispredicted_calls(
                facts_ref,
                &unpacked.module.filename,
                &module,
            ) {
                diag_warnings.push(UnpackWarning::new(
                    &unpacked.module.filename,
                    UnpackWarningKind::CrossModuleClassCall,
                    format!(
                        "`{imported}` from `{source}` is still invoked with .call/.apply, but it was expected to become super(); the provider may now be a class that cannot be called without `new`"
                    ),
                ));
            }

            diag_warnings.extend(collect_commonjs_export_residual_warnings(
                &module,
                unresolved_mark,
                &unpacked.module.filename,
            ));

            // Final, isolated remap: rewrite import-source strings that point
            // at modules renamed via recovered filenames. Runs after every
            // fact-driven pass so the fact map stays keyed by provisional names.
            if !rename_ref.is_empty() {
                rewrite_import_sources(
                    &mut module,
                    &unpacked.module.filename,
                    rename_ref,
                    unresolved_mark,
                );
            }

            let final_filename = rename_ref
                .get(&unpacked.module.filename)
                .map(|s| s.as_str())
                .unwrap_or(&unpacked.module.filename);
            if !matches!(options.level, RewriteLevel::Minimal) {
                crate::rules::strip_redundant_sentry_source_file(&mut module, final_filename);
            }
            // Dead-helper DCE may still prune bare side-effect imports after
            // this parallel phase. Do not use such an import as the only
            // Module proof when that later mutation is enabled.
            strip_redundant_module_use_strict(&mut module, final_filename, !eliminate_dead_modules);

            // Collect the dead-module-elimination report after output
            // finalization so redundant module directives do not make an
            // otherwise pure generated helper appear side-effectful.
            let report = if eliminate_dead_modules {
                let is_helper = facts_ref
                    .get(&unpacked.module.filename)
                    .is_some_and(|facts| facts.is_helper_module);
                Some(collect_import_report(
                    &module,
                    unpacked.module.is_entry,
                    is_helper,
                    unpacked.external_consumers,
                ))
            } else {
                None
            };

            {
                let span = tracing::info_span!("phase2: fixer");
                let _enter = span.enter();
                apply_fixer(&mut module)?;
            }
            let (code, srcmap_json) = if options.emit_source_map {
                let (code, srcmap_buf) = {
                    let span = tracing::info_span!("phase2: emit");
                    let _enter = span.enter();
                    print_js_with_srcmap(&module, cm.clone())?
                };
                let origin = unpacked
                    .input
                    .and_then(|input| origins.get(input.index())?.as_deref());
                let map_json = match origin {
                    // A module without input offsets (fully synthesized) still
                    // maps into its origin: every position is left unmapped.
                    Some(origin) => build_composed_output_sourcemap(
                        &srcmap_buf,
                        &cm,
                        final_filename,
                        InputOffsets::of(&unpacked.module).unwrap_or(InputOffsets::Printed(&[])),
                        origin,
                    )?,
                    None => build_output_sourcemap(&srcmap_buf, &cm, final_filename)?,
                };
                (code, Some(map_json))
            } else {
                let code = {
                    let span = tracing::info_span!("phase2: emit");
                    let _enter = span.enter();
                    print_js(&module, cm)?
                };
                (code, None)
            };

            if options.diagnostics {
                diag_warnings.extend(collect_output_diagnostics(&code, &unpacked.module.filename));
            }

            Ok((code, srcmap_json, diag_warnings, report))
        };

        let result = if let Some(prepared) = prepared {
            let Phase1PreparedModule {
                globals,
                module,
                unresolved_mark,
            } = prepared;
            GLOBALS.set(&globals, || {
                let cm: Lrc<SourceMap> = Default::default();
                run_phase2_tail(module, cm, unresolved_mark, prepared_parse_warnings)
            })
        } else {
            GLOBALS.set(&Default::default(), || {
                let cm: Lrc<SourceMap> = Default::default();
                let parsed = {
                    let span = tracing::info_span!("phase2: parse");
                    let _enter = span.enter();
                    parse_js_with_recovery(
                        &unpacked.module.code,
                        &unpacked.module.filename,
                        cm.clone(),
                    )?
                };
                let mut module = parsed.module;
                let unresolved_mark = {
                    let span = tracing::info_span!("phase2: resolver");
                    let _enter = span.enter();
                    let unresolved_mark = Mark::new();
                    let top_level_mark = Mark::new();
                    module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));
                    unresolved_mark
                };
                apply_filename_rewrites(
                    &mut module,
                    unresolved_mark,
                    unpacked.filename_rewrite.as_ref(),
                );
                apply_numeric_rewrites(
                    &mut module,
                    unresolved_mark,
                    unpacked.numeric_rewrite.as_ref(),
                    &numeric_rewrite_plan,
                );
                normalize_webpack_commonjs_runtime(
                    &mut module,
                    unresolved_mark,
                    unpacked.webpack_commonjs_runtime,
                    unpacked.webpack_numeric_module_id,
                    unpacked.webpack_legacy_module_i,
                );
                restore_webpack_factory_default(
                    &mut module,
                    unresolved_mark,
                    unpacked.implicit_commonjs_default_object,
                    unpacked.webpack_commonjs_runtime,
                    &unpacked.module.filename,
                );

                // Through-UnEsm range.
                {
                    let span = tracing::info_span!("phase2: early rules");
                    let _enter = span.enter();
                    apply_rules(
                        &mut module,
                        unresolved_mark,
                        RulePipelineOptions::until("UnEsm")
                            .with_current_filename(&unpacked.module.filename),
                    );
                }

                let input_parse_warnings = collect_input_parse_warnings(&parsed.recoverable_errors);
                run_phase2_tail(module, cm, unresolved_mark, input_parse_warnings)
            })
        };

        match result {
            Ok((code, srcmap_json, mut diag_warnings, report)) => {
                let out_filename = rename_ref
                    .get(&unpacked.module.filename)
                    .cloned()
                    .unwrap_or(unpacked.module.filename);
                if let Some(note) = unpacked.detector_note {
                    diag_warnings.push(detector_note_warning(&out_filename, note));
                }
                (out_filename, code, diag_warnings, report, srcmap_json)
            }
            Err(e) => (
                unpacked.module.filename.clone(),
                unpacked.module.code,
                vec![UnpackWarning::new(
                    unpacked.module.filename,
                    UnpackWarningKind::DecompileFailed,
                    format!("decompile failed, preserving raw code: {e}"),
                )],
                None,
                None,
            ),
        }
    };

    let triples: Vec<_> = {
        let span = tracing::info_span!("phase2_decompile_modules");
        let _enter = span.enter();
        par_map_largest_first(
            phase2_inputs,
            |(unpacked, _, _): &(
                PreparedUnpackModule,
                Option<Phase1PreparedModule>,
                Vec<UnpackWarning>,
            )| unpacked.module.code.len(),
            decompile_module,
        )
    };

    // Separate source maps from the tuples before dead-module elimination.
    let mut srcmap_by_filename: crate::collections::HashMap<String, String> =
        crate::collections::HashMap::default();
    let triples_for_dead: Vec<(String, String, Vec<UnpackWarning>, Option<ImportReport>)> = triples
        .into_iter()
        .map(|(filename, code, warns, report, srcmap)| {
            if let Some(map_json) = srcmap {
                srcmap_by_filename.insert(filename.clone(), map_json);
            }
            (filename, code, warns, report)
        })
        .collect();

    let mut modules = Vec::with_capacity(triples_for_dead.len());
    if eliminate_dead_modules {
        let (kept, module_warnings) = eliminate_dead_helper_modules(triples_for_dead);
        modules = kept;
        warnings.extend(module_warnings);
    } else {
        for (filename, code, module_warnings, _report) in triples_for_dead {
            modules.push((filename, code));
            warnings.extend(module_warnings);
        }
    }
    if options.diagnostics && report_import_cycle_warnings {
        warnings.extend(collect_import_cycle_warnings(&modules));
    }

    // Build final provenance from the surviving output modules, mapping
    // provisional filenames to their recovered names.  Dead helper modules
    // that were eliminated above are excluded.
    let reverse_rename: crate::collections::HashMap<&str, &str> = rename_ref
        .iter()
        .map(|(prov, renamed)| (renamed.as_str(), prov.as_str()))
        .collect();
    let modules = modules
        .into_iter()
        .map(|(final_filename, code)| {
            let provisional = reverse_rename
                .get(final_filename.as_str())
                .copied()
                .unwrap_or(final_filename.as_str());
            let (input, ranges, inspection_context_ranges, is_entry) = provenance_by_provisional
                .get(provisional)
                .expect("every surviving module retains its provenance");
            let source_map = srcmap_by_filename.remove(&final_filename);
            PreparedModuleOutput {
                filename: final_filename,
                code,
                source_map,
                provenance: PreparedModuleProvenance {
                    input: *input,
                    ranges: ranges.clone(),
                    inspection_context_ranges: inspection_context_ranges.clone(),
                    is_entry: *is_entry,
                },
            }
        })
        .collect();

    Ok(PreparedUnpackOutput {
        modules,
        warnings,
        detected_formats: Vec::new(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_tracing::record_spans;
    use crate::unpacker::UnpackedModule;
    use crate::{validate_output_modules, DceMode, OutputFindingKind};

    fn validate_prepared_output(output: &PreparedUnpackOutput) -> Vec<crate::OutputFinding> {
        let modules = output
            .modules
            .iter()
            .map(|module| (module.filename.clone(), module.code.clone()))
            .collect::<Vec<_>>();
        validate_output_modules(&modules)
    }

    #[test]
    fn webpack_self_default_restoration_requires_an_unobserved_factory_object() {
        fn restore(source: &str) -> String {
            GLOBALS.set(&Default::default(), || {
                let cm: Lrc<SourceMap> = Default::default();
                let mut module = parse_js(source, "provider.js", cm.clone())
                    .expect("webpack factory fixture should parse");
                let unresolved_mark = Mark::new();
                module.visit_mut_with(&mut resolver(unresolved_mark, Mark::new(), false));
                restore_webpack_factory_default(
                    &mut module,
                    unresolved_mark,
                    false,
                    true,
                    "provider.js",
                );
                print_js(&module, cm).expect("restored fixture should print")
            })
        }

        let restored = restore(
            r#""use strict";
var current = require("./provider.js");
for (var key in current) globalThis[key] = current[key];"#,
        );
        let directive = restored
            .find("\"use strict\";")
            .expect("expected directive");
        let default = restored
            .find("module.exports = {};")
            .expect("expected detector-owned default restoration");
        let self_require = restored
            .find("require(\"./provider.js\")")
            .expect("expected self require");
        assert!(directive < default && default < self_require, "{restored}");

        for source in [
            r#"var current = require("./provider.js"); consume(module, current);"#,
            r#"var current = require("./provider.js"); consume(exports, current);"#,
            r#"var current = require("./provider.js"); consume(this, current);"#,
            r#"var current = require("./provider.js"); consume(arguments, current);"#,
            r#"var current = require("./provider.js"); eval("exports");"#,
            r#"export const marker = 1; var current = require("./provider.js");"#,
        ] {
            let output = restore(source);
            assert!(
                !output.contains("module.exports = {};"),
                "an observable factory environment must fail closed:\n{output}"
            );
        }
    }

    #[test]
    fn lifted_return_boundary_keeps_imports_at_module_scope() {
        let code = GLOBALS.set(&Default::default(), || {
            let cm: Lrc<SourceMap> = Default::default();
            let mut module = parse_js(
                r#"import { value } from "./dep.js"; if (skip) return; consume(value);"#,
                "entry.js",
                cm.clone(),
            )
            .expect("recoverable top-level return should produce an AST");
            assert_eq!(
                restore_lifted_function_boundary(&mut module, true),
                BoundaryRestoration::Restored
            );
            apply_fixer(&mut module).expect("restored module should fix");
            print_js(&module, cm).expect("restored module should print")
        });

        assert!(
            code.starts_with("import ") && code.contains("return;") && code.contains("(()=>"),
            "imports should remain outside the restored callable boundary:\n{code}"
        );
        assert_eq!(
            validate_output_modules(&[
                ("entry.js".to_string(), code),
                ("dep.js".to_string(), "export const value = 1;".to_string()),
            ]),
            vec![]
        );
    }

    #[test]
    fn lifted_return_boundary_rejects_unguarded_exports() {
        GLOBALS.set(&Default::default(), || {
            let cm: Lrc<SourceMap> = Default::default();
            let mut module = parse_js(
                "if (skip) return; export const value = initialize();",
                "entry.js",
                cm,
            )
            .expect("recoverable top-level return should produce an AST");

            assert_eq!(
                restore_lifted_function_boundary(&mut module, true),
                BoundaryRestoration::Declined,
                "an export initializer cannot be moved outside the restored return boundary"
            );
        });
    }

    #[test]
    fn lifted_async_return_boundary_preserves_top_level_await() {
        let code = GLOBALS.set(&Default::default(), || {
            let cm: Lrc<SourceMap> = Default::default();
            let mut module = parse_js(
                "if (skip) return; await initialize();",
                "entry.js",
                cm.clone(),
            )
            .expect("recoverable top-level return should produce an AST");
            assert_eq!(
                restore_lifted_function_boundary(&mut module, true),
                BoundaryRestoration::Restored
            );
            apply_fixer(&mut module).expect("restored async module should fix");
            print_js(&module, cm).expect("restored async module should print")
        });

        assert!(
            code.contains("async")
                && code.contains("await initialize()")
                && code.contains("return;"),
            "an async lifted body must regain an async callable boundary:\n{code}"
        );
        assert_eq!(
            validate_output_modules(&[("entry.js".to_string(), code)]),
            vec![]
        );
    }

    #[test]
    fn lifted_return_boundary_ignores_nested_function_returns() {
        GLOBALS.set(&Default::default(), || {
            let cm: Lrc<SourceMap> = Default::default();
            let mut module = parse_js(
                "function read() { return 1; } consume(read());",
                "entry.js",
                cm,
            )
            .expect("fixture should parse");

            assert_eq!(
                restore_lifted_function_boundary(&mut module, true),
                BoundaryRestoration::NotNeeded
            );
        });
    }

    #[test]
    fn lifted_boundary_declines_bodies_observing_this_or_arguments() {
        GLOBALS.set(&Default::default(), || {
            let cm: Lrc<SourceMap> = Default::default();
            let mut module = parse_js(
                "if (skip) return; consume(this.config);",
                "entry.js",
                cm.clone(),
            )
            .expect("recoverable top-level return should produce an AST");
            assert_eq!(
                restore_lifted_function_boundary(&mut module, true),
                BoundaryRestoration::Declined,
                "an arrow boundary would rebind the lifted `this`"
            );

            let mut with_arguments = parse_js(
                "if (skip) return; consume(arguments[0]);",
                "entry.js",
                cm.clone(),
            )
            .expect("recoverable top-level return should produce an AST");
            assert_eq!(
                restore_lifted_function_boundary(&mut with_arguments, true),
                BoundaryRestoration::Declined,
                "an arrow boundary has no `arguments`"
            );

            let mut nested = parse_js(
                "if (skip) return; function tail() { return arguments[0]; } consume(tail(1));",
                "entry.js",
                cm,
            )
            .expect("recoverable top-level return should produce an AST");
            assert_eq!(
                restore_lifted_function_boundary(&mut nested, true),
                BoundaryRestoration::Restored,
                "nested-function `arguments` belongs to that function"
            );
        });
    }

    #[test]
    fn profiler_reports_phase_operation_boundaries() {
        let modules = vec![UnpackedModule {
            id: "entry".to_string(),
            is_entry: true,
            code: "export const value = 1;".to_string(),
            filename: "entry.js".to_string(),
            ..Default::default()
        }];

        let (output, spans) = record_spans(|| {
            unpack_multi_module(modules, DecompileOptions::default())
                .expect("profiled fixture should decompile")
        });

        assert_eq!(output.modules.len(), 1);
        for expected in [
            "phase1: parse",
            "phase1: resolver",
            "phase1: rules",
            "phase1: fact recovery",
            "phase2: rules",
            "phase2: fixer",
            "phase2: emit",
        ] {
            assert!(
                spans.iter().any(|name| name == expected),
                "missing {expected:?} in {spans:?}"
            );
        }
        assert!(
            !spans.iter().any(|name| name == "phase2: parse"),
            "normal unpack should reuse the Phase 1 AST"
        );
    }

    #[test]
    fn export_of_a_block_nested_var_survives_unpack() {
        // `var p` inside the block is a module-scope binding, so the export
        // names a declared local.
        let modules = vec![UnpackedModule {
            id: "entry".to_string(),
            is_entry: true,
            code: r#"if (globalThis.flag) {
    var p = 1;
}
export { p as t };
"#
            .to_string(),
            filename: "entry.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("fixture should decompile");
        let code = &output.modules[0].code;
        assert!(
            code.contains("export { p as t };"),
            "the export should be kept:\n{code}"
        );
    }

    #[test]
    fn late_cleanup_preserves_pre_existing_dead_recovered_import_specifier() {
        let modules = vec![UnpackedModule {
            id: "entry".to_string(),
            is_entry: true,
            code: r#"import { alreadyDead } from "./module.js";"#.to_string(),
            filename: "entry.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(
            modules,
            DecompileOptions {
                dce_mode: DceMode::TransformOnly,
                ..Default::default()
            },
        )
        .expect("fixture should decompile");
        assert_eq!(
            output.modules[0].code,
            "import { alreadyDead } from \"./module.js\";\n"
        );
    }

    #[test]
    fn scope_split_cycles_do_not_emit_diagnostic_warnings() {
        let modules = vec![
            PreparedUnpackModule::with_cycle_warnings(
                UnpackedModule {
                    id: "a".to_string(),
                    is_entry: true,
                    code: r#"import { b } from "./b.js"; export const a = b + 1;"#.to_string(),
                    filename: "entry.js".to_string(),
                    ..Default::default()
                },
                false,
            ),
            PreparedUnpackModule::with_cycle_warnings(
                UnpackedModule {
                    id: "b".to_string(),
                    is_entry: false,
                    code: r#"import { a } from "./entry.js"; export const b = a + 1;"#.to_string(),
                    filename: "b.js".to_string(),
                    ..Default::default()
                },
                false,
            ),
        ];

        let output = unpack_multi_module_with_plan(
            modules,
            NumericRewritePlan::default(),
            DecompileOptions {
                diagnostics: true,
                ..Default::default()
            },
            &[],
        )
        .expect("scope split cycle should decompile");

        assert!(
            output.warnings.is_empty(),
            "native ESM cycles from scope splits should not produce stderr warnings: {:?}",
            output.warnings
        );
    }

    #[test]
    fn multi_module_split_sequence_uses_member_name_for_assignment_temp() {
        let modules = vec![UnpackedModule {
            id: "1".to_string(),
            is_entry: false,
            code: r#"var i, a, o;
module.exports = (a = (i = require("./module-2.js")).lib, o = a.WordArray, i.SHA1);
"#
            .to_string(),
            filename: "module-1.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("fixture should decompile");
        let code = &output.modules[0].code;
        assert!(
            code.contains("const lib ="),
            "expected temp binding to use member name:\n{code}"
        );
        assert!(
            !code.contains("const _a ="),
            "should not synthesize the fallback assignment name:\n{code}"
        );
    }

    #[test]
    fn multi_module_preserves_lowered_interop_binding_read_until_import_recovery() {
        let modules = vec![UnpackedModule {
            id: "1".to_string(),
            is_entry: false,
            code: r#""use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
var a = require("./module-2.js"), o = (r(a), r(require("./module-3.js")));
function r(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
class l extends a.Component {}
exports.default = o.default(l);
"#
            .to_string(),
            filename: "module-1.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("fixture should decompile");
        let code = &output.modules[0].code;
        assert!(
            code.contains("import a from \"./module-2.js\";"),
            "expected require binding to become an import:\n{code}"
        );
        assert!(
            code.contains("import o from \"./module-3.js\";"),
            "expected interop require to become an import:\n{code}"
        );
        assert!(
            code.contains("a;\nclass l extends a.Component"),
            "expected lowered interop binding read to survive until import recovery:\n{code}"
        );
    }

    #[test]
    fn lowered_interop_residue_does_not_block_named_import_recovery() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.transform = function(value) { return value + 1; };".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
function interopRequireDefault(value) {
    return value && value.__esModule ? value : { default: value };
}
var provider = require("./provider.js");
interopRequireDefault(provider);
module.exports = function(value) { return provider.transform(value); };
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("interop residue fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert_eq!(findings, vec![]);

        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import { transform }") && !consumer.contains("provider;"),
            "an inert lowered interop read must not retain a missing default import:\n{consumer}"
        );
    }

    #[test]
    fn named_only_provider_repairs_synthetic_default_to_namespace_import() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "provider".to_string(),
                    code: r#"
exports.alpha = 1;
exports.beta = 2;
"#
                    .to_string(),
                    filename: "provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: r#"
var provider = require("./provider.js");
function read(alpha, beta) {
    return provider.alpha + provider.beta + alpha + beta;
}
module.exports = read;
"#
                    .to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        let output = unpack_multi_module(modules(), DecompileOptions::default())
            .expect("named-only provider fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";"),
            "colliding local names should retain a valid namespace fallback:\n{consumer}"
        );

        let source_map_output = unpack_multi_module(
            modules(),
            DecompileOptions {
                emit_source_map: true,
                ..Default::default()
            },
        )
        .expect("namespace repair should survive the source-map path");
        assert_eq!(validate_prepared_output(&source_map_output), vec![]);
        assert!(
            source_map_output
                .modules
                .iter()
                .all(|module| module.source_map.is_some()),
            "namespace repair must preserve emitted source maps"
        );
    }

    #[test]
    fn named_only_provider_repairs_a_transparent_synthetic_import_alias() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1; exports.beta = 2;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var imported = require("./provider.js");
let provider = imported;
const value = provider.alpha + provider.beta;
provider = { alpha: 3 };
module.exports = value + provider.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("a transparent alias should preserve namespace semantics");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as imported from \"./provider.js\";"),
            "the synthesized edge should become a namespace import:\n{consumer}"
        );
        assert!(
            consumer.contains("provider = {") && consumer.contains("provider.alpha"),
            "the reassigned alias must keep its later, non-namespace lifetime:\n{consumer}"
        );
    }

    #[test]
    fn named_only_provider_keeps_namespace_member_mutation_fail_closed() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var imported = require("./provider.js");
let provider = imported;
provider.alpha = 2;
module.exports = provider.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("a namespace mutation should remain printable");
        let findings = validate_prepared_output(&output);
        assert!(findings.iter().any(|finding| {
            finding.kind == OutputFindingKind::MissingImportedName
                && finding.filename == "consumer.js"
        }));
    }

    #[test]
    fn named_only_provider_keeps_conditional_alias_replacement_fail_closed() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var imported = require("./provider.js");
let provider = imported;
if (replaceProvider) provider = { alpha: 2 };
module.exports = provider.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("a conditional alias replacement should remain printable");
        let findings = validate_prepared_output(&output);
        assert!(findings.iter().any(|finding| {
            finding.kind == OutputFindingKind::MissingImportedName
                && finding.filename == "consumer.js"
        }));
    }

    #[test]
    fn named_only_provider_namespace_supports_enumeration_and_copy_sources() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1; exports.beta = 2;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var provider = require("./provider.js");
var copy = {};
Object.assign(copy, provider);
module.exports = Object.keys(provider).join(",") + copy.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("namespace enumeration fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";"),
            "whole-namespace enumeration and copy must use a namespace import:\n{consumer}"
        );
    }

    #[test]
    fn named_only_provider_repairs_an_escaped_synthetic_default() {
        // Without a default export the default import cannot link, so a
        // namespace passed on as a value keeps the only meaning left.
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1; exports.beta = 2;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var provider = require("./provider.js");
register(provider);
exports.alpha = provider.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("escaped namespace fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";")
                && consumer.contains("register(provider)"),
            "an escaped namespace must not keep a default import that cannot link:\n{consumer}"
        );
    }

    fn decompiled_consumer(provider: &str, consumer: &str) -> String {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: provider.to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: consumer.to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];
        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("provider fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.clone())
            .expect("expected consumer module")
    }

    #[test]
    fn exports_object_provider_with_a_default_repairs_a_whole_use_to_a_namespace() {
        // Requiring the provider returns its `exports` object, which holds
        // `default` as one property among the others: the namespace of the
        // recovered module, not its default export.
        for provider in [
            "exports.default = D; exports.alpha = 1; function D() { return 2; }",
            "require.r(exports); require.d(exports, { default: () => D, alpha: () => alpha }); \
             function D() { return 2; } var alpha = 1;",
        ] {
            let consumer = decompiled_consumer(
                provider,
                "var provider = require(\"./provider.js\"); register(provider); \
                 exports.value = provider.default() + provider.alpha;",
            );
            assert!(
                consumer.contains("import * as provider from \"./provider.js\";")
                    && consumer.contains("register(provider)"),
                "the whole `exports` object is the namespace:\n{consumer}"
            );
        }
    }

    #[test]
    fn provider_declaring_its_default_before_un_esm_keeps_the_default_import() {
        // The webpack runtime normalizers write a replaced `module.exports`
        // as `export default` before the rules run; that default is the whole
        // required value.
        let consumer = decompiled_consumer(
            "var _webpackDefault = function D() {}; _webpackDefault.alpha = 1; \
             export default _webpackDefault; exports.beta = 2;",
            "var provider = require(\"./provider.js\"); register(provider); \
             exports.value = provider.alpha;",
        );
        assert!(
            !consumer.contains("import * as provider"),
            "a declared default is the whole required value:\n{consumer}"
        );
    }

    #[test]
    fn interop_default_of_an_exports_object_provider_keeps_the_default_import() {
        // webpack's `require.n` getter, inline or as the runtime call, reads
        // the default export of a provider marked ESM. The getter is replaced
        // by the plain binding before the repair runs, so the binding then
        // means the default export, not the namespace.
        let provider = "Object.defineProperty(exports, \"__esModule\", { value: true }); \
                        exports.default = { run() { return 2; } }; exports.alpha = 1;";
        for consumer in [
            "var provider = require(\"./provider.js\"), \
             get = () => provider && provider.__esModule ? provider.default : provider; \
             exports.value = get().run();",
            "var provider = require(\"./provider.js\"), get = require.n(provider); \
             exports.value = get().run();",
            // `UnEsm` merges both bindings of the source into one default
            // import, so the whole use alone does not make it a namespace.
            "function _interopRequireDefault(obj) { \
               return obj && obj.__esModule ? obj : { default: obj }; } \
             var whole = require(\"./provider.js\"); \
             var provider = _interopRequireDefault(require(\"./provider.js\")); \
             register(whole); exports.value = provider.default.run();",
        ] {
            let consumer = decompiled_consumer(provider, consumer);
            assert!(
                !consumer.contains("import * as"),
                "an unwrapped interop default must keep the default import:\n{consumer}"
            );
        }
    }

    /// swc's `_interop_require_wildcard`, inlined by Terser at its only call
    /// site and applied to `require("./provider.js")`.
    /// shape: producer swc@1.16.2 module=commonjs, then @rspack/core@1.7.12
    /// mode=production.
    const INLINE_WILDCARD_REQUIRE: &str = "function(e) { \
        if (e && e.__esModule) return e; \
        if (null === e || \"object\" != typeof e && \"function\" != typeof e) return { default: e }; \
        var n = { __proto__: null }, u = Object.defineProperty && Object.getOwnPropertyDescriptor; \
        for (var o in e) if (\"default\" !== o && Object.prototype.hasOwnProperty.call(e, o)) { \
          var a = u ? Object.getOwnPropertyDescriptor(e, o) : null; \
          a && (a.get || a.set) ? Object.defineProperty(n, o, a) : n[o] = e[o]; } \
        return n.default = e, n; }(require(\"./provider.js\"))";

    #[test]
    fn inline_wildcard_of_a_marked_provider_repairs_to_a_namespace() {
        // A wildcard interop returns a provider marked `__esModule` unchanged,
        // so the binding is the whole `exports` object: the namespace.
        let consumer = decompiled_consumer(
            "Object.defineProperty(exports, \"__esModule\", { value: !0 }); \
             exports.default = D; exports.alpha = 1; function D() { return 2; }",
            &format!(
                "var provider = {INLINE_WILDCARD_REQUIRE}; register(provider); \
                 exports.value = provider.default() + provider.alpha;"
            ),
        );
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";")
                && consumer.contains("register(provider)"),
            "the wildcard of a marked provider is its namespace:\n{consumer}"
        );
    }

    #[test]
    fn inline_wildcard_of_an_unmarked_provider_keeps_the_default_import() {
        // Without the marker the wildcard builds a copy whose `default` is the
        // whole `exports` object, not the recovered default export.
        let consumer = decompiled_consumer(
            "exports.default = D; exports.alpha = 1; function D() { return 2; }",
            &format!(
                "var provider = {INLINE_WILDCARD_REQUIRE}; register(provider); \
                 exports.value = provider.default.alpha;"
            ),
        );
        assert!(
            !consumer.contains("import * as provider"),
            "an unmarked provider must keep the default import:\n{consumer}"
        );
    }

    #[test]
    fn replaced_module_exports_provider_keeps_the_default_import_of_a_whole_use() {
        // `module.exports = D` makes `D` the whole required value; its
        // properties are recovered as named exports, but the default import
        // is the value the consumer used.
        let consumer = decompiled_consumer(
            "module.exports = D; module.exports.alpha = 1; function D() { return 2; }",
            "var provider = require(\"./provider.js\"); register(provider); \
             exports.value = provider() + provider.alpha;",
        );
        assert!(
            consumer.contains("import provider from \"./provider.js\";"),
            "a replaced `module.exports` is the default export:\n{consumer}"
        );
    }

    #[test]
    fn webpack_namespace_object_of_a_commonjs_import_becomes_a_namespace_import() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1; exports.beta = 2;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var ns;
var provider = require("./provider.js");
register(ns || (ns = require.t(provider, 2)));
exports.alpha = provider.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("require.t namespace fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";")
                && consumer.contains("register(provider)")
                && !consumer.contains("require.t"),
            "webpack's namespace object of a whole import is the namespace import:\n{consumer}"
        );
    }

    #[test]
    fn recovered_export_star_surface_repairs_downstream_namespace_copy() {
        let modules = vec![
            UnpackedModule {
                id: "source".to_string(),
                code: "exports.alpha = 1; exports.beta = 2;".to_string(),
                filename: "source.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "facade".to_string(),
                code: r#"
var source = require("./source.js");
Object.keys(source).forEach(function(key) {
    key !== "default" && key !== "__esModule" &&
        (key in exports && exports[key] === source[key] ||
            (exports[key] = source[key]));
});
"#
                .to_string(),
                filename: "facade.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var facade = require("./facade.js");
var copy = {};
Object.assign(copy, facade);
module.exports = copy.alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("recovered export-star fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let facade = output
            .modules
            .iter()
            .find(|module| module.filename == "facade.js")
            .map(|module| module.code.as_str())
            .expect("expected facade module");
        assert_eq!(facade, "export * from \"./source.js\";\n");
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as facade from \"./facade.js\";"),
            "the downstream copy must consume the recovered namespace surface:\n{consumer}"
        );
    }

    #[test]
    fn export_star_provider_supports_synthetic_namespace_require() {
        let modules = vec![
            UnpackedModule {
                id: "source".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "source.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "provider".to_string(),
                code: "export * from \"./source.js\";".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var provider = require("./provider.js");
module.exports = Object.keys(provider);
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("export-star namespace fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";"),
            "an export-star surface is valid through a namespace import:\n{consumer}"
        );
    }

    #[test]
    fn authored_default_import_is_not_provider_repaired() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
import provider from "./provider.js";
console.log(Object.keys(provider));
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("authored import fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "provider repair must not reinterpret authored default imports: {findings:#?}"
        );
    }

    #[test]
    fn provider_namespace_repair_rejects_esmodule_meta_observation() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var provider = require("./provider.js");
module.exports = provider.__esModule;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("namespace metadata fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "observing CommonJS interop metadata must keep namespace repair fail closed: {findings:#?}"
        );
    }

    #[test]
    fn getter_map_default_provider_supports_synthetic_default_import() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "provider".to_string(),
                    code: r#"
((target, getters) => {
    for (const key in getters) {
        Object.defineProperty(target, key, {
            enumerable: true,
            get: getters[key]
        });
    }
})(exports, {
    dim() { return dim; },
    default() { return logger; }
});
function dim(value) { return value; }
const logger = {
    warn(value) { console.warn(value); }
};
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && exports.default.__esModule === undefined) {
    Object.defineProperty(exports.default, "__esModule", { value: true });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
"#
                    .to_string(),
                    filename: "provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: r#"
var logger = require("./provider.js");
module.exports = function(value) { return logger.warn(value); };
"#
                    .to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        let output = unpack_multi_module(modules(), DecompileOptions::default())
            .expect("getter-map default fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let provider = output
            .modules
            .iter()
            .find(|module| module.filename == "provider.js")
            .map(|module| module.code.as_str())
            .expect("expected provider module");
        assert!(
            provider.contains("export { logger as default };")
                && !provider.contains("Object.defineProperty"),
            "the provider should expose the recovered live default:\n{provider}"
        );
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        // The compatibility block makes the default the whole required value.
        assert!(
            consumer.contains("import logger from \"./provider.js\";"),
            "the proven provider default should satisfy the synthetic require:\n{consumer}"
        );

        let source_map_output = unpack_multi_module(
            modules(),
            DecompileOptions {
                emit_source_map: true,
                ..Default::default()
            },
        )
        .expect("getter-map default should survive the source-map path");
        assert_eq!(validate_prepared_output(&source_map_output), vec![]);
        assert!(
            source_map_output
                .modules
                .iter()
                .all(|module| module.source_map.is_some()),
            "getter-map default recovery must preserve emitted source maps"
        );
    }

    #[test]
    fn unused_synthetic_require_becomes_side_effect_import() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "provider".to_string(),
                    code: "exports.alpha = 1;".to_string(),
                    filename: "provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: r#"
before();
var unused = require("./provider.js");
after();
module.exports = 42;
"#
                    .to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        let output = unpack_multi_module(modules(), DecompileOptions::default())
            .expect("unused require fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import \"./provider.js\";"),
            "provider evaluation must survive as a side-effect import:\n{consumer}"
        );
        assert!(
            !consumer.contains("import unused") && !consumer.contains("var unused"),
            "the unused guessed default binding should be removed:\n{consumer}"
        );

        let source_map_output = unpack_multi_module(
            modules(),
            DecompileOptions {
                emit_source_map: true,
                ..Default::default()
            },
        )
        .expect("unused require cleanup should survive the source-map path");
        assert_eq!(validate_prepared_output(&source_map_output), vec![]);
        assert!(
            source_map_output
                .modules
                .iter()
                .all(|module| module.source_map.is_some()),
            "side-effect import recovery must preserve emitted source maps"
        );
    }

    #[test]
    fn unused_synthetic_default_is_removed_from_mixed_import() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var unused = require("./provider.js");
var alpha = require("./provider.js").alpha;
module.exports = alpha;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("mixed import fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import { alpha }") && !consumer.contains("import unused"),
            "only the used named binding should remain:\n{consumer}"
        );
    }

    #[test]
    fn unused_authored_import_is_not_synthetic_cleanup() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.alpha = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
import missing from "./provider.js";
export const result = 1;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("authored unused import fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "cleanup must not reinterpret an authored dead import: {findings:#?}"
        );
    }

    #[test]
    fn substantive_namespace_use_still_blocks_named_import_recovery() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.transform = function(value) { return value + 1; };".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
function interopRequireDefault(value) {
    return value && value.__esModule ? value : { default: value };
}
var provider = require("./provider.js");
interopRequireDefault(provider);
observe(provider);
module.exports = function(value) { return provider.transform(value); };
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("substantive namespace fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import * as provider from \"./provider.js\";")
                && consumer.contains("observe(provider)")
                && consumer.contains("provider.transform(value)")
                && !consumer.contains("import { transform }"),
            "a substantive whole-object use must keep the whole namespace binding:\n{consumer}"
        );
    }

    #[test]
    fn provider_facts_capture_missing_properties_from_proven_empty_default_objects() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "empty-stub".to_string(),
                    code: "module.exports = {};".to_string(),
                    filename: "empty-stub.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: r#"
before();
var existsSync = require("./empty-stub.js").existsSync;
after();
module.exports = function(path) {
    return Boolean(existsSync) && existsSync(path);
};
"#
                    .to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        for emit_source_map in [false, true] {
            let output = unpack_multi_module(
                modules(),
                DecompileOptions {
                    emit_source_map,
                    ..Default::default()
                },
            )
            .expect("proven empty default-object fixture should decompile");
            assert_eq!(validate_prepared_output(&output), vec![]);

            let consumer = output
                .modules
                .iter()
                .find(|module| module.filename == "consumer.js")
                .map(|module| module.code.as_str())
                .expect("expected consumer module");
            assert!(
                !consumer.contains("import { existsSync"),
                "a CommonJS property read must not remain a named import:\n{consumer}"
            );
            assert!(
                consumer.contains(".existsSync"),
                "the property must be captured from the proven default object:\n{consumer}"
            );
            let before = consumer
                .find("before();")
                .expect("leading effect should remain");
            let capture = consumer[before..]
                .find(".existsSync")
                .map(|offset| before + offset)
                .expect("property capture should remain");
            let after = consumer
                .find("after();")
                .expect("trailing effect should remain");
            assert!(
                before < capture && capture < after,
                "the property read must remain at its original require position:\n{consumer}"
            );
            if emit_source_map {
                assert!(
                    output
                        .modules
                        .iter()
                        .all(|module| module.source_map.is_some()),
                    "provider repair must preserve emitted source maps"
                );
            }
        }
    }

    #[test]
    fn provider_facts_capture_proven_callable_default_properties() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "provider".to_string(),
                    code: r#"
function api(value) { return value; }
api.parse = function(value) { return value.length; };
api.Rule = class Rule {};
module.exports = api;
api.default = api;
"#
                    .to_string(),
                    filename: "provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: r#"
before();
var parse = require("./provider.js").parse;
var Rule = require("./provider.js").Rule;
after();
module.exports = [parse("value"), new Rule()];
"#
                    .to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        for emit_source_map in [false, true] {
            let output = unpack_multi_module(
                modules(),
                DecompileOptions {
                    emit_source_map,
                    ..Default::default()
                },
            )
            .expect("proven callable-property fixture should decompile");
            assert_eq!(validate_prepared_output(&output), vec![]);

            let consumer = output
                .modules
                .iter()
                .find(|module| module.filename == "consumer.js")
                .map(|module| module.code.as_str())
                .expect("expected consumer module");
            assert!(
                !consumer.contains("import { parse") && !consumer.contains("Rule } from"),
                "attached CommonJS properties must not remain guessed named imports:\n{consumer}"
            );
            assert!(
                (consumer.contains(".parse") && consumer.contains(".Rule"))
                    || consumer.contains("{ parse, Rule }"),
                "attached properties must be captured from the callable default:\n{consumer}"
            );
            let before = consumer
                .find("before();")
                .expect("leading effect should remain");
            let parse_capture = consumer
                .find(".parse")
                .or_else(|| consumer.find("{ parse"))
                .expect("parse capture should remain");
            let rule_capture = consumer[parse_capture..]
                .find("Rule")
                .map(|offset| parse_capture + offset)
                .expect("Rule capture should remain");
            let after = consumer
                .find("after();")
                .expect("trailing effect should remain");
            assert!(
                before < parse_capture && parse_capture < rule_capture && rule_capture < after,
                "callable property reads must stay at their original require positions:\n{consumer}"
            );
            if emit_source_map {
                assert!(
                    output
                        .modules
                        .iter()
                        .all(|module| module.source_map.is_some()),
                    "callable property repair must preserve emitted source maps"
                );
            }
        }
    }

    #[test]
    fn provider_facts_reject_a_conditionally_rewritten_callable_default() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "provider".to_string(),
                    code: r#"
function api(value) { return value; }
api.parse = function(value) { return value.length; };
module.exports = api;
if (globalThis.legacy) { module.exports = globalThis.wrap(api); }
"#
                    .to_string(),
                    filename: "provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: r#"
var parse = require("./provider.js").parse;
module.exports = function(value) { return parse(value); };
"#
                    .to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        for emit_source_map in [false, true] {
            let output = unpack_multi_module(
                modules(),
                DecompileOptions {
                    emit_source_map,
                    ..Default::default()
                },
            )
            .expect("conditional callable-default fixture should decompile");
            let findings = validate_prepared_output(&output);
            assert!(
                findings.iter().any(|finding| {
                    finding.kind == OutputFindingKind::MissingImportedName
                        && finding.filename == "consumer.js"
                }),
                "an unproven callable surface must remain visible to validation: {findings:#?}"
            );

            let consumer = output
                .modules
                .iter()
                .find(|module| module.filename == "consumer.js")
                .map(|module| module.code.as_str())
                .expect("expected consumer module");
            assert!(
                consumer.contains("import { parse } from \"./provider.js\""),
                "an unproven property import must not be rewritten through the default export:\n{consumer}"
            );
        }
    }

    #[test]
    fn provider_facts_reject_conditional_properties_on_a_localized_callable_alias() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: r#"
function api(value) { return value; }
var local = module.exports = api;
if (globalThis.enableOptional) { local.optional = function() { return true; }; }
"#
                .to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var optional = require("./provider.js").optional;
module.exports = optional;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("conditional alias-property fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "a conditional alias property must remain visible to validation: {findings:#?}"
        );
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        assert!(
            consumer.contains("import { optional } from \"./provider.js\""),
            "an unproven alias property must not be repaired through the default export:\n{consumer}"
        );
    }

    #[test]
    fn provider_facts_do_not_infer_absent_callable_properties() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: r#"
function api(value) { return value; }
api.parse = function(value) { return value.length; };
module.exports = api;
"#
                .to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var missing = require("./provider.js").missing;
module.exports = function() { return missing; };
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("absent callable-property fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "callable facts prove only observed properties and must not infer an absent one: {findings:#?}"
        );
    }

    #[test]
    fn provider_property_capture_preserves_same_declaration_order() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: r#"
module.exports = {
    capability: function() { return true; },
    secondary: function() { return true; }
};
"#
                .to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
let first = sideEffect(),
    { capability, secondary } = require("./provider.js"),
    available = Boolean(capability && secondary);
observe(first, available);
module.exports = available;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("same-declaration capture fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected consumer module");
        let effect = consumer
            .find("sideEffect()")
            .expect("leading declarator should remain");
        let capture = consumer
            .find(".capability")
            .or_else(|| consumer.find("{ capability"))
            .expect("property capture should remain");
        let secondary_capture = consumer[capture..]
            .find("secondary")
            .map(|offset| capture + offset)
            .expect("second property capture should remain");
        let feature_check = consumer
            .find("Boolean(")
            .expect("later declarator should remain");
        assert!(
            effect < capture && capture < secondary_capture && secondary_capture < feature_check,
            "captures must remain ordered between surrounding declarators:\n{consumer}"
        );
    }

    #[test]
    fn provider_facts_repair_recovered_commonjs_import_shapes() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "default-provider".to_string(),
                    code: r#"
var methods = {
    map: function(value) { return value + 1; },
    filter: function(value) { return value > 0; }
};
module.exports = methods;
"#
                    .to_string(),
                    filename: "default-provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "named-consumer".to_string(),
                    is_entry: true,
                    code: r#"
before();
var map = require("./default-provider.js").map;
between();
var filter = require("./default-provider.js").filter;
map = replacement;
module.exports = function(value) { return filter(map(value)); };
"#
                    .to_string(),
                    filename: "named-consumer.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        let output = unpack_multi_module(modules(), DecompileOptions::default())
            .expect("provider-aware fixture should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);

        let named_consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "named-consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected named consumer");
        assert!(
            !named_consumer.contains("import { map")
                && !named_consumer.contains("filter } from"),
            "properties of a proven default object must be captured from its default import:\n{named_consumer}"
        );
        assert!(
            (named_consumer.contains("{ map:") && named_consumer.contains("filter }"))
                || (named_consumer.contains(".map") && named_consumer.contains(".filter")),
            "property captures must come from the proven default object:\n{named_consumer}"
        );
        assert!(
            named_consumer.contains("let map") || named_consumer.contains("let { map"),
            "a reassigned property local must remain mutable instead of becoming an import binding:\n{named_consumer}"
        );
        let before = named_consumer
            .find("before();")
            .expect("leading effect should remain");
        let map_capture = named_consumer[before..]
            .find("map")
            .map(|offset| before + offset)
            .expect("map capture should remain");
        let between = named_consumer
            .find("between();")
            .expect("middle effect should remain");
        let filter_capture = named_consumer[between..]
            .find("filter")
            .map(|offset| between + offset)
            .expect("filter capture should remain");
        assert!(
            before < map_capture && map_capture < between && between < filter_capture,
            "property captures must stay at their original require positions around effects:\n{named_consumer}"
        );

        let source_map_output = unpack_multi_module(
            modules(),
            DecompileOptions {
                emit_source_map: true,
                ..Default::default()
            },
        )
        .expect("provider-aware fixture should decompile through the source-map path");
        assert_eq!(validate_prepared_output(&source_map_output), vec![]);
        assert!(
            source_map_output
                .modules
                .iter()
                .all(|module| module.source_map.is_some()),
            "provider repair must survive the source-map path's second parse"
        );
    }

    #[test]
    fn commonjs_default_object_composition_preserves_mutable_identity_and_copy_order() {
        let modules = || {
            vec![
                UnpackedModule {
                    id: "base-a".to_string(),
                    code: r#"module.exports = { alpha: "a", shared: "first" };"#.to_string(),
                    filename: "base-a.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "base-b".to_string(),
                    code: r#"module.exports = { beta: "b", shared: "second" };"#.to_string(),
                    filename: "base-b.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "middle".to_string(),
                    code: r#"
module.exports = {};
Object.assign(module.exports, require("./base-a.js") || {});
"#
                    .to_string(),
                    filename: "middle.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "entry".to_string(),
                    is_entry: true,
                    code: r#"
module.exports = {};
Object.assign(module.exports, require("./middle.js") || {});
Object.assign(module.exports, require("./base-b.js") || {});
"#
                    .to_string(),
                    filename: "entry.js".to_string(),
                    ..Default::default()
                },
            ]
        };

        let output = unpack_multi_module(modules(), DecompileOptions::default())
            .expect("default-object composition should decompile");
        assert_eq!(validate_prepared_output(&output), vec![]);

        for filename in ["middle.js", "entry.js"] {
            let code = output
                .modules
                .iter()
                .find(|module| module.filename == filename)
                .map(|module| module.code.as_str())
                .expect("expected composed module");
            assert!(
                !code.contains("module.exports") && !code.contains("require("),
                "the exact composition should use recovered ESM edges:\n{code}"
            );
            assert!(
                !code.contains("export default {};"),
                "the exported value must be the same object that Object.assign mutates:\n{code}"
            );
            assert!(
                code.contains("Object.assign(_defaultObject,")
                    && code.contains("export default _defaultObject;"),
                "both the copies and default export must share one local object:\n{code}"
            );
        }

        let entry = output
            .modules
            .iter()
            .find(|module| module.filename == "entry.js")
            .map(|module| module.code.as_str())
            .expect("expected entry module");
        assert_eq!(
            entry.matches("Object.assign(").count(),
            2,
            "both ordered copies must remain visible:\n{entry}"
        );
        assert!(
            entry.find("./middle.js").expect("middle import")
                < entry.find("./base-b.js").expect("base-b import"),
            "provider imports should retain first-use order:\n{entry}"
        );

        let source_map_output = unpack_multi_module(
            modules(),
            DecompileOptions {
                emit_source_map: true,
                ..Default::default()
            },
        )
        .expect("composition recovery should survive the source-map path");
        assert_eq!(validate_prepared_output(&source_map_output), vec![]);
        assert!(
            source_map_output
                .modules
                .iter()
                .all(|module| module.source_map.is_some()),
            "composition recovery must preserve emitted source maps"
        );
    }

    #[test]
    fn commonjs_default_object_composition_requires_complete_provider_and_consumer_proofs() {
        let cases = [
            (
                "unknown-provider",
                "module.exports = makeStyles();",
                r#"
module.exports = {};
Object.assign(module.exports, require("./provider.js") || {});
"#,
            ),
            (
                "authored-esm-provider",
                "export default { value: 1 };",
                r#"
module.exports = {};
Object.assign(module.exports, require("./provider.js") || {});
"#,
            ),
            (
                "mutated-provider-surface",
                "module.exports = {}; module.exports.value = 1;",
                r#"
module.exports = {};
Object.assign(module.exports, require("./provider.js") || {});
"#,
            ),
            (
                "extra-consumer-runtime-use",
                "module.exports = { value: 1 };",
                r#"
module.exports = {};
observe(module.exports);
Object.assign(module.exports, require("./provider.js") || {});
"#,
            ),
        ];

        for (name, provider, consumer) in cases {
            let modules = vec![
                UnpackedModule {
                    id: "provider".to_string(),
                    code: provider.to_string(),
                    filename: "provider.js".to_string(),
                    ..Default::default()
                },
                UnpackedModule {
                    id: "consumer".to_string(),
                    is_entry: true,
                    code: consumer.to_string(),
                    filename: "consumer.js".to_string(),
                    ..Default::default()
                },
            ];
            let output = unpack_multi_module(modules, DecompileOptions::default())
                .unwrap_or_else(|error| panic!("{name} fixture should decompile: {error}"));
            let consumer = output
                .modules
                .iter()
                .find(|module| module.filename == "consumer.js")
                .map(|module| module.code.as_str())
                .expect("expected consumer module");
            assert!(
                consumer.contains("module.exports") && consumer.contains("require("),
                "{name} must fail closed instead of inventing a mutable default:\n{consumer}"
            );
            assert!(
                validate_prepared_output(&output)
                    .iter()
                    .any(|finding| finding.kind == OutputFindingKind::EsmCommonJsResidual),
                "{name} should retain an honest CommonJS residual"
            );
        }
    }

    #[test]
    fn commonjs_default_object_composition_cycles_fail_closed() {
        let modules = vec![
            UnpackedModule {
                id: "left".to_string(),
                is_entry: true,
                code: r#"
module.exports = {};
Object.assign(module.exports, require("./right.js") || {});
"#
                .to_string(),
                filename: "left.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "right".to_string(),
                code: r#"
module.exports = {};
Object.assign(module.exports, require("./left.js") || {});
"#
                .to_string(),
                filename: "right.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("cyclic composition fixture should decompile conservatively");
        assert!(output.modules.iter().all(|module| {
            module.code.contains("module.exports") && module.code.contains("require(")
        }));
        assert_eq!(
            validate_prepared_output(&output)
                .iter()
                .filter(|finding| finding.kind == OutputFindingKind::EsmCommonJsResidual)
                .count(),
            2,
            "the unresolved module target in each cyclic module should remain visible"
        );
    }

    #[test]
    fn provider_facts_leave_unproven_default_properties_unchanged() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "module.exports = makeProvider();".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var missing = require("./provider.js").missing;
module.exports = function() { return missing; };
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("unproven provider fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "an unknown default value must fail closed instead of fabricating a property capture: {findings:#?}"
        );
    }

    #[test]
    fn provider_facts_leave_mutated_commonjs_namespaces_unresolved() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "exports.value = 1;".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var provider = require("./provider.js");
provider.value = 2;
module.exports = provider;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("mutable namespace fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "a mutable CommonJS exports object needs a provider facade and must fail closed: {findings:#?}"
        );
    }

    #[test]
    fn provider_facts_leave_export_star_surfaces_unresolved() {
        let modules = vec![
            UnpackedModule {
                id: "star-source".to_string(),
                code: "exports.other = 1;".to_string(),
                filename: "star-source.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "provider".to_string(),
                code: r#"
module.exports = { value: 1 };
export * from "./star-source.js";
"#
                .to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"
var value = require("./provider.js").value;
module.exports = value;
"#
                .to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("export-star provider fixture should decompile");
        let findings = validate_prepared_output(&output);
        assert!(
            findings.iter().any(|finding| {
                finding.kind == OutputFindingKind::MissingImportedName
                    && finding.filename == "consumer.js"
            }),
            "an open export-star surface must fail closed instead of treating local absence as proof: {findings:#?}"
        );
    }

    #[test]
    fn provider_facts_do_not_rewrite_authored_esm_imports() {
        let modules = vec![
            UnpackedModule {
                id: "provider".to_string(),
                code: "export default { value: 1 };".to_string(),
                filename: "provider.js".to_string(),
                ..Default::default()
            },
            UnpackedModule {
                id: "consumer".to_string(),
                is_entry: true,
                code: r#"import { value } from "./provider.js"; console.log(value);"#.to_string(),
                filename: "consumer.js".to_string(),
                ..Default::default()
            },
        ];

        let output = unpack_multi_module(modules, DecompileOptions::default())
            .expect("authored ESM fixture should decompile");
        let consumer = output
            .modules
            .iter()
            .find(|module| module.filename == "consumer.js")
            .map(|module| module.code.as_str())
            .expect("expected ESM consumer");
        assert!(
            consumer.contains("import { value }"),
            "authored ESM imports must remain outside CommonJS repair:\n{consumer}"
        );
    }

    #[test]
    fn unpack_keeps_exported_builtin_alias_declared() {
        // `export { create }` names the alias binding, so the alias inliner
        // leaves the declaration alone instead of removing it and relying on
        // stale-export pruning to drop the specifier (which would also drop
        // the export from every consumer's point of view).
        let modules = vec![UnpackedModule {
            id: "helper".to_string(),
            is_entry: false,
            code: r#"
var create = Object.create;
function wrap(value) {
    return create(value);
}
export { create, wrap };
"#
            .to_string(),
            filename: "helper.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(
            modules,
            DecompileOptions {
                level: RewriteLevel::Standard,
                ..Default::default()
            },
        )
        .expect("module should decompile");
        let code = &output.modules[0].code;

        assert!(
            code.contains("= Object.create;"),
            "exported alias declaration should survive:\n{code}"
        );
        assert!(
            code.contains("create") && code.contains("wrap"),
            "both exports should be preserved:\n{code}"
        );
        let findings = crate::validate_output_modules(&[("helper.js".to_string(), code.clone())]);
        assert!(findings.is_empty(), "{findings:#?}");
    }

    #[test]
    fn normal_unpack_phase_preserves_helper_declaration_order() {
        let modules = vec![UnpackedModule {
            id: "entry".to_string(),
            is_entry: true,
            code: r#"
setup();
const { defineProperty } = Object;
var helper = (target) => defineProperty({}, "x", { value: target });
function setup() {
    return helper;
}
export { helper };
"#
            .to_string(),
            filename: "entry.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(
            modules,
            DecompileOptions {
                level: RewriteLevel::Minimal,
                ..Default::default()
            },
        )
        .expect("module should decompile");
        let code = &output.modules[0].code;
        let setup_call = code.find("setup()").expect("setup call should remain");
        let define_property = code
            .find("defineProperty } = Object")
            .expect("Object destructuring helper should remain");
        let helper = code.find("helper =").expect("helper binding should remain");

        assert!(
            setup_call < define_property && define_property < helper,
            "normal unpack should preserve declaration order; raw runnable cleanup owns helper hoisting:\n{code}"
        );
    }

    #[test]
    fn unpack_emit_source_map_uses_phase2_parser_source_map() {
        let modules = vec![UnpackedModule {
            id: "entry".to_string(),
            is_entry: true,
            code: "const value = input + 1;\nexport { value };".to_string(),
            filename: "entry.js".to_string(),
            ..Default::default()
        }];

        let output = unpack_multi_module(
            modules,
            DecompileOptions {
                emit_source_map: true,
                ..Default::default()
            },
        )
        .expect("module should decompile with source maps");

        let source_map = output.modules[0]
            .source_map
            .as_deref()
            .expect("unpack should emit one source map per kept module");
        let sm = sourcemap::SourceMap::from_reader(source_map.as_bytes())
            .expect("source map should parse");
        assert_eq!(sm.get_file(), Some("entry.js"));
        assert!(
            sm.get_token_count() > 0,
            "source map should contain generated-to-input mappings"
        );
    }

    #[test]
    fn unpack_rejects_bundle_level_input_source_map() {
        let modules = vec![UnpackedModule {
            id: "entry".to_string(),
            is_entry: true,
            code: "export const value = 1;".to_string(),
            filename: "entry.js".to_string(),
            ..Default::default()
        }];

        let error = unpack_multi_module(
            modules,
            DecompileOptions {
                sourcemap: Some(br#"{"version":3,"sources":[],"names":[],"mappings":""}"#.to_vec()),
                ..Default::default()
            },
        )
        .expect_err("bundle-level input maps must be rejected before module renaming");
        assert!(error.to_string().contains(
            "input source maps are not supported with unpacking because extracted module coordinates differ from bundle coordinates"
        ));
    }
}
