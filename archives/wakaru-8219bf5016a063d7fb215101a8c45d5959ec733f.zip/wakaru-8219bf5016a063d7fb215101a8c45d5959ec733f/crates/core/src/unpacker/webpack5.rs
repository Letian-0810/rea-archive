use crate::collections::{HashMap, HashSet};

use swc_core::atoms::Atom;
use swc_core::common::{
    sync::Lrc, Globals, Mark, SourceMap, Span, Spanned, SyntaxContext, DUMMY_SP, GLOBALS,
};
use swc_core::ecma::ast::{
    ArrayLit, ArrowFunctionBody, AssignExpr, AssignOp, AssignTarget, BinExpr, BinaryOp, CallExpr,
    Callee, Expr, ExprStmt, FnExpr, Id, Ident, IdentName, KeyValueProp, Lit, MemberExpr,
    MemberProp, Module, ModuleItem, ObjectLit, Pat, Prop, PropName, PropOrSpread, SeqExpr,
    SimpleAssignTarget, Stmt, Str, UnaryExpr, UnaryOp, VarDecl, VarDeclarator,
};
use swc_core::ecma::codegen::Config;
use swc_core::ecma::transforms::base::resolver;
use swc_core::ecma::utils::replace_ident;
use swc_core::ecma::visit::{Visit, VisitMut, VisitMutWith, VisitWith};

use crate::js_names::{is_reserved_binding_name, is_valid_identifier_name};
use crate::rules::rename_utils::BindingRename;
use crate::unpacker::surrounding::{
    ContextSymCollector, IdentNameCollector, SurroundingCode, SurroundingItems,
};
use crate::unpacker::webpack4::{
    rewrite_require_n_accesses, unwrap_webpack_global_envelopes, RequireIdRewriter,
    RequireStringIdRewriter,
};
use crate::unpacker::webpack_common::{
    is_external_require_call, isolated_failure, numeric_id_from_expr, split_array_concat,
    FactoryNormalizationError,
};
use crate::unpacker::{
    deconflict_runtime_binding_renames, emit_module_with_positions, source_fallback_for_stmts,
    spans_byte_ranges, stmts_have_function_level_return,
    stmts_have_function_level_special_bindings, BundleFormat, DetectedBundle,
    DetectedModuleFailure, MappedCode, PreparedModuleAst, SourcePositions, UnpackResult,
    UnpackedModule,
};
use crate::utils::paren::strip_parens;
use crate::utils::swc_safety::apply_fixer;

struct Webpack5RuntimeNormalizer {
    require_sym: Atom,
    unresolved_mark: Mark,
}

impl VisitMut for Webpack5RuntimeNormalizer {
    fn visit_mut_expr(&mut self, expr: &mut Expr) {
        expr.visit_mut_children_with(self);

        // `hmd` / `nmd` return the module object they receive, so the
        // decorator assignment evaluates to the value `module` already holds.
        if let Some(module) = self.factory_module_decorator_target(expr) {
            *expr = Expr::Ident(module);
        } else if let Some(ctxt) = self.try_match_require_member(expr, "g") {
            *expr = Expr::Ident(Ident::new(Atom::from("global"), DUMMY_SP, ctxt));
        } else if let Some(ctxt) = self.try_match_require_member(expr, "amdO") {
            *expr = amd_define_detection_expr(ctxt);
        }
    }

    fn visit_mut_module_items(&mut self, items: &mut Vec<ModuleItem>) {
        items.visit_mut_children_with(self);

        let mut new_items = Vec::with_capacity(items.len());
        for item in items.drain(..) {
            if let ModuleItem::Stmt(stmt) = item {
                if let Some(replacements) = self.try_convert_stmt(&stmt, true) {
                    new_items.extend(replacements.into_iter().map(ModuleItem::Stmt));
                } else {
                    new_items.push(ModuleItem::Stmt(stmt));
                }
            } else {
                new_items.push(item);
            }
        }
        *items = new_items;
    }

    fn visit_mut_stmts(&mut self, stmts: &mut Vec<Stmt>) {
        stmts.visit_mut_children_with(self);

        let mut new_stmts = Vec::with_capacity(stmts.len());
        for stmt in stmts.drain(..) {
            if let Some(replacements) = self.try_convert_stmt(&stmt, false) {
                new_stmts.extend(replacements);
            } else {
                new_stmts.push(stmt);
            }
        }
        *stmts = new_stmts;
    }
}

impl Webpack5RuntimeNormalizer {
    fn try_match_require_member(&self, expr: &Expr, expected_prop: &str) -> Option<SyntaxContext> {
        let Expr::Member(MemberExpr { obj, prop, .. }) = expr else {
            return None;
        };
        let Expr::Ident(obj_ident) = &**obj else {
            return None;
        };
        if obj_ident.sym != self.require_sym || obj_ident.ctxt.outer() != self.unresolved_mark {
            return None;
        }
        let MemberProp::Ident(prop_name) = prop else {
            return None;
        };
        if prop_name.sym.as_ref() != expected_prop {
            return None;
        }
        Some(obj_ident.ctxt)
    }

    fn try_convert_stmt(
        &self,
        stmt: &Stmt,
        allow_module_decorator_removal: bool,
    ) -> Option<Vec<Stmt>> {
        let Stmt::Expr(ExprStmt { expr, .. }) = stmt else {
            return None;
        };
        let stripped_expr = strip_parens(expr);
        // `visit_mut_expr` has already reduced each factory decorator to a
        // plain `module` read; drop the reads left in statement position.
        if allow_module_decorator_removal {
            if self.is_factory_module_read(stripped_expr) {
                return Some(vec![]);
            }
            if let Expr::Seq(seq) = stripped_expr {
                return self.try_remove_module_decorator_from_seq(seq);
            }
        }
        let Expr::Call(call) = stripped_expr else {
            return None;
        };
        let Callee::Expr(callee_expr) = &call.callee else {
            return None;
        };
        let Expr::Member(MemberExpr { obj, prop, .. }) = &**callee_expr else {
            return None;
        };
        let Expr::Ident(callee_obj) = &**obj else {
            return None;
        };
        if callee_obj.sym != self.require_sym || callee_obj.ctxt.outer() != self.unresolved_mark {
            return None;
        }
        let MemberProp::Ident(prop_name) = prop else {
            return None;
        };

        match prop_name.sym.as_ref() {
            // `require.r({})` — the esModule marker applied to a
            // minifier-inlined, otherwise-unused exports object (webpack's
            // `var t = {}; require.r(t)` after the anchor was inlined) — a
            // semantic no-op.
            "r" if call.args.len() == 1
                && call.args[0].spread.is_none()
                && matches!(
                    strip_parens(&call.args[0].expr),
                    Expr::Object(object) if object.props.is_empty()
                ) =>
            {
                Some(vec![])
            }
            _ => None,
        }
    }

    fn try_remove_module_decorator_from_seq(&self, seq: &SeqExpr) -> Option<Vec<Stmt>> {
        let mut changed = false;
        let mut exprs = Vec::with_capacity(seq.exprs.len());
        for expr in &seq.exprs {
            if self.is_factory_module_read(strip_parens(expr)) {
                changed = true;
            } else {
                exprs.push(expr.clone());
            }
        }
        if !changed {
            return None;
        }
        match exprs.len() {
            0 => Some(vec![]),
            1 => Some(vec![Stmt::Expr(ExprStmt {
                span: DUMMY_SP,
                expr: exprs.pop().expect("single seq expr"),
            })]),
            _ => Some(vec![Stmt::Expr(ExprStmt {
                span: DUMMY_SP,
                expr: Box::new(Expr::Seq(SeqExpr {
                    span: seq.span,
                    exprs,
                })),
            })]),
        }
    }

    fn is_factory_module_read(&self, expr: &Expr) -> bool {
        matches!(expr, Expr::Ident(ident)
            if ident.sym.as_ref() == "module" && ident.ctxt.outer() == self.unresolved_mark)
    }

    /// The factory's own `module` binding in `module = require.nmd(module)`.
    /// A shadowing inner `module` parameter has a local context and keeps its
    /// write.
    fn factory_module_decorator_target(&self, expr: &Expr) -> Option<Ident> {
        if !self.is_module_decorator_assignment(strip_parens(expr)) {
            return None;
        }
        let Expr::Assign(AssignExpr {
            left: AssignTarget::Simple(SimpleAssignTarget::Ident(module)),
            ..
        }) = strip_parens(expr)
        else {
            return None;
        };
        (module.id.ctxt.outer() == self.unresolved_mark).then(|| module.id.clone())
    }

    fn is_module_decorator_assignment(&self, expr: &Expr) -> bool {
        let Expr::Assign(AssignExpr {
            op: AssignOp::Assign,
            left,
            right,
            ..
        }) = expr
        else {
            return false;
        };
        let AssignTarget::Simple(SimpleAssignTarget::Ident(left_ident)) = left else {
            return false;
        };
        if left_ident.id.sym.as_ref() != "module" {
            return false;
        }
        let Expr::Call(call) = &**right else {
            return false;
        };
        if call.args.len() != 1 {
            return false;
        }
        let Callee::Expr(callee_expr) = &call.callee else {
            return false;
        };
        let Expr::Member(MemberExpr { obj, prop, .. }) = &**callee_expr else {
            return false;
        };
        let Expr::Ident(callee_obj) = &**obj else {
            return false;
        };
        if callee_obj.sym != self.require_sym || callee_obj.ctxt.outer() != self.unresolved_mark {
            return false;
        }
        let MemberProp::Ident(prop_name) = prop else {
            return false;
        };
        if !matches!(prop_name.sym.as_ref(), "hmd" | "nmd") {
            return false;
        }
        let Expr::Ident(arg_ident) = &*call.args[0].expr else {
            return false;
        };
        arg_ident.sym.as_ref() == "module" && arg_ident.ctxt == left_ident.id.ctxt
    }
}

fn amd_define_detection_expr(ctxt: SyntaxContext) -> Expr {
    Expr::Bin(BinExpr {
        span: DUMMY_SP,
        op: BinaryOp::LogicalAnd,
        left: Box::new(Expr::Bin(BinExpr {
            span: DUMMY_SP,
            op: BinaryOp::EqEqEq,
            left: Box::new(Expr::Unary(UnaryExpr {
                span: DUMMY_SP,
                op: UnaryOp::TypeOf,
                arg: Box::new(Expr::Ident(Ident::new("define".into(), DUMMY_SP, ctxt))),
            })),
            right: Box::new(Expr::Lit(Lit::Str(Str {
                span: DUMMY_SP,
                value: "function".into(),
                raw: None,
            }))),
        })),
        right: Box::new(Expr::Member(MemberExpr {
            span: DUMMY_SP,
            obj: Box::new(Expr::Ident(Ident::new("define".into(), DUMMY_SP, ctxt))),
            prop: MemberProp::Ident(IdentName::new("amd".into(), DUMMY_SP)),
        })),
    })
}

pub fn detect_and_extract(source: &str) -> Option<UnpackResult> {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let module = super::parse_es_module(source, "webpack5.js", cm.clone()).ok()?;
        detect_from_module_prepared(&module, cm, SourcePositions::Discard)?
            .materialize()
            .ok()
    })
}

pub(super) fn detect_from_module_prepared(
    module: &Module,
    cm: Lrc<SourceMap>,
    positions: SourcePositions,
) -> Option<DetectedBundle> {
    let span = tracing::info_span!("webpack5: detect_from_module");
    let _enter = span.enter();
    for (idx, item) in module.body.iter().enumerate() {
        let ModuleItem::Stmt(Stmt::Expr(ExprStmt { expr, .. })) = item else {
            continue;
        };
        let Some(bootstrap_body) = extract_iife_body(expr) else {
            continue;
        };
        if let Some(result) = extract_webpack5_modules_with_plan(
            bootstrap_body,
            cm.clone(),
            None,
            positions,
            SurroundingItems::around(&module.body, idx),
        ) {
            return Some(result);
        }
    }
    // Fallback: `output.iife: false` and `experiments.outputModule` emit the
    // bootstrap statements at the top level instead of inside an IIFE.
    detect_webpack5_top_level(module, cm, positions)
}

/// Detect an unwrapped webpack 5 bootstrap (no IIFE): the modules container,
/// require function, runtime, and entry all sit at the file's top level. This
/// is `output.iife: false` (script/CommonJS output).
///
/// `experiments.outputModule` also drops the IIFE, but emits top-level ESM
/// `import`/`export` declarations that carry the library's public surface.
/// Recovering those faithfully needs harmony-export reconstruction the driver
/// pipeline does not yet do, so a bundle with any top-level `ModuleDecl` is
/// left untouched rather than extracted into an entry that silently loses its
/// exports.
fn detect_webpack5_top_level(
    module: &Module,
    cm: Lrc<SourceMap>,
    positions: SourcePositions,
) -> Option<DetectedBundle> {
    // This fallback runs for every input the IIFE scan rejects, so decide by
    // reference before cloning anything: bail on any top-level ModuleDecl and
    // find the modules container in the same pass.
    let mut modules_sym: Option<Atom> = None;
    for item in &module.body {
        match item {
            ModuleItem::ModuleDecl(_) => return None,
            ModuleItem::Stmt(Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl))) => {
                if modules_sym.is_none() {
                    if let Some((_, sym)) = extract_webpack_modules_container(var_decl, false) {
                        modules_sym = Some(sym);
                    }
                }
            }
            ModuleItem::Stmt(_) => {}
        }
    }
    let modules_sym = modules_sym?;

    let stmts: Vec<Stmt> = module
        .body
        .iter()
        .filter_map(|item| match item {
            ModuleItem::Stmt(stmt) => Some(stmt.clone()),
            ModuleItem::ModuleDecl(_) => None,
        })
        .collect();

    // Guard against arbitrary top-level function tables: require a proven
    // webpack require lifecycle for the container. The plan is reused by
    // entry extraction below.
    let require_plan = plan_webpack_require_fn(&stmts, &modules_sym)?;

    let bootstrap_body = swc_core::ecma::ast::FunctionBody {
        span: DUMMY_SP,
        stmts,
    };
    extract_webpack5_modules_with_plan(
        &bootstrap_body,
        cm,
        Some(require_plan),
        positions,
        SurroundingItems::default(),
    )
}

pub(super) fn detect_runtime_entry_from_module(
    module: &Module,
    source: &str,
) -> Option<UnpackResult> {
    for item in &module.body {
        let ModuleItem::Stmt(Stmt::Expr(ExprStmt { expr, .. })) = item else {
            continue;
        };
        let Some(bootstrap_body) = extract_iife_body(expr) else {
            continue;
        };
        if is_webpack5_runtime_entry_body(bootstrap_body) {
            return Some(UnpackResult::new(
                vec![UnpackedModule {
                    id: "entry".to_string(),
                    is_entry: true,
                    code: source.to_string(),
                    filename: "entry.js".to_string(),
                    source_ranges: vec![(0, source.len() as u32)],
                    inspection_context_ranges: Vec::new(),
                    source_input: String::new(),
                    generated_source_map: Vec::new(),
                    verbatim_source_offset: Some(0),
                    mapped_in_every_mode: false,
                }],
                BundleFormat::Webpack5,
            ));
        }
    }
    None
}

/// Detect and extract modules from a webpack5 JSONP chunk format:
/// `(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[chunkIds], {modules}])`
pub fn detect_and_extract_chunk(source: &str) -> Option<UnpackResult> {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let module = super::parse_es_module(source, "webpack5.js", cm.clone()).ok()?;
        detect_chunk_from_module_prepared(&module, cm)?
            .materialize()
            .ok()
    })
}

pub(crate) fn detect_chunk_ids_from_module(module: &Module) -> HashSet<usize> {
    let mut ids = HashSet::default();
    for item in &module.body {
        let ModuleItem::Stmt(Stmt::Expr(ExprStmt { expr, .. })) = item else {
            continue;
        };
        if let Some((chunk_ids, _)) = extract_chunk_push_parts(expr) {
            ids.extend(numeric_ids_from_array(chunk_ids));
        }
        ids.extend(extract_commonjs_chunk_ids(expr));
    }
    ids
}

pub(super) fn detect_chunk_from_module_prepared(
    module: &Module,
    cm: Lrc<SourceMap>,
) -> Option<DetectedBundle> {
    let span = tracing::info_span!("webpack5: detect_chunk_from_module");
    let _enter = span.enter();
    let mut all_modules = Vec::new();
    let mut all_prepared = Vec::new();
    let mut all_failures = HashMap::default();
    let mut all_numeric_module_ids = HashMap::default();
    let mut all_legacy_module_i = HashSet::default();

    for item in &module.body {
        let ModuleItem::Stmt(Stmt::Expr(ExprStmt { expr, .. })) = item else {
            continue;
        };
        if let Some(modules_container) = extract_chunk_push_modules(expr) {
            let extracted = extract_modules_from_container(&modules_container, cm.clone())?;
            if is_legacy_webpack_jsonp_push(expr) {
                all_legacy_module_i.extend(extracted.numeric_module_ids.keys().cloned());
            }
            all_modules.extend(extracted.modules);
            all_prepared.extend(extracted.prepared);
            all_failures.extend(extracted.failures);
            all_numeric_module_ids.extend(extracted.numeric_module_ids);
        } else if let Some(modules_container) = extract_commonjs_chunk_modules(expr) {
            let extracted = extract_modules_from_container(&modules_container, cm.clone())?;
            all_modules.extend(extracted.modules);
            all_prepared.extend(extracted.prepared);
            all_failures.extend(extracted.failures);
            all_numeric_module_ids.extend(extracted.numeric_module_ids);
        }
    }

    if all_modules.is_empty() || all_prepared.iter().all(Option::is_none) {
        // Preserve the historical whole-input fallback when no factory across
        // the complete chunk remains trustworthy.
        return None;
    }

    Some(
        DetectedBundle::new(
            // A standalone chunk has no in-file runtime: its modules are
            // registered for consumption by runtimes in other physical assets,
            // so dead-module elimination must fail closed for them.
            UnpackResult::new(all_modules, BundleFormat::Webpack5).with_external_consumers(),
            all_prepared,
            cm,
        )
        .with_module_failures(all_failures)
        .with_webpack_numeric_module_ids(all_numeric_module_ids)
        .with_webpack_legacy_module_i(all_legacy_module_i),
    )
}

/// The webpack 5 modules container. Usually an object keyed by module id, but
/// `Template.getModulesArrayBounds` switches to a sparse array (indices are
/// the ids) when ids are dense numerics, wrapped in `Array(minId).concat([...])`
/// when the smallest id is non-zero.
enum Webpack5ModulesContainer<'a> {
    Object(&'a ObjectLit),
    Array {
        array: &'a ArrayLit,
        id_offset: usize,
    },
}

impl<'a> Webpack5ModulesContainer<'a> {
    fn from_expr(expr: &'a Expr) -> Option<Self> {
        match strip_parens(expr) {
            Expr::Object(object_lit) => {
                is_valid_modules_object(object_lit)?;
                Some(Self::Object(object_lit))
            }
            Expr::Array(array) => {
                is_valid_modules_array(array)?;
                Some(Self::Array {
                    array,
                    id_offset: 0,
                })
            }
            Expr::Call(call) => {
                let (array, id_offset) = split_array_concat(call)?;
                is_valid_modules_array(array)?;
                Some(Self::Array { array, id_offset })
            }
            _ => None,
        }
    }

    /// A bootstrap's own table may be empty: webpack 5 production
    /// concatenates dependency-free application code into the runtime and
    /// emits `var r = {}`, with modules only arriving from chunks. Callers
    /// still require the proven require lifecycle for this table and an
    /// extracted entry. Chunk containers stay non-empty.
    fn from_bootstrap_expr(expr: &'a Expr) -> Option<Self> {
        match strip_parens(expr) {
            Expr::Object(object_lit) if object_lit.props.is_empty() => {
                Some(Self::Object(object_lit))
            }
            _ => Self::from_expr(expr),
        }
    }

    fn is_empty_object(&self) -> bool {
        matches!(self, Self::Object(object_lit) if object_lit.props.is_empty())
    }

    fn entry_count(&self) -> usize {
        match self {
            Self::Object(object_lit) => object_lit.props.len(),
            Self::Array { array, .. } => array.elems.len(),
        }
    }
}

/// Whether the bootstrap contains a webpack require function for `modules_sym`.
///
/// Merely calling a computed member of the table (`handlers[i](event)`) is not
/// enough — ordinary dispatch tables do that, and a *mutating* dispatcher even
/// pairs a table call with a returned `.exports` member
/// (`handlers[i](context); return context.exports;`). The require function is
/// identified by three structural facts tied to one binding `m` inside one
/// function scope, webpack's module lifecycle:
///
/// 1. `m` is created as a *module-cache write* — an object literal carrying an
///    `exports` property, written into a cache under the id being required
///    (`var m = cache[id] = { exports: {} }`),
/// 2. `m` (or `m.exports`) is passed to the table invocation *indexed by the
///    same id binding* (`modules[id](m, m.exports, require)` /
///    `modules[id].call(...)`),
/// 3. a return yields `m.exports`.
///
/// The cache write and the shared index are what make the proof
/// producer-specific: webpack's generated require always memoizes the module
/// object under `moduleId` and invokes the factory under the same `moduleId`.
/// A dispatcher allocating a bare `var context = { exports: {} }` and passing
/// it to `handlers[i](context)` has no cache write, so it fails fact 1 even
/// though it creates the object locally; a dispatcher whose context is a
/// caller-supplied parameter fails it too. The lifecycle holds regardless of
/// how the require function is written (declaration, expression, minified)
/// and admits zero-parameter factories — webpack's shared call site always
/// passes the module object even when factories declare no params.
///
/// The *entire region* is resolved once (see [`resolve_probe`]) and the table
/// is identified by the resolved [`Id`] of its declaration — not by name — so
/// any binding that shadows the table's name at any depth (a parameter, a
/// named function expression's self-binding, a class expression's name, an
/// enclosing function's parameter captured by a closure) is a different
/// identity and never mistaken for the table.
///
/// Candidates are the region-level declarations and directly invoked
/// functions webpack emits its require lifecycle as (see
/// [`region_fn_candidates`]). The returned plan carries either its declaration
/// boundary or the directly supplied entry id. Entry extraction consumes the
/// same plan instead of rediscovering the require function with a weaker
/// model.
fn plan_webpack_require_fn(stmts: &[Stmt], modules_sym: &Atom) -> Option<RequireFnPlan> {
    // Cheap symbol-level early-out before cloning + resolving the region.
    if !region_invokes_table(stmts, modules_sym) {
        return None;
    }
    let (probe_stmts, unresolved_ctxt) = resolve_probe(stmts)?;
    // The modules container is always a region-level var declaration; its
    // resolved identity is what candidates must invoke.
    let table_id = region_level_binding_id(&probe_stmts, modules_sym)?;
    region_fn_candidates(&probe_stmts)
        .into_iter()
        .find(|candidate| {
            body_is_webpack_require(&candidate.excluded, candidate.body, &table_id)
                && direct_entry_is_movable(&probe_stmts, candidate, &table_id, unresolved_ctxt)
        })
        .map(|candidate| match candidate.kind {
            RegionFnCandidateKind::Declared(sym) => RequireFnPlan::Declared {
                stmt_idx: candidate.stmt_idx,
                sym,
            },
            RegionFnCandidateKind::DirectEntry { entry_id, site } => RequireFnPlan::DirectEntry {
                entry_id,
                stmt_idx: candidate.stmt_idx,
                site,
            },
        })
}

/// The entry code after a directly invoked require (its consumer and every
/// statement after it, see [`direct_entry_stmts`]) moves to entry.js only when
/// it means the same there: it shares no bootstrap binding with the runtime
/// left behind, and it does not observe the bootstrap function (`this`,
/// `arguments`, a `return`). Dropping that code would lose authored behavior
/// (a library's exports, the call that starts the app), so a bundle whose
/// entry code cannot move stays unsplit instead.
fn direct_entry_is_movable(
    probe_stmts: &[Stmt],
    candidate: &RegionFnCandidate<'_>,
    table_id: &Id,
    unresolved_ctxt: SyntaxContext,
) -> bool {
    let RegionFnCandidateKind::DirectEntry { site, .. } = candidate.kind else {
        return true;
    };
    let Some(moved) = direct_entry_stmts(probe_stmts, candidate.stmt_idx, site, unresolved_ctxt)
    else {
        return false;
    };
    if stmts_have_function_level_special_bindings(&moved)
        || stmts_have_function_level_return(&moved)
    {
        return false;
    }
    let Some(site_stmt) = probe_stmts.get(candidate.stmt_idx) else {
        return false;
    };
    let Some(call) = direct_entry_call(site_stmt, site) else {
        return false;
    };

    // Region-level bindings all carry the table's context. One spelled in
    // both the moved code and what stays behind (the statements before the
    // call site, the require function, earlier declarators of the site) is
    // shared with the runtime.
    let mut runtime = ContextSymCollector::new(table_id.1);
    probe_stmts[..candidate.stmt_idx].visit_with(&mut runtime);
    call.callee.visit_with(&mut runtime);
    if let (
        DirectEntrySite::Declarator(decl_idx),
        Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)),
    ) = (site, site_stmt)
    {
        var_decl.decls[..decl_idx].visit_with(&mut runtime);
    }
    let mut entry = ContextSymCollector::new(table_id.1);
    moved.visit_with(&mut entry);
    entry.syms.is_disjoint(&runtime.syms)
}

/// How the bootstrap exposes its proven webpack require lifecycle.
enum RequireFnPlan {
    /// A region-level declaration followed by a separate startup program.
    /// Statement indices refer to the probed region; [`resolve_probe`] clones
    /// statements in order, so they are valid for the original region.
    Declared { stmt_idx: usize, sym: Atom },
    /// A require function invoked directly with the entry module id:
    /// `!function require(id) { ... }(entryId)`. `stmt_idx` is the statement
    /// holding the call.
    DirectEntry {
        entry_id: String,
        stmt_idx: usize,
        site: DirectEntrySite,
    },
}

/// Where a directly invoked require call sits in its statement.
#[derive(Clone, Copy)]
enum DirectEntrySite {
    /// The statement's expression: a bare or `!`-prefixed call, or the
    /// right side of an assignment (`window.lib = function r(id) {...}(1)`).
    Expr,
    /// One element of the statement's comma sequence.
    SeqElement(usize),
    /// The initializer of the statement's declarator at this index
    /// (`var lib = function r(id) {...}(1)`).
    Declarator(usize),
}

/// Resolved [`Id`] of the region-level `var` declarator binding `sym`.
fn region_level_binding_id(stmts: &[Stmt], sym: &Atom) -> Option<Id> {
    stmts.iter().find_map(|stmt| {
        let Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) = stmt else {
            return None;
        };
        var_decl.decls.iter().find_map(|declarator| {
            let Pat::Ident(binding) = &declarator.name else {
                return None;
            };
            (binding.id.sym == *sym).then(|| binding.id.to_id())
        })
    })
}

/// If `expr` is `<ident>[<computed>]`, return the base ident and the index
/// expression (parens stripped).
fn computed_index_parts(expr: &Expr) -> Option<(&Ident, &Expr)> {
    let Expr::Member(MemberExpr { obj, prop, .. }) = expr else {
        return None;
    };
    let MemberProp::Computed(computed) = prop else {
        return None;
    };
    match strip_parens(obj) {
        Expr::Ident(ident) => Some((ident, strip_parens(&computed.expr))),
        _ => None,
    }
}

/// If `call` invokes a computed member of a table — `table[id](...)` or
/// `table[id].call(...)` — return the table's base ident and the index
/// expression.
fn table_invocation_parts(call: &CallExpr) -> Option<(&Ident, &Expr)> {
    let Callee::Expr(callee) = &call.callee else {
        return None;
    };
    let callee = strip_parens(callee);
    if let Some(parts) = computed_index_parts(callee) {
        return Some(parts);
    }
    let Expr::Member(MemberExpr { obj, prop, .. }) = callee else {
        return None;
    };
    if !matches!(prop, MemberProp::Ident(ident) if ident.sym.as_ref() == "call") {
        return None;
    }
    computed_index_parts(strip_parens(obj))
}

/// If `call` invokes a computed member of a table, return the table's base
/// ident.
fn table_invocation_base(call: &CallExpr) -> Option<&Ident> {
    table_invocation_parts(call).map(|(base, _)| base)
}

/// If `expr` is (or, for a sequence, ends in) an `<ident>.exports` member
/// access — webpack's `return module.exports` /
/// `return factory(...), module.exports` — return the object's ident.
fn exports_member_object_ident(expr: &Expr) -> Option<&Ident> {
    match strip_parens(expr) {
        Expr::Member(MemberExpr { obj, prop, .. }) => {
            if !matches!(prop, MemberProp::Ident(ident) if ident.sym.as_ref() == "exports") {
                return None;
            }
            match strip_parens(obj) {
                Expr::Ident(ident) => Some(ident),
                _ => None,
            }
        }
        Expr::Seq(seq) => seq
            .exprs
            .last()
            .and_then(|last| exports_member_object_ident(last)),
        _ => None,
    }
}

/// If `expr` is webpack's chained module-cache write ending in a module
/// object literal — `cache[id] = { exports: {} }`, possibly nested inside
/// further plain assignments — return the resolved identity of the `id`
/// binding indexing the cache.
///
/// webpack's require function never creates the module object bare: it is
/// always written into the module cache under the id being required
/// (`var module = cache[moduleId] = { exports: {} }` in webpack 5,
/// `installedModules[moduleId] = { i: moduleId, ... }` in webpack 4). An
/// ordinary dispatcher allocating a plain `var context = { exports: {} }`
/// has no cache write and yields no index here.
fn module_object_cache_index(expr: &Expr) -> Option<Id> {
    let Expr::Assign(assign) = strip_parens(expr) else {
        return None;
    };
    if assign.op != AssignOp::Assign || !is_module_object_literal(&assign.right) {
        return None;
    }
    let index = match &assign.left {
        AssignTarget::Simple(SimpleAssignTarget::Member(member)) => match &member.prop {
            MemberProp::Computed(computed) => match strip_parens(&computed.expr) {
                Expr::Ident(ident) => Some(ident.to_id()),
                _ => None,
            },
            _ => None,
        },
        _ => None,
    };
    index.or_else(|| module_object_cache_index(&assign.right))
}

/// `expr` (after stripping parens and chained assignments like
/// `cache[id] = { exports: {} }`) is an object literal with an `exports`
/// property — webpack's freshly-created module object. Covers webpack 5's
/// `{ exports: {} }` and webpack 4's `{ i: id, l: false, exports: {} }`.
fn is_module_object_literal(expr: &Expr) -> bool {
    match strip_parens(expr) {
        Expr::Assign(assign) => is_module_object_literal(&assign.right),
        Expr::Object(object) => object.props.iter().any(|prop| match prop {
            PropOrSpread::Prop(prop) => match prop.as_ref() {
                Prop::KeyValue(kv) => match &kv.key {
                    PropName::Ident(ident) => ident.sym.as_ref() == "exports",
                    PropName::Str(s) => s.value.as_str() == Some("exports"),
                    _ => false,
                },
                Prop::Shorthand(ident) => ident.sym.as_ref() == "exports",
                _ => false,
            },
            PropOrSpread::Spread(_) => false,
        }),
        _ => false,
    }
}

enum RegionFnCandidateKind {
    Declared(Atom),
    DirectEntry {
        entry_id: String,
        site: DirectEntrySite,
    },
}

/// A region-level require-function candidate. Webpack emits either a function
/// declaration / variable-bound function or a function expression invoked
/// directly with the entry module id.
struct RegionFnCandidate<'a> {
    /// Index of the candidate statement in the region.
    stmt_idx: usize,
    kind: RegionFnCandidateKind,
    /// Caller-facing bindings: parameters and, for a named function
    /// expression, its self-binding. Neither may carry the creation fact.
    excluded: HashSet<Id>,
    body: &'a [Stmt],
}

/// Collect region-level require-function candidates from `stmts`, in order.
/// Detection ([`plan_webpack_require_fn`]) and loose entry-extraction discovery
/// ([`find_webpack5_require_fn`]) draw declared candidates from here, so their
/// supported declaration shapes cannot drift apart.
fn region_fn_candidates(stmts: &[Stmt]) -> Vec<RegionFnCandidate<'_>> {
    let mut candidates = Vec::new();
    for (stmt_idx, stmt) in stmts.iter().enumerate() {
        match stmt {
            Stmt::Decl(swc_core::ecma::ast::Decl::Fn(fn_decl)) => {
                let Some(body) = &fn_decl.function.body else {
                    continue;
                };
                let mut excluded: HashSet<Id> = HashSet::default();
                for param in &fn_decl.function.params {
                    collect_pat_binding_ids(&param.pat, &mut excluded);
                }
                candidates.push(RegionFnCandidate {
                    stmt_idx,
                    kind: RegionFnCandidateKind::Declared(fn_decl.ident.sym.clone()),
                    excluded,
                    body: &body.stmts,
                });
            }
            Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) => {
                for (decl_idx, declarator) in var_decl.decls.iter().enumerate() {
                    let Pat::Ident(binding) = &declarator.name else {
                        continue;
                    };
                    let Some(init) = &declarator.init else {
                        continue;
                    };
                    match strip_parens(init) {
                        Expr::Fn(fn_expr) => {
                            let Some(body) = &fn_expr.function.body else {
                                continue;
                            };
                            let mut excluded: HashSet<Id> = HashSet::default();
                            for param in &fn_expr.function.params {
                                collect_pat_binding_ids(&param.pat, &mut excluded);
                            }
                            if let Some(self_ident) = &fn_expr.ident {
                                excluded.insert(self_ident.to_id());
                            }
                            candidates.push(RegionFnCandidate {
                                stmt_idx,
                                kind: RegionFnCandidateKind::Declared(binding.id.sym.clone()),
                                excluded,
                                body: &body.stmts,
                            });
                        }
                        Expr::Arrow(arrow) => {
                            let ArrowFunctionBody::FunctionBody(body) = &*arrow.body else {
                                continue;
                            };
                            let mut excluded: HashSet<Id> = HashSet::default();
                            for pat in &arrow.params {
                                collect_pat_binding_ids(pat, &mut excluded);
                            }
                            candidates.push(RegionFnCandidate {
                                stmt_idx,
                                kind: RegionFnCandidateKind::Declared(binding.id.sym.clone()),
                                excluded,
                                body: &body.stmts,
                            });
                        }
                        // `var lib = function require(id) { ... }(entryId)` —
                        // a library build binding the entry's exports.
                        Expr::Call(call) => {
                            if let Some(candidate) = require_candidate_from_call(
                                stmt_idx,
                                call,
                                DirectEntrySite::Declarator(decl_idx),
                            ) {
                                candidates.push(candidate);
                            }
                        }
                        _ => {}
                    }
                }
            }
            _ => candidates.extend(directly_invoked_require_candidates(stmt_idx, stmt)),
        }
    }
    candidates
}

fn directly_invoked_require_candidates(stmt_idx: usize, stmt: &Stmt) -> Vec<RegionFnCandidate<'_>> {
    let Stmt::Expr(ExprStmt { expr, .. }) = stmt else {
        return Vec::new();
    };
    // Terser merges an `output.library` startup into one comma sequence
    // (`sink = function require(id) {...}(1), module.exports = {}`); each
    // element can hold the call.
    if let Expr::Seq(seq) = strip_parens(expr) {
        return seq
            .exprs
            .iter()
            .enumerate()
            .filter_map(|(idx, element)| {
                require_candidate_from_call(
                    stmt_idx,
                    direct_invoke_call(element)?,
                    DirectEntrySite::SeqElement(idx),
                )
            })
            .collect();
    }
    direct_invoke_call(expr)
        .and_then(|call| require_candidate_from_call(stmt_idx, call, DirectEntrySite::Expr))
        .into_iter()
        .collect()
}

/// Unwrap a directly invoked require expression to its call. Besides the bare
/// and `!`-prefixed statement forms, `output.library` builds consume the
/// entry's exports — `window.lib = function require(id) { ... }(entryId)` —
/// so assignment right-hand sides are unwrapped too.
fn direct_invoke_call(expr: &Expr) -> Option<&CallExpr> {
    match strip_parens(expr) {
        Expr::Call(call) => Some(call),
        Expr::Unary(unary) if unary.op == UnaryOp::Bang => match strip_parens(&unary.arg) {
            Expr::Call(call) => Some(call),
            _ => None,
        },
        Expr::Assign(assign) if assign.op == AssignOp::Assign => direct_invoke_call(&assign.right),
        _ => None,
    }
}

fn require_candidate_from_call(
    stmt_idx: usize,
    call: &CallExpr,
    site: DirectEntrySite,
) -> Option<RegionFnCandidate<'_>> {
    if call.args.len() != 1 || call.args[0].spread.is_some() {
        return None;
    }
    let entry_id = module_id_literal(&call.args[0].expr)?;
    let Callee::Expr(callee) = &call.callee else {
        return None;
    };

    let mut excluded = HashSet::default();
    let body = match strip_parens(callee) {
        Expr::Fn(fn_expr) => {
            for param in &fn_expr.function.params {
                collect_pat_binding_ids(&param.pat, &mut excluded);
            }
            if let Some(self_ident) = &fn_expr.ident {
                excluded.insert(self_ident.to_id());
            }
            &fn_expr.function.body.as_ref()?.stmts
        }
        Expr::Arrow(arrow) => {
            for pat in &arrow.params {
                collect_pat_binding_ids(pat, &mut excluded);
            }
            let ArrowFunctionBody::FunctionBody(body) = &*arrow.body else {
                return None;
            };
            &body.stmts
        }
        _ => return None,
    };

    Some(RegionFnCandidate {
        stmt_idx,
        kind: RegionFnCandidateKind::DirectEntry { entry_id, site },
        excluded,
        body,
    })
}

fn module_id_literal(expr: &Expr) -> Option<String> {
    match strip_parens(expr) {
        Expr::Lit(Lit::Num(number)) => Some(format!("{}", number.value as i64)),
        Expr::Lit(Lit::Str(string)) => Some(string.value.as_str().unwrap_or("unknown").to_string()),
        _ => None,
    }
}

/// Whether one function body is a webpack require function: some binding is
/// created locally via a module-cache write (`m = cache[id] = {exports: {}}`),
/// passed to the module-table invocation indexed by the same `id` binding,
/// and has its `.exports` returned (see [`plan_webpack_require_fn`]). The
/// invocation may be direct (`table[id](...)`, with or without `.call`) or
/// through the `interceptModuleExecution` factory holder of HMR builds
/// (`{ factory: table[id] }` invoked as `holder.factory.call(...)`).
/// Nested function scopes are not descended into, so facts from an unrelated
/// inner function cannot combine to look like a require function.
///
/// Facts are keyed by resolved binding identity ([`Id`]), not identifier
/// text: an inner block-local `const context = { exports: {} }` must not
/// supply the creation fact for a same-named outer parameter that a
/// dispatcher invokes the table with and returns `.exports` from. `stmts` are
/// already resolved (the whole region is resolved once by
/// [`plan_webpack_require_fn`]); `excluded` carries the candidate's
/// caller-facing bindings — parameters (including their same-name `var`
/// redeclarations, which share the binding) and a named function expression's
/// self-binding — which can never carry the creation fact.
///
/// The creation fact must target a binding the candidate *owns*: whole-region
/// resolution means "resolved" alone only proves the binding lives somewhere
/// in the bootstrap, and webpack's module object is always the require
/// function's own variable — an assignment into an enclosing region binding
/// (`var context; function dispatch(i) { context = { exports: {} }; ... }`)
/// is a dispatcher mutating shared state, not the module lifecycle. Declarator
/// initializers are body-owned by construction (the scanner never descends
/// into nested functions); assignment targets are checked against the body's
/// own declared bindings.
fn body_is_webpack_require(excluded: &HashSet<Id>, stmts: &[Stmt], table_id: &Id) -> bool {
    let mut body_declared = HashSet::default();
    let mut collector = BodyVarCollector {
        ids: &mut body_declared,
    };
    stmts.visit_with(&mut collector);
    let mut scanner = RequireBodyScanner {
        table_id,
        excluded,
        body_declared: &body_declared,
        local_modules: HashMap::default(),
        table_call_args: HashSet::default(),
        returned_exports_objs: HashSet::default(),
        factory_holders: HashMap::default(),
    };
    stmts.visit_with(&mut scanner);
    scanner.local_modules.iter().any(|(module, cache_index)| {
        scanner.returned_exports_objs.contains(module)
            && scanner
                .table_call_args
                .contains(&(module.clone(), cache_index.clone()))
    })
}

/// Collects the binding [`Id`]s declared by the body's own statements
/// (without descending into nested functions — their locals belong to them).
struct BodyVarCollector<'a> {
    ids: &'a mut HashSet<Id>,
}

impl Visit for BodyVarCollector<'_> {
    // Stay within this function's own scope.
    fn visit_function(&mut self, _function: &swc_core::ecma::ast::Function) {}
    fn visit_arrow_expr(&mut self, _arrow: &swc_core::ecma::ast::ArrowExpr) {}

    fn visit_var_declarator(&mut self, declarator: &VarDeclarator) {
        declarator.visit_children_with(self);
        collect_pat_binding_ids(&declarator.name, self.ids);
    }
}

/// Clone `stmts` into a synthetic function and run the swc resolver over the
/// clone, so every identifier carries a real binding identity ([`Id`]).
/// Detection runs on pre-resolver ASTs whose `SyntaxContext`s are empty, and
/// structural shadow tracking proved incomplete one lexical construct at a
/// time (nested functions, then blocks/catch/for heads, then named class
/// expressions, then function-expression self-bindings) — hygiene marks
/// handle every scope uniformly, at every nesting depth, provided the WHOLE
/// region containing all relevant declarations is resolved together.
/// Bindings declared outside `stmts` resolve to the returned unresolved
/// context.
fn resolve_probe(stmts: &[Stmt]) -> Option<(Vec<Stmt>, SyntaxContext)> {
    GLOBALS.set(&Default::default(), || {
        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        let probe_fn = swc_core::ecma::ast::Function {
            params: Vec::new(),
            decorators: Vec::new(),
            span: DUMMY_SP,
            ctxt: SyntaxContext::empty(),
            this_param: None,
            body: Some(swc_core::ecma::ast::FunctionBody {
                span: DUMMY_SP,
                stmts: stmts.to_vec(),
            }),
            is_generator: false,
            is_async: false,
            type_params: None,
            return_type: None,
        };
        let mut probe = Module {
            span: DUMMY_SP,
            body: vec![ModuleItem::Stmt(Stmt::Decl(swc_core::ecma::ast::Decl::Fn(
                swc_core::ecma::ast::FnDecl {
                    ident: Ident::new(
                        Atom::from("__wakaru_probe__"),
                        DUMMY_SP,
                        SyntaxContext::empty(),
                    ),
                    declare: false,
                    function: Box::new(probe_fn),
                },
            )))],
            shebang: None,
        };
        probe.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));
        let ModuleItem::Stmt(Stmt::Decl(swc_core::ecma::ast::Decl::Fn(fn_decl))) =
            probe.body.pop()?
        else {
            return None;
        };
        let body = fn_decl.function.body?;
        Some((
            body.stmts,
            SyntaxContext::empty().apply_mark(unresolved_mark),
        ))
    })
}

/// Collect the binding [`Id`]s a (possibly destructuring) pattern declares.
fn collect_pat_binding_ids(pat: &Pat, ids: &mut HashSet<Id>) {
    use swc_core::ecma::ast::ObjectPatProp;
    match pat {
        Pat::Ident(binding) => {
            ids.insert(binding.id.to_id());
        }
        Pat::Array(array) => array
            .elems
            .iter()
            .flatten()
            .for_each(|elem| collect_pat_binding_ids(elem, ids)),
        Pat::Rest(rest) => collect_pat_binding_ids(&rest.arg, ids),
        Pat::Object(object) => object.props.iter().for_each(|prop| match prop {
            ObjectPatProp::KeyValue(kv) => collect_pat_binding_ids(&kv.value, ids),
            ObjectPatProp::Assign(assign) => {
                ids.insert(assign.key.to_id());
            }
            ObjectPatProp::Rest(rest) => collect_pat_binding_ids(&rest.arg, ids),
        }),
        Pat::Assign(assign) => collect_pat_binding_ids(&assign.left, ids),
        Pat::Invalid(_) | Pat::Expr(_) => {}
    }
}

/// Cheap symbol-level prefilter for [`plan_webpack_require_fn`]: does the
/// region invoke `modules_sym` as a table anywhere (at any nesting depth)?
/// Avoids cloning + resolving regions that cannot possibly match.
fn region_invokes_table(stmts: &[Stmt], modules_sym: &Atom) -> bool {
    invoked_table_syms(stmts).contains(modules_sym)
}

/// Every symbol the region invokes as a table, collected in one walk so a
/// caller testing many candidates does not rescan the region per candidate.
fn invoked_table_syms(stmts: &[Stmt]) -> HashSet<Atom> {
    let mut finder = TableInvocationFinder::default();
    stmts.visit_with(&mut finder);
    finder.syms
}

#[derive(Default)]
struct TableInvocationFinder {
    syms: HashSet<Atom>,
}

impl Visit for TableInvocationFinder {
    fn visit_call_expr(&mut self, call: &CallExpr) {
        call.visit_children_with(self);
        if let Some(base) = table_invocation_base(call) {
            self.syms.insert(base.sym.clone());
        }
    }

    // webpack's `interceptModuleExecution` runtime (HMR builds) never calls
    // the table directly: it reads `factory: table[id]` into an options
    // object and invokes `execOptions.factory.call(...)`. Accept a computed
    // table read stored as an object-literal property value as potential
    // invocation evidence; the full scanner still has to join it with the
    // cache-write and exports-return facts.
    fn visit_key_value_prop(&mut self, kv: &KeyValueProp) {
        kv.visit_children_with(self);
        if let Some((base, _)) = computed_index_parts(strip_parens(&kv.value)) {
            self.syms.insert(base.sym.clone());
        }
    }
}

struct RequireBodyScanner<'a> {
    /// Resolved identity of the modules-table binding.
    table_id: &'a Id,
    /// The candidate's caller-facing bindings (parameters, fn-expr
    /// self-binding) — these must never carry the creation fact.
    excluded: &'a HashSet<Id>,
    /// Bindings declared by the body's own statements — the only ones an
    /// assignment-based creation fact may target.
    body_declared: &'a HashSet<Id>,
    /// Bindings created via a module-cache write
    /// (`m = cache[id] = { exports: ... }`), mapped to the resolved identity
    /// of the cache index binding `id`.
    local_modules: HashMap<Id, Id>,
    /// (binding, invocation index) pairs: the binding was passed (bare or as
    /// `<ident>.exports`) to a `table[index](...)` invocation.
    table_call_args: HashSet<(Id, Id)>,
    /// Bindings whose `.exports` member a return statement yields.
    returned_exports_objs: HashSet<Id>,
    /// (holder binding, property name) pairs holding a factory read from the
    /// table — `var execOptions = { factory: table[id], ... }` — mapped to
    /// the resolved identity of the index binding `id`. webpack's
    /// `interceptModuleExecution` runtime (HMR builds) invokes the factory
    /// through this indirection instead of calling the table directly.
    factory_holders: HashMap<(Id, Atom), Id>,
}

impl RequireBodyScanner<'_> {
    /// Record `(holder, prop) → index` pairs for object-literal properties
    /// reading a factory out of the table: `{ factory: table[id], ... }`.
    fn record_factory_holders(&mut self, holder: &Id, init: &Expr) {
        let Expr::Object(object) = strip_parens(init) else {
            return;
        };
        for prop in &object.props {
            let PropOrSpread::Prop(prop) = prop else {
                continue;
            };
            let Prop::KeyValue(kv) = prop.as_ref() else {
                continue;
            };
            let name = match &kv.key {
                PropName::Ident(ident) => ident.sym.clone(),
                PropName::Str(s) => match s.value.as_str() {
                    Some(value) => Atom::from(value),
                    None => continue,
                },
                _ => continue,
            };
            let Some((base, index)) = computed_index_parts(strip_parens(&kv.value)) else {
                continue;
            };
            if base.to_id() != *self.table_id {
                continue;
            }
            let Expr::Ident(index_ident) = index else {
                continue;
            };
            self.factory_holders
                .insert((holder.clone(), name), index_ident.to_id());
        }
    }

    /// If `call` invokes a recorded factory holder — `holder.prop(...)` or
    /// `holder.prop.call(...)` — return the table index it was read with.
    fn factory_invocation_index(&self, call: &CallExpr) -> Option<Id> {
        let Callee::Expr(callee) = &call.callee else {
            return None;
        };
        let Expr::Member(member) = strip_parens(callee) else {
            return None;
        };
        if let Some(index) = self.holder_prop_index(member) {
            return Some(index);
        }
        if matches!(&member.prop, MemberProp::Ident(p) if p.sym.as_ref() == "call") {
            if let Expr::Member(inner) = strip_parens(&member.obj) {
                return self.holder_prop_index(inner);
            }
        }
        None
    }

    fn holder_prop_index(&self, member: &MemberExpr) -> Option<Id> {
        let Expr::Ident(holder) = strip_parens(&member.obj) else {
            return None;
        };
        let MemberProp::Ident(prop) = &member.prop else {
            return None;
        };
        self.factory_holders
            .get(&(holder.to_id(), prop.sym.clone()))
            .cloned()
    }

    fn record_table_call_args<'a>(&mut self, index: Id, args: impl Iterator<Item = &'a Expr>) {
        for arg in args {
            match strip_parens(arg) {
                Expr::Ident(ident) => {
                    self.table_call_args.insert((ident.to_id(), index.clone()));
                }
                expr => {
                    if let Some(ident) = exports_member_object_ident(expr) {
                        self.table_call_args.insert((ident.to_id(), index.clone()));
                    }
                }
            }
        }
    }
}

impl Visit for RequireBodyScanner<'_> {
    // Stay within this function's own scope.
    fn visit_function(&mut self, _function: &swc_core::ecma::ast::Function) {}
    fn visit_arrow_expr(&mut self, _arrow: &swc_core::ecma::ast::ArrowExpr) {}

    fn visit_var_declarator(&mut self, declarator: &VarDeclarator) {
        declarator.visit_children_with(self);
        let Pat::Ident(binding) = &declarator.name else {
            return;
        };
        if let Some(init) = &declarator.init {
            // A `var` redeclaration of a parameter shares the parameter's
            // binding — that is still a caller-supplied value, not a module
            // object created by this function.
            if !self.excluded.contains(&binding.id.to_id()) {
                if let Some(cache_index) = module_object_cache_index(init) {
                    self.local_modules.insert(binding.id.to_id(), cache_index);
                }
                self.record_factory_holders(&binding.id.to_id(), init);
            }
        }
    }

    fn visit_assign_expr(&mut self, assign: &AssignExpr) {
        assign.visit_children_with(self);
        if assign.op != AssignOp::Assign {
            return;
        }
        let AssignTarget::Simple(SimpleAssignTarget::Ident(binding)) = &assign.left else {
            return;
        };
        // Only a binding this body itself declares can carry the creation
        // fact — assigning a fresh object into a caller-supplied parameter,
        // an enclosing region binding, or a global is not webpack's
        // lifecycle. `body_declared` still admits minifier-hoisted
        // `var c; c = t[o] = ...`; `excluded` still rejects a `var`
        // redeclaration of a parameter (shared binding).
        if self.body_declared.contains(&binding.id.to_id())
            && !self.excluded.contains(&binding.id.to_id())
        {
            if let Some(cache_index) = module_object_cache_index(&assign.right) {
                self.local_modules.insert(binding.id.to_id(), cache_index);
            }
            self.record_factory_holders(&binding.id.to_id(), &assign.right);
        }
    }

    fn visit_call_expr(&mut self, call: &CallExpr) {
        call.visit_children_with(self);
        // The invoked table must be the *resolved* modules-table binding — a
        // shadow of its name at any depth (parameter, fn-expr self-binding,
        // class name) is a different identity. The invocation index must be a
        // plain binding so it can be compared with the cache-write index —
        // webpack's shared call site always indexes both with the same
        // `moduleId`.
        if let Some((base, index)) = table_invocation_parts(call) {
            if base.to_id() == *self.table_id {
                if let Expr::Ident(index_ident) = index {
                    self.record_table_call_args(
                        index_ident.to_id(),
                        call.args
                            .iter()
                            .filter_map(|arg| arg.spread.is_none().then_some(arg.expr.as_ref())),
                    );
                }
            }
        }
        // The `interceptModuleExecution` runtime invokes the factory through
        // a recorded holder (`execOptions.factory.call(...)`) instead of
        // calling the table directly. The holder is declared before this
        // invocation in every webpack emission, so recording during the same
        // in-order traversal is sufficient.
        if let Some(index) = self.factory_invocation_index(call) {
            self.record_table_call_args(
                index,
                call.args
                    .iter()
                    .filter_map(|arg| arg.spread.is_none().then_some(arg.expr.as_ref())),
            );
        }
    }

    fn visit_return_stmt(&mut self, ret: &swc_core::ecma::ast::ReturnStmt) {
        ret.visit_children_with(self);
        if let Some(arg) = &ret.arg {
            if let Some(ident) = exports_member_object_ident(arg) {
                self.returned_exports_objs.insert(ident.to_id());
            }
        }
    }
}

/// Match the pattern: `(self.X = self.X || []).push([[ids], {modules}])`
/// or `(window["X"] = window["X"] || []).push([[ids], {modules}])`.
/// The modules payload may also be a sparse array — see
/// [`Webpack5ModulesContainer`].
fn extract_chunk_push_modules(expr: &Expr) -> Option<Webpack5ModulesContainer<'_>> {
    extract_chunk_push_parts(expr).map(|(_, modules)| modules)
}

/// Webpack 4's default JSONP receiver begins with `webpackJsonp`, and its
/// production module object exposes the numeric id as `module.i`. The generic
/// chunk detector also accepts modern/custom push receivers, so keep this
/// legacy fact separate instead of treating every `.i` read as an id.
fn is_legacy_webpack_jsonp_push(expr: &Expr) -> bool {
    if extract_chunk_push_parts(expr).is_none() {
        return false;
    }
    let Expr::Call(call) = strip_parens(expr) else {
        return false;
    };
    let Callee::Expr(callee) = &call.callee else {
        return false;
    };
    let Expr::Member(callee) = strip_parens(callee) else {
        return false;
    };
    let Expr::Assign(assignment) = strip_parens(&callee.obj) else {
        return false;
    };
    let AssignTarget::Simple(SimpleAssignTarget::Member(target)) = &assignment.left else {
        return false;
    };
    match &target.prop {
        MemberProp::Ident(name) => name.sym.starts_with("webpackJsonp"),
        MemberProp::Computed(computed) => {
            matches!(strip_parens(&computed.expr), Expr::Lit(Lit::Str(name))
                if name.value.as_str().is_some_and(|name| name.starts_with("webpackJsonp")))
        }
        _ => false,
    }
}

fn extract_chunk_push_parts(expr: &Expr) -> Option<(&ArrayLit, Webpack5ModulesContainer<'_>)> {
    let Expr::Call(call) = expr else {
        return None;
    };
    let Callee::Expr(callee_expr) = &call.callee else {
        return None;
    };
    // callee is (self.X = self.X || []).push
    let Expr::Member(MemberExpr { obj, prop, .. }) = &**callee_expr else {
        return None;
    };
    let MemberProp::Ident(push_ident) = prop else {
        return None;
    };
    if push_ident.sym.as_ref() != "push" {
        return None;
    }

    // obj is (self.X = self.X || []) — a parenthesized assignment
    let obj = strip_parens(obj);
    let Expr::Assign(AssignExpr {
        op: AssignOp::Assign,
        right,
        ..
    }) = obj
    else {
        return None;
    };

    // right side: self.X || []
    let Expr::Bin(BinExpr {
        op: BinaryOp::LogicalOr,
        right: or_right,
        ..
    }) = &**right
    else {
        return None;
    };
    // Verify right side of || is an empty array
    let Expr::Array(ArrayLit { elems, .. }) = &**or_right else {
        return None;
    };
    if !elems.is_empty() {
        return None;
    }

    // push argument: [[chunkIds], {modules}, ...]
    if call.args.is_empty() {
        return None;
    }
    let push_arg = &call.args[0].expr;
    let Expr::Array(ArrayLit {
        elems: push_elems, ..
    }) = &**push_arg
    else {
        return None;
    };
    // Must have at least 2 elements: [chunkIds, modulesObject]
    if push_elems.len() < 2 {
        return None;
    }
    // First element: array of chunk IDs
    let Some(Some(first)) = push_elems.first() else {
        return None;
    };
    let Expr::Array(chunk_ids) = &*first.expr else {
        return None;
    };
    // Second element: modules container (object or sparse array)
    let Some(Some(second)) = push_elems.get(1) else {
        return None;
    };
    let modules_container = Webpack5ModulesContainer::from_expr(&second.expr)?;

    Some((chunk_ids, modules_container))
}

/// Match CommonJS async chunk modules:
/// `exports.modules = { ... }`
/// or minified sequence forms like `exports.id=1,exports.modules={...}`.
fn extract_commonjs_chunk_modules(expr: &Expr) -> Option<Webpack5ModulesContainer<'_>> {
    match strip_parens(expr) {
        Expr::Assign(assign) => extract_commonjs_chunk_modules_from_assign(assign),
        Expr::Seq(seq) => seq
            .exprs
            .iter()
            .find_map(|expr| extract_commonjs_chunk_modules(expr)),
        _ => None,
    }
}

fn extract_commonjs_chunk_modules_from_assign(
    assign: &AssignExpr,
) -> Option<Webpack5ModulesContainer<'_>> {
    if assign.op != AssignOp::Assign {
        return None;
    }
    let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
        return None;
    };
    let Expr::Ident(obj) = &*member.obj else {
        return None;
    };
    if obj.sym.as_ref() != "exports" {
        return None;
    }
    if !member_prop_name_is(&member.prop, "modules") {
        return None;
    }
    Webpack5ModulesContainer::from_expr(&assign.right)
}

fn extract_commonjs_chunk_ids(expr: &Expr) -> HashSet<usize> {
    let mut ids = HashSet::default();
    match strip_parens(expr) {
        Expr::Assign(assign) => {
            collect_commonjs_chunk_ids_from_assign(assign, &mut ids);
        }
        Expr::Seq(seq) => {
            for expr in &seq.exprs {
                ids.extend(extract_commonjs_chunk_ids(expr));
            }
        }
        _ => {}
    }
    ids
}

fn collect_commonjs_chunk_ids_from_assign(assign: &AssignExpr, out: &mut HashSet<usize>) {
    if assign.op != AssignOp::Assign {
        return;
    }
    let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
        return;
    };
    let Expr::Ident(obj) = &*member.obj else {
        return;
    };
    if obj.sym.as_ref() != "exports" {
        return;
    }

    if member_prop_name_is(&member.prop, "id") {
        if let Some(id) = numeric_id_from_expr(&assign.right) {
            out.insert(id);
        }
    } else if member_prop_name_is(&member.prop, "ids") {
        let Expr::Array(ids) = strip_parens(&assign.right) else {
            return;
        };
        out.extend(numeric_ids_from_array(ids));
    }
}

fn numeric_ids_from_array(array: &ArrayLit) -> HashSet<usize> {
    array
        .elems
        .iter()
        .filter_map(|elem| elem.as_ref())
        .filter_map(|elem| numeric_id_from_expr(&elem.expr))
        .collect()
}

fn member_prop_name_is(prop: &MemberProp, expected: &str) -> bool {
    match prop {
        MemberProp::Ident(ident) => ident.sym.as_ref() == expected,
        MemberProp::Computed(computed) => {
            let Expr::Lit(Lit::Str(value)) = strip_parens(&computed.expr) else {
                return false;
            };
            value.value.as_str() == Some(expected)
        }
        _ => false,
    }
}

/// Extract modules from a modules container where keys (or array indices) are
/// module IDs and values are factory functions.
/// Used by both entry bundles and JSONP chunks.
struct PreparedWebpack5Factories {
    prepared: Vec<Option<PreparedModuleAst>>,
    failures: HashMap<String, DetectedModuleFailure>,
    id_to_filename: HashMap<usize, String>,
    str_id_to_filename: HashMap<String, String>,
}

/// Runtime-parameter reuse and free-name capture keep one factory opaque in
/// a numeric-id container. `isolate_fatal` does the same for any other
/// normalization failure; only translated factories opt in, because their
/// detector already reports failures per module.
fn prepare_webpack5_factories(
    module_entries: &[Webpack5ModuleDescriptor<'_>],
    isolate_fatal: bool,
) -> Option<PreparedWebpack5Factories> {
    // A missing numeric ID remains an unmistakable webpack runtime call such
    // as `require(17)`. An unresolved string ID could instead look like
    // `require("./provider.js")` and be mistaken for an authored ESM edge by
    // UnEsm, so named-ID containers retain the historical whole-bundle
    // fallback when any factory is opaque.
    let can_isolate_runtime_parameter_reuse = module_entries
        .iter()
        .all(|entry| entry.id.parse::<usize>().is_ok());
    let mut opaque_filenames: HashMap<String, DetectedModuleFailure> = HashMap::default();

    loop {
        // Every round uses one immutable graph snapshot. Newly unsupported
        // factories are applied only after the full pass, so table order
        // cannot change the converged opaque set.
        let id_to_filename: HashMap<usize, String> = module_entries
            .iter()
            .filter(|entry| !opaque_filenames.contains_key(&entry.filename))
            .filter_map(|entry| {
                entry
                    .id
                    .parse::<usize>()
                    .ok()
                    .map(|id| (id, entry.filename.clone()))
            })
            .collect();
        let str_id_to_filename: HashMap<String, String> = module_entries
            .iter()
            .filter(|entry| !opaque_filenames.contains_key(&entry.filename))
            .map(|entry| (entry.id.clone(), entry.filename.clone()))
            .collect();

        let mut prepared = Vec::with_capacity(module_entries.len());
        let mut newly_opaque = HashMap::default();
        for entry in module_entries {
            if opaque_filenames.contains_key(&entry.filename) {
                prepared.push(None);
                continue;
            }
            match prepare_webpack5_module(entry, &id_to_filename, &str_id_to_filename) {
                Ok(ast) => prepared.push(Some(ast)),
                Err(
                    error @ (FactoryNormalizationError::RuntimeParameterReuse
                    | FactoryNormalizationError::FreeNameCapture),
                ) => {
                    if !can_isolate_runtime_parameter_reuse {
                        return None;
                    }
                    newly_opaque.insert(entry.filename.clone(), isolated_failure(error));
                    prepared.push(None);
                }
                Err(FactoryNormalizationError::Fatal) => {
                    if !(isolate_fatal && can_isolate_runtime_parameter_reuse) {
                        return None;
                    }
                    newly_opaque.insert(
                        entry.filename.clone(),
                        DetectedModuleFailure::TranslatedFactoryNormalization,
                    );
                    prepared.push(None);
                }
            }
        }

        if newly_opaque.is_empty() {
            return Some(PreparedWebpack5Factories {
                prepared,
                failures: opaque_filenames,
                id_to_filename,
                str_id_to_filename,
            });
        }
        opaque_filenames.extend(newly_opaque);
    }
}

/// A factory another detector already translated into webpack's
/// `(module, exports, require)` calling convention.
pub(super) struct TranslatedWebpackFactory {
    pub(super) id: String,
    pub(super) filename: String,
    pub(super) params: Vec<Pat>,
    pub(super) body: Vec<Stmt>,
}

/// Prepare translated factories with the webpack 5 normalizer. The prepared
/// sidecar is aligned with `factories`; `None` means the whole container must
/// keep its original fallback.
pub(super) fn prepare_translated_webpack_factories(
    factories: &[TranslatedWebpackFactory],
) -> Option<(
    Vec<Option<PreparedModuleAst>>,
    HashMap<String, DetectedModuleFailure>,
)> {
    let descriptors = factories
        .iter()
        .map(|factory| Webpack5ModuleDescriptor {
            id: factory.id.clone(),
            numeric_id: factory.id.parse::<f64>().ok(),
            filename: factory.filename.clone(),
            params: Webpack5FactoryParams::Arrow(&factory.params),
            body_stmts: &factory.body,
        })
        .collect::<Vec<_>>();
    let prepared = prepare_webpack5_factories(&descriptors, true)?;
    Some((prepared.prepared, prepared.failures))
}

struct ExtractedWebpack5Modules {
    modules: Vec<UnpackedModule>,
    prepared: Vec<Option<PreparedModuleAst>>,
    failures: HashMap<String, DetectedModuleFailure>,
    numeric_module_ids: HashMap<String, f64>,
}

fn extract_modules_from_container(
    modules_container: &Webpack5ModulesContainer<'_>,
    cm: Lrc<SourceMap>,
) -> Option<ExtractedWebpack5Modules> {
    let span = tracing::info_span!(
        "webpack5: extract_modules_from_object",
        count = modules_container.entry_count()
    );
    let _enter = span.enter();

    let module_entries = collect_module_descriptors(modules_container)?;

    let prepared_factories = prepare_webpack5_factories(&module_entries, false)?;

    let mut modules = Vec::new();
    for entry in &module_entries {
        modules.push(UnpackedModule {
            id: entry.id.clone(),
            is_entry: false,
            code: source_fallback_for_stmts(&cm, entry.body_stmts),
            filename: entry.filename.clone(),
            source_ranges: spans_byte_ranges(&cm, entry.body_stmts.iter().map(|s| s.span())),
            inspection_context_ranges: Vec::new(),
            source_input: String::new(),
            generated_source_map: Vec::new(),
            verbatim_source_offset: None,
            mapped_in_every_mode: false,
        });
    }

    Some(ExtractedWebpack5Modules {
        modules,
        prepared: prepared_factories.prepared,
        failures: prepared_factories.failures,
        numeric_module_ids: module_entries
            .iter()
            .filter_map(|entry| entry.numeric_id.map(|id| (entry.filename.clone(), id)))
            .collect(),
    })
}

/// `require_plan`, when the caller already gated the region, is reused for
/// container validation and entry extraction instead of resolving the region
/// again. `surrounding` is the input's top-level code around a bootstrap IIFE.
fn extract_webpack5_modules_with_plan(
    bootstrap_body: &swc_core::ecma::ast::FunctionBody,
    cm: Lrc<SourceMap>,
    mut require_plan: Option<RequireFnPlan>,
    positions: SourcePositions,
    surrounding: SurroundingItems<'_>,
) -> Option<DetectedBundle> {
    let span = tracing::info_span!("webpack5: extract_modules");
    let _enter = span.enter();

    // The top-level fallback found its table with the strict scan and passes
    // its plan; only an IIFE bootstrap may own an empty table.
    let allow_empty_table = require_plan.is_none();
    let (modules_container, modules_sym) = {
        let span = tracing::info_span!("webpack5: find modules object");
        let _enter = span.enter();
        let mut found: Option<(Webpack5ModulesContainer<'_>, Atom)> = None;
        // Empty objects are common region-level declarations; test them
        // against one shared table-invocation scan.
        let mut invoked_tables: Option<HashSet<Atom>> = None;
        for stmt in &bootstrap_body.stmts {
            let Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) = stmt else {
                continue;
            };
            let Some((container, modules_sym)) =
                extract_webpack_modules_container(var_decl, allow_empty_table)
            else {
                continue;
            };
            if container.is_empty_object()
                && !invoked_tables
                    .get_or_insert_with(|| invoked_table_syms(&bootstrap_body.stmts))
                    .contains(&modules_sym)
            {
                continue;
            }
            // Function-valued arrays and objects both occur in ordinary
            // programs. Require webpack's defining cache/invoke/return
            // lifecycle tied to this table before destructively extracting it.
            if require_plan.is_none() {
                match plan_webpack_require_fn(&bootstrap_body.stmts, &modules_sym) {
                    Some(plan) => require_plan = Some(plan),
                    None => continue,
                }
            }
            found = Some((container, modules_sym));
            break;
        }
        found?
    };

    let module_entries = {
        let span = tracing::info_span!("webpack5: collect module entries");
        let _enter = span.enter();
        if modules_container.is_empty_object() {
            Vec::new()
        } else {
            collect_module_descriptors(&modules_container)?
        }
    };

    let PreparedWebpack5Factories {
        mut prepared,
        failures,
        id_to_filename,
        str_id_to_filename,
    } = prepare_webpack5_factories(&module_entries, false)?;
    if !module_entries.is_empty() && failures.len() == module_entries.len() {
        // A synthetic startup cannot make an entirely opaque module table
        // trustworthy; retain the original whole-input fallback.
        return None;
    }
    let id_to_filename = &id_to_filename;
    let str_id_to_filename = &str_id_to_filename;

    let mut modules = Vec::new();

    {
        let span = tracing::info_span!(
            "webpack5: prepare all modules",
            count = module_entries.len()
        );
        let _enter = span.enter();
        for entry in &module_entries {
            modules.push(UnpackedModule {
                id: entry.id.clone(),
                is_entry: false,
                code: source_fallback_for_stmts(&cm, entry.body_stmts),
                filename: entry.filename.clone(),
                source_ranges: spans_byte_ranges(&cm, entry.body_stmts.iter().map(|s| s.span())),
                inspection_context_ranges: Vec::new(),
                source_input: String::new(),
                generated_source_map: Vec::new(),
                verbatim_source_offset: None,
                mapped_in_every_mode: false,
            });
        }
    }

    // Code around the bootstrap runs before or after the bundle; entry.js
    // keeps it, in source order, around the startup.
    let surrounding = SurroundingCode::collect(surrounding, &ENTRY_NORMALIZED_NAMES)?;
    let entry = EntryEmitter {
        cm: &cm,
        id_to_filename,
        str_id_to_filename,
        positions,
        surrounding: &surrounding,
    };

    let (direct_entry_id, direct_entry_consumer) = match require_plan.as_ref() {
        Some(RequireFnPlan::DirectEntry {
            entry_id,
            stmt_idx,
            site,
        }) => (
            Some(entry_id.clone()),
            direct_entry_stmts(
                &bootstrap_body.stmts,
                *stmt_idx,
                *site,
                SyntaxContext::empty(),
            )
            .filter(|stmts| !is_bare_entry_call(stmts)),
        ),
        _ => (None, None),
    };
    let trailing_entry_body = direct_entry_id
        .is_none()
        .then(|| extract_trailing_entry_body(bootstrap_body, &modules_sym, require_plan.as_ref()))
        .flatten();
    // Check for a trailing IIFE entry point. A directly invoked require
    // lifecycle is runtime machinery; its call argument identifies the real
    // entry module and its body must never be materialized as entry.js.
    let mut has_synthetic_entry = if direct_entry_id.is_some() {
        // The statement holding the call and the statements after it are
        // entry code (a library's `window.lib = function require(id) { ...
        // }(entryId)`, the call that starts the app) and must survive as
        // entry.js.
        direct_entry_consumer.is_some_and(|stmts| {
            let (ranges, code) = entry.emit(stmts, Atom::from(DIRECT_ENTRY_REQUIRE), None);
            append_synthetic_entry(&mut modules, &mut prepared, ranges, code)
        })
    } else if let Some(entry_body) = trailing_entry_body {
        let require_sym = match require_plan.as_ref() {
            Some(RequireFnPlan::Declared { sym, .. }) => sym.clone(),
            _ => Atom::from("__webpack_require__"),
        };
        let (ranges, code) = entry.emit(
            entry_body,
            require_sym,
            Some(Atom::from("__webpack_exports__")),
        );
        append_synthetic_entry(&mut modules, &mut prepared, ranges, code)
    } else if let Some(ncc) = extract_ncc_inline_entry(bootstrap_body) {
        let (ranges, code) = entry.emit(ncc.body_stmts, ncc.require_sym, None);
        append_synthetic_entry(&mut modules, &mut prepared, ranges, code)
    } else {
        false
    };

    // Fallback: scan bootstrap for entry-module startup calls, then for an
    // inline startup section (`var __webpack_exports__ = {};` + entry code).
    if !has_synthetic_entry {
        if let Some(entry_id) = direct_entry_id
            .or_else(|| find_ncc_direct_entry(bootstrap_body))
            .or_else(|| find_require_s_entry(bootstrap_body))
            .or_else(|| find_require_o_entry(bootstrap_body))
        {
            if surrounding.is_empty() {
                for module in &mut modules {
                    if module.id == entry_id {
                        module.is_entry = true;
                        break;
                    }
                }
            } else {
                // The code around the bootstrap needs entry.js; the startup
                // between its parts is the entry module's require.
                let (ranges, code) = entry.emit(
                    vec![entry_module_require(&module_entries, &entry_id)],
                    Atom::from(DIRECT_ENTRY_REQUIRE),
                    None,
                );
                has_synthetic_entry =
                    append_synthetic_entry(&mut modules, &mut prepared, ranges, code);
            }
        } else if let Some(startup) =
            extract_webpack5_inline_startup(bootstrap_body, &modules_sym, require_plan.as_ref())
        {
            let (ranges, code) =
                entry.emit(startup.body_stmts, startup.require_sym, startup.exports_sym);
            has_synthetic_entry = append_synthetic_entry(&mut modules, &mut prepared, ranges, code);
        }
    }
    // With no entry.js to hold it, the code around the bootstrap would be in
    // no output file; the input stays one file instead.
    if !surrounding.is_empty() && !has_synthetic_entry {
        return None;
    }

    if modules.is_empty() {
        return None;
    }
    let numeric_module_ids = module_entries
        .iter()
        .filter_map(|entry| entry.numeric_id.map(|id| (entry.filename.clone(), id)))
        .collect();

    Some(
        DetectedBundle::new(
            UnpackResult::new(modules, BundleFormat::Webpack5),
            prepared,
            cm,
        )
        .with_module_failures(failures)
        .with_webpack_numeric_module_ids(numeric_module_ids),
    )
}

/// Callee spelling given to a directly invoked require call when its consumer
/// is emitted as entry.js; entry normalization rewrites it to `require`.
const DIRECT_ENTRY_REQUIRE: &str = "__webpack_require__";

/// The entry code a directly invoked require leaves in the bootstrap: the
/// statement holding the call, in webpack's unrolled startup form, then every
/// statement after it. `window.lib = function require(id) {...}(1)` becomes
/// `var lib = __webpack_require__(1); window.lib = lib;` (a shape `UnEsm`
/// turns into an import), `var lib = function require(id) {...}(1)` becomes
/// `var lib = __webpack_require__(1)`, a bare call becomes
/// `__webpack_require__(1);`, and a comma sequence becomes one statement per
/// element. A final `return` is lowered as in the startup region. Whether the
/// code can leave the bootstrap is [`direct_entry_is_movable`]'s question.
/// `require_ctxt` is the context given to the unrolled require name.
fn direct_entry_stmts(
    stmts: &[Stmt],
    stmt_idx: usize,
    site: DirectEntrySite,
    require_ctxt: SyntaxContext,
) -> Option<Vec<Stmt>> {
    let site_stmt = stmts.get(stmt_idx)?;
    let trailing = &stmts[stmt_idx + 1..];
    let mut names = IdentNameCollector::default();
    site_stmt.visit_with(&mut names);
    trailing.visit_with(&mut names);
    let unrolled_call = |call: &CallExpr| direct_entry_require_call(call.clone(), require_ctxt);

    let mut out = Vec::with_capacity(trailing.len() + 2);
    match (site, site_stmt) {
        (DirectEntrySite::Expr, Stmt::Expr(expr_stmt)) => {
            if matches!(strip_parens(&expr_stmt.expr), Expr::Assign(_)) {
                out.extend(unrolled_direct_entry_assignment(
                    &expr_stmt.expr,
                    expr_stmt.span,
                    &names.0,
                    require_ctxt,
                )?);
            } else {
                out.push(Stmt::Expr(ExprStmt {
                    span: expr_stmt.span,
                    expr: Box::new(Expr::Call(unrolled_call(direct_invoke_call(
                        &expr_stmt.expr,
                    )?))),
                }));
            }
        }
        (DirectEntrySite::SeqElement(element_idx), Stmt::Expr(expr_stmt)) => {
            let Expr::Seq(seq) = strip_parens(&expr_stmt.expr) else {
                return None;
            };
            for (idx, element) in seq.exprs.iter().enumerate() {
                let span = element.span();
                if idx != element_idx {
                    out.push(Stmt::Expr(ExprStmt {
                        span,
                        expr: element.clone(),
                    }));
                } else if matches!(strip_parens(element), Expr::Assign(_)) {
                    out.extend(unrolled_direct_entry_assignment(
                        element,
                        span,
                        &names.0,
                        require_ctxt,
                    )?);
                } else {
                    out.push(Stmt::Expr(ExprStmt {
                        span,
                        expr: Box::new(Expr::Call(unrolled_call(direct_invoke_call(element)?))),
                    }));
                }
            }
        }
        (
            DirectEntrySite::Declarator(decl_idx),
            Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)),
        ) => {
            // Earlier declarators are runtime (the module cache); the call's
            // declarator and later ones are entry code.
            let mut entry_decl = (**var_decl).clone();
            entry_decl.decls.drain(..decl_idx);
            let init = entry_decl.decls.first_mut()?.init.as_mut()?;
            let Expr::Call(call) = strip_parens(init) else {
                return None;
            };
            **init = Expr::Call(unrolled_call(call));
            out.push(Stmt::Decl(swc_core::ecma::ast::Decl::Var(Box::new(
                entry_decl,
            ))));
        }
        _ => return None,
    }
    out.extend(trailing.iter().cloned());
    lower_final_return(&mut out);
    Some(out)
}

/// The directly invoked call at `site` in `stmt`.
fn direct_entry_call(stmt: &Stmt, site: DirectEntrySite) -> Option<&CallExpr> {
    match (site, stmt) {
        (DirectEntrySite::Expr, Stmt::Expr(expr_stmt)) => direct_invoke_call(&expr_stmt.expr),
        (DirectEntrySite::SeqElement(idx), Stmt::Expr(expr_stmt)) => {
            let Expr::Seq(seq) = strip_parens(&expr_stmt.expr) else {
                return None;
            };
            direct_invoke_call(seq.exprs.get(idx)?)
        }
        (
            DirectEntrySite::Declarator(idx),
            Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)),
        ) => match strip_parens(var_decl.decls.get(idx)?.init.as_ref()?) {
            Expr::Call(call) => Some(call),
            _ => None,
        },
        _ => None,
    }
}

/// Whether direct-entry code is only the bare unrolled call: then the entry
/// module itself is marked as the entry instead of writing entry.js.
fn is_bare_entry_call(stmts: &[Stmt]) -> bool {
    matches!(stmts, [Stmt::Expr(ExprStmt { expr, .. })] if matches!(&**expr, Expr::Call(_)))
}

/// `target = function require(id) {...}(1)` as
/// `var target_name = __webpack_require__(1); target = target_name;`.
fn unrolled_direct_entry_assignment(
    expr: &Expr,
    span: Span,
    taken: &HashSet<Atom>,
    require_ctxt: SyntaxContext,
) -> Option<Vec<Stmt>> {
    let binding = Ident::new_no_ctxt(direct_entry_binding_name(expr, taken), DUMMY_SP);
    let mut consumer = Box::new(expr.clone());
    let call = replace_direct_invoke_call(&mut consumer, &binding)?;
    Some(vec![
        Stmt::Decl(swc_core::ecma::ast::Decl::Var(Box::new(VarDecl {
            span,
            ctxt: SyntaxContext::empty(),
            kind: swc_core::ecma::ast::VarDeclKind::Var,
            declare: false,
            decls: vec![VarDeclarator {
                span: DUMMY_SP,
                name: Pat::Ident(binding.into()),
                init: Some(Box::new(Expr::Call(direct_entry_require_call(
                    call,
                    require_ctxt,
                )))),
                definite: false,
            }],
        }))),
        Stmt::Expr(ExprStmt {
            span,
            expr: consumer,
        }),
    ])
}

/// The directly invoked call with its function-expression callee replaced by
/// the unrolled require name; the entry-id argument stays.
fn direct_entry_require_call(call: CallExpr, require_ctxt: SyntaxContext) -> CallExpr {
    CallExpr {
        callee: Callee::Expr(Box::new(Expr::Ident(Ident::new(
            Atom::from(DIRECT_ENTRY_REQUIRE),
            DUMMY_SP,
            require_ctxt,
        )))),
        ..call
    }
}

/// The innermost assignment target's property name (`lib` for `window.lib`),
/// or `entry`; suffixed until no identifier in the statement spells it.
fn direct_entry_binding_name(expr: &Expr, taken: &HashSet<Atom>) -> Atom {
    let mut innermost = None;
    let mut current = strip_parens(expr);
    while let Expr::Assign(assign) = current {
        innermost = Some(&assign.left);
        current = strip_parens(&assign.right);
    }
    let base = innermost
        .and_then(|target| match target {
            AssignTarget::Simple(SimpleAssignTarget::Member(member)) => {
                static_member_property_name(&member.prop)
            }
            _ => None,
        })
        .filter(|name| is_valid_identifier_name(name) && !is_reserved_binding_name(name))
        .unwrap_or("entry");
    let mut name = Atom::from(base);
    let mut suffix = 1;
    while taken.contains(&name) || name.as_ref() == DIRECT_ENTRY_REQUIRE {
        name = Atom::from(format!("{base}_{suffix}"));
        suffix += 1;
    }
    name
}

/// Replace the directly invoked call at the end of the assignment chain with
/// `binding`, returning the call.
fn replace_direct_invoke_call(expr: &mut Expr, binding: &Ident) -> Option<CallExpr> {
    match expr {
        Expr::Paren(paren) => replace_direct_invoke_call(&mut paren.expr, binding),
        Expr::Assign(assign) if assign.op == AssignOp::Assign => {
            replace_direct_invoke_call(&mut assign.right, binding)
        }
        Expr::Call(_) => {
            let Expr::Call(call) = std::mem::replace(expr, Expr::Ident(binding.clone())) else {
                unreachable!("matched a call expression");
            };
            Some(call)
        }
        _ => None,
    }
}

fn append_synthetic_entry(
    modules: &mut Vec<UnpackedModule>,
    prepared: &mut Vec<Option<PreparedModuleAst>>,
    source_ranges: Vec<(u32, u32)>,
    code: Option<MappedCode>,
) -> bool {
    let Some(MappedCode {
        code,
        points: generated_source_map,
    }) = code
    else {
        return false;
    };
    modules.push(UnpackedModule {
        id: "entry".to_string(),
        is_entry: true,
        code,
        filename: "entry.js".to_string(),
        source_ranges,
        inspection_context_ranges: Vec::new(),
        source_input: String::new(),
        generated_source_map,
        verbatim_source_offset: None,
        mapped_in_every_mode: false,
    });
    prepared.push(None);
    true
}

/// `__webpack_require__(<id>);` for the module `entry_id` names, with the id
/// spelled as the table spells it so entry normalization rewrites it to the
/// module's file.
fn entry_module_require(module_entries: &[Webpack5ModuleDescriptor<'_>], entry_id: &str) -> Stmt {
    let id = module_entries
        .iter()
        .find(|descriptor| descriptor.id == entry_id)
        .and_then(|descriptor| descriptor.numeric_id)
        .map_or_else(|| Expr::from(entry_id), Expr::from);
    Stmt::Expr(ExprStmt {
        span: DUMMY_SP,
        expr: Box::new(Expr::Call(CallExpr {
            callee: Callee::Expr(Box::new(Expr::Ident(Ident::new_no_ctxt(
                Atom::from(DIRECT_ENTRY_REQUIRE),
                DUMMY_SP,
            )))),
            args: vec![id.into()],
            ..Default::default()
        })),
    })
}

/// Free names entry normalization gives a meaning of its own: the module's
/// `require` and `exports` (from the runtime's require and exports object),
/// `global` and `define.amd` (from `require.g` and `require.amdO`), and the
/// CommonJS `module`.
const ENTRY_NORMALIZED_NAMES: [&str; 5] = ["require", "exports", "module", "global", "define"];

/// Emits synthetic entry.js programs, with the input's code around the
/// bootstrap placed before and after the normalized startup.
struct EntryEmitter<'a> {
    cm: &'a Lrc<SourceMap>,
    id_to_filename: &'a HashMap<usize, String>,
    str_id_to_filename: &'a HashMap<String, String>,
    positions: SourcePositions,
    surrounding: &'a SurroundingCode,
}

impl EntryEmitter<'_> {
    /// The entry's source ranges and code.
    fn emit(
        &self,
        body_stmts: Vec<Stmt>,
        require_sym: Atom,
        exports_sym: Option<Atom>,
    ) -> (Vec<(u32, u32)>, Option<MappedCode>) {
        let ranges = spans_byte_ranges(
            self.cm,
            body_stmts
                .iter()
                .map(Spanned::span)
                .chain(self.surrounding.spans()),
        );
        let (mut synthetic_module, _, top_level_mark) = normalize_extracted_webpack_entry_module(
            body_stmts,
            self.id_to_filename,
            self.str_id_to_filename,
            require_sym,
            exports_sym,
        );
        self.surrounding
            .rename_conflicts(&mut synthetic_module, top_level_mark);
        self.surrounding.place_around(&mut synthetic_module);
        if apply_fixer(&mut synthetic_module).is_err() {
            return (ranges, None);
        }
        let code = emit_module_with_positions(
            &synthetic_module,
            self.cm.clone(),
            Config::default().with_minify(false),
            self.positions,
        )
        .ok();
        (ranges, code)
    }
}

/// Normalize a webpack5 runtime entry body into a standalone module.
///
/// This is extraction normalization only: it rewrites webpack runtime
/// identifiers, module ids, and runtime helper noise, then leaves ESM recovery
/// and readability cleanup to the driver pipeline.
fn normalize_extracted_webpack_entry_module(
    body_stmts: Vec<Stmt>,
    id_to_filename: &HashMap<usize, String>,
    str_id_to_filename: &HashMap<String, String>,
    require_sym: Atom,
    exports_sym: Option<Atom>,
) -> (Module, Mark, Mark) {
    let mut synthetic_module = build_module_from_stmts(body_stmts);
    let unresolved_mark = Mark::new();
    let top_level_mark = Mark::new();
    synthetic_module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));

    let unresolved_ctxt = SyntaxContext::empty().apply_mark(unresolved_mark);

    let mut id_rewriter = RequireIdRewriter {
        require_sym: require_sym.clone(),
        unresolved_mark,
        from_filename: "entry.js",
        id_to_filename,
    };
    synthetic_module.visit_mut_with(&mut id_rewriter);
    let mut str_rewriter = RequireStringIdRewriter {
        require_sym: require_sym.clone(),
        unresolved_mark,
        from_filename: "entry.js",
        id_to_filename: str_id_to_filename,
    };
    synthetic_module.visit_mut_with(&mut str_rewriter);

    rewrite_require_n_accesses(&mut synthetic_module, require_sym.clone(), unresolved_mark);

    replace_ident(
        &mut synthetic_module,
        (require_sym.clone(), unresolved_ctxt),
        &Ident::new(Atom::from("require"), Default::default(), unresolved_ctxt),
    );
    if let Some(exports_sym) = exports_sym {
        replace_ident(
            &mut synthetic_module,
            (exports_sym, unresolved_ctxt),
            &Ident::new(Atom::from("exports"), Default::default(), unresolved_ctxt),
        );
    }

    let mut normalizer = Webpack5RuntimeNormalizer {
        require_sym: Atom::from("require"),
        unresolved_mark,
    };
    synthetic_module.visit_mut_with(&mut normalizer);

    (synthetic_module, unresolved_mark, top_level_mark)
}

fn extract_trailing_entry_body(
    bootstrap_body: &swc_core::ecma::ast::FunctionBody,
    modules_sym: &Atom,
    require_plan: Option<&RequireFnPlan>,
) -> Option<Vec<Stmt>> {
    // Most production entries are already inline. Avoid resolving/cloning
    // their bootstrap again when there is no removable trailing call.
    let candidate = bootstrap_body
        .stmts
        .iter()
        .rev()
        .find(|stmt| !matches!(stmt, Stmt::Return(_)))?;
    // Terser may merge the last runtime assignments and the wrapper into one
    // sequence (`r.d = ..., r.o = ..., (() => { ... })()`); the startup region
    // below splits that sequence, so its tail is a candidate too.
    let Stmt::Expr(ExprStmt { expr, .. }) = candidate else {
        return None;
    };
    let tail = match strip_parens(expr) {
        Expr::Seq(seq) => seq.exprs.last()?,
        _ => expr,
    };
    extract_iife_body(tail)?;

    // A final IIFE is only the entry wrapper when it owns the entire startup
    // region. Terser can inline an authored main() after imports or other
    // entry statements; extracting only that call body would discard them.
    let (startup, require_sym) =
        extract_webpack5_startup_region(bootstrap_body, modules_sym, require_plan)?;
    let entry_stmt = match startup.as_slice() {
        [stmt] => stmt,
        [anchor, stmt]
            if empty_object_anchor(anchor).is_some_and(|(binding, var)| {
                var.decls.len() == 1
                    && (!stmts_reference_ident(std::slice::from_ref(stmt), &binding)
                        || (binding == "__webpack_exports__" && {
                            // Check the body at the scope it will occupy after unwrapping.
                            // The canonical spelling alone does not prove that the object
                            // is used exclusively by webpack's export machinery.
                            let Some(body) = extract_iife_stmt_body(stmt) else {
                                return false;
                            };
                            let mut region = vec![anchor.clone()];
                            region.extend(body.stmts.iter().cloned());
                            let evidence =
                                anchor_export_helper_evidence(&region, &require_sym, &binding);
                            evidence.helper && !evidence.other_uses
                        }))
            }) =>
        {
            stmt
        }
        _ => return None,
    };
    extract_iife_stmt_body(entry_stmt).map(|body| body.stmts.clone())
}

struct NccInlineEntry {
    body_stmts: Vec<Stmt>,
    require_sym: Atom,
}

/// Extract ncc's inline startup program.
///
/// ncc uses webpack 5's module table but emits the entry directly in the
/// bootstrap IIFE rather than in a trailing IIFE or a `require.s`/`require.O`
/// startup. Its post-processing gives the runtime require binding a stable
/// `nccwpck_require` marker. The entry starts at the declaration of the binding
/// assigned to `module.exports` by the final bootstrap statement; unlike the
/// generated variable name, that export assignment survives minification.
fn extract_ncc_inline_entry(
    bootstrap_body: &swc_core::ecma::ast::FunctionBody,
) -> Option<NccInlineEntry> {
    let require_sym = find_ncc_require_sym(bootstrap_body)?;

    let exports_sym = bootstrap_body
        .stmts
        .iter()
        .rev()
        .find_map(ncc_module_exports_binding)?;
    let entry_start = bootstrap_body
        .stmts
        .iter()
        .enumerate()
        .find_map(|(index, stmt)| {
            let Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) = stmt else {
                return None;
            };
            var_decl
                .decls
                .iter()
                .any(|decl| matches!(&decl.name, Pat::Ident(binding) if binding.sym == exports_sym))
                .then_some(index)
        })?;

    Some(NccInlineEntry {
        body_stmts: bootstrap_body.stmts[entry_start..].to_vec(),
        require_sym,
    })
}

struct Webpack5InlineStartup {
    body_stmts: Vec<Stmt>,
    require_sym: Atom,
    exports_sym: Option<Atom>,
}

/// Extract webpack 5's inline startup: when the entry module needs no IIFE
/// wrapper and no `require.s`/`require.O` startup, the runtime inlines the entry
/// statements at the end of the bootstrap.
///
/// In unminified output an empty-object var declaration
/// (`var __webpack_exports__ = {};`) anchors the startup section. It sits after
/// the require function (which rules out the module cache — webpack declares it
/// before the require function) with no webpack runtime definitions following
/// it (which rules out runtime-section state like load-script's
/// `var inProgress = {};`). Minifiers may merge the entry's leading declarators
/// into the anchor statement (`var o = {}, e = r(9);`), so the anchor's
/// trailing declarators are kept as entry code.
///
/// Minifiers also drop the anchor entirely because nothing reads it. In that
/// case everything after the last runtime definition is treated as the entry,
/// provided it calls the require binding.
fn extract_webpack5_inline_startup(
    bootstrap_body: &swc_core::ecma::ast::FunctionBody,
    modules_sym: &Atom,
    require_plan: Option<&RequireFnPlan>,
) -> Option<Webpack5InlineStartup> {
    let (entry_region, require_sym) =
        extract_webpack5_startup_region(bootstrap_body, modules_sym, require_plan)?;

    // The anchor, when present, is the *first* statement of the startup section
    // (webpack emits it immediately after the runtime). Position and `{}` shape
    // are not enough to treat it as the exports object: when a minifier has
    // dropped the real anchor, an ordinary entry local such as `const app = {}`
    // is the first statement instead, and renaming it to `exports` (plus
    // dropping its declaration) corrupts the entry.
    let (body_stmts, exports_sym) = match empty_object_anchor(&entry_region[0]) {
        Some((binding, var_decl)) => {
            // The region with the empty-object declarator removed.
            let mut without_anchor: Vec<Stmt> = Vec::new();
            if var_decl.decls.len() > 1 {
                let mut rest = var_decl.clone();
                rest.decls.remove(0);
                without_anchor.push(Stmt::Decl(swc_core::ecma::ast::Decl::Var(Box::new(rest))));
            }
            without_anchor.extend(entry_region[1..].iter().cloned());

            let evidence = anchor_export_helper_evidence(&entry_region, &require_sym, &binding);
            if evidence.helper && !evidence.other_uses {
                // Real exports anchor (`require.r(binding)` / `require.d(binding,
                // ...)`): drop the declaration and rename the binding to
                // `exports` so the export helpers are recovered.
                (without_anchor, Some(binding))
            } else if !stmts_reference_ident(&without_anchor, &binding) {
                // A dead `__webpack_exports__ = {}` (app entries with no
                // exports): drop the inert declaration, but do not rename.
                (without_anchor, None)
            } else {
                // An ordinary entry local that happens to be `{}` first, or a
                // library anchor a wrapper tail still consumes (`module.exports
                // = t`) — dropping its declaration would break that use: keep
                // the whole region untouched.
                (entry_region.clone(), None)
            }
        }
        None => (entry_region.clone(), None),
    };

    // Require the recovered entry to actually call the require binding so a
    // bundle with no startup does not synthesize a bogus entry.
    if body_stmts.is_empty() || !stmts_call_require(&body_stmts, &require_sym) {
        return None;
    }
    Some(Webpack5InlineStartup {
        body_stmts,
        require_sym,
        exports_sym,
    })
}

/// Recover the complete startup region before choosing whether a trailing
/// wrapper can be removed. Both entry paths must agree on the runtime boundary,
/// including entry expressions merged into the final runtime sequence.
fn extract_webpack5_startup_region(
    bootstrap_body: &swc_core::ecma::ast::FunctionBody,
    modules_sym: &Atom,
    require_plan: Option<&RequireFnPlan>,
) -> Option<(Vec<Stmt>, Atom)> {
    // Reuse the lifecycle plan that gated detection. Keep the loose fallback
    // for callers that do not already carry a plan.
    let (require_idx, require_sym) = match require_plan {
        Some(RequireFnPlan::Declared { stmt_idx, sym }) => (*stmt_idx, sym.clone()),
        Some(RequireFnPlan::DirectEntry { .. }) => return None,
        None => find_webpack5_require_fn(&bootstrap_body.stmts, modules_sym)?,
    };

    // Runtime sections define helpers on webpack-owned require properties
    // (`require.d = ...`, `require.f.j = ...`), but entry source can mutate
    // arbitrary properties on that same documented raw-require object. A
    // named exports anchor is an explicit producer boundary; otherwise find
    // the first require use that executes during startup and only classify
    // known webpack runtime properties before it as runtime. This ordering
    // matters when Terser merges both into one sequence:
    // `require.instrumented = true, loadEntry()`.
    //
    // Both scans use resolved identity. They also skip dormant nested
    // functions while descending into immediately-invoked runtime wrappers,
    // so `function decorate() { require.flag = true; }` is entry code rather
    // than a late runtime definition.
    let (probe_stmts, _) = resolve_probe(&bootstrap_body.stmts)?;
    let require_id = declared_binding_id(probe_stmts.get(require_idx)?, &require_sym)?;
    let named_anchor_idx =
        find_named_exports_anchor(&bootstrap_body.stmts, require_idx.saturating_add(1));
    let runtime_boundary =
        find_inline_runtime_boundary(&probe_stmts, require_idx, &require_id, named_anchor_idx);
    let last_runtime_idx = runtime_boundary.as_ref().map(|boundary| boundary.stmt_idx);

    let startup_scan_from = last_runtime_idx
        .map(|idx| idx + 1)
        .unwrap_or(require_idx + 1)
        .max(require_idx + 1);

    // Minifiers may merge the last runtime assignments and the startup into
    // one comma sequence (`r.d = ..., r.o = ..., loadEntry()`). When the
    // boundary statement is such a sequence, its tail after the final runtime
    // assignment is startup code and belongs to the entry region.
    let mut entry_region: Vec<Stmt> = Vec::new();
    if let Some(RuntimeBoundary {
        stmt_idx: idx,
        seq_expr_idx: Some(split),
    }) = runtime_boundary
    {
        if let Some(Stmt::Expr(orig_stmt)) = bootstrap_body.stmts.get(idx) {
            if let Expr::Seq(orig_seq) = strip_parens(&orig_stmt.expr) {
                for tail in &orig_seq.exprs[split + 1..] {
                    entry_region.push(Stmt::Expr(ExprStmt {
                        span: tail.span(),
                        expr: tail.clone(),
                    }));
                }
            }
        }
    }
    entry_region.extend(bootstrap_body.stmts[startup_scan_from..].iter().cloned());
    if entry_region.is_empty() {
        return None;
    }

    // Lowering runs before the anchor analysis so an inert `return t` does
    // not count as a wrapper use of the anchor.
    lower_final_return(&mut entry_region);
    if entry_region.is_empty() {
        return None;
    }

    Some((entry_region, require_sym))
}

/// Entry code may end at an enclosing UMD/AMD factory's `return`: wrapper
/// plumbing, and illegal at the top level of a module. Keep a side-effectful
/// argument as an expression statement (a minified library may start up
/// directly in the return, `return r(5)`); drop inert values like the
/// minified `return {}`.
fn lower_final_return(stmts: &mut Vec<Stmt>) {
    if !matches!(stmts.last(), Some(Stmt::Return(_))) {
        return;
    }
    let Some(Stmt::Return(ret)) = stmts.pop() else {
        return;
    };
    if let Some(arg) = ret.arg {
        if matches!(
            strip_parens(&arg),
            Expr::Call(_) | Expr::New(_) | Expr::Assign(_) | Expr::Await(_) | Expr::Seq(_)
        ) {
            stmts.push(Stmt::Expr(ExprStmt {
                span: ret.span,
                expr: arg,
            }));
        }
    }
}

/// If `stmt` begins with an empty-object declarator (`var x = {}` — webpack's
/// `__webpack_exports__` anchor), return its binding symbol and the var decl.
fn empty_object_anchor(stmt: &Stmt) -> Option<(Atom, &VarDecl)> {
    let Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) = stmt else {
        return None;
    };
    let first = var_decl.decls.first()?;
    let Pat::Ident(binding) = &first.name else {
        return None;
    };
    let init = first.init.as_ref()?;
    let Expr::Object(object) = strip_parens(init) else {
        return None;
    };
    if !object.props.is_empty() {
        return None;
    }
    Some((binding.id.sym.clone(), var_decl))
}

/// Whether `binding` is passed to a webpack export helper — `require.r(binding)`
/// (esModule marker) or `require.d(binding, ...)` (define exports) — which is
/// what identifies it as webpack's exports object rather than an ordinary
/// empty-object local.
///
/// Evidence must be about the *same binding*, not the same spelling: a nested
/// function parameter, block-scoped `const`, catch parameter, or named class
/// expression (`class a { static { require.d(a, ...) } }`) shadows the anchor,
/// and helper calls on the shadow prove nothing about it. The region is
/// probe-resolved (see [`resolve_probe`]) and compared by binding identity,
/// which covers every lexical scope uniformly. The require binding is declared
/// before the startup region, so real helper references resolve to the probe's
/// unresolved context; a startup-region local shadowing the require binding is
/// rejected the same way.
///
/// Evidence inside a nested function or arrow does NOT count even when it
/// captures the real anchor: webpack emits its inline-startup export helpers
/// in the startup scope itself, and a closure (`function helper() {
/// require.d(a, ...) }`) may never run — treating it as proof would rewrite a
/// live local to `exports` on the strength of dead code.
fn anchor_export_helper_evidence(
    stmts: &[Stmt],
    require_sym: &Atom,
    binding: &Atom,
) -> AnchorEvidence {
    const NONE: AnchorEvidence = AnchorEvidence {
        helper: false,
        other_uses: false,
    };
    let Some((probe_stmts, unresolved_ctxt)) = resolve_probe(stmts) else {
        return NONE;
    };
    // The anchor is the first declarator of the region's first statement
    // (mirrors `empty_object_anchor`); take its resolved identity from the
    // probe.
    let Some(Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl))) = probe_stmts.first() else {
        return NONE;
    };
    let Some(first) = var_decl.decls.first() else {
        return NONE;
    };
    let Pat::Ident(anchor) = &first.name else {
        return NONE;
    };
    if anchor.id.sym != *binding {
        return NONE;
    }
    let anchor_id = anchor.id.to_id();
    let mut finder = ExportHelperFinder {
        require_sym,
        unresolved_ctxt,
        anchor_id: anchor_id.clone(),
        helper_args: 0,
    };
    probe_stmts.visit_with(&mut finder);
    let mut counter = AnchorUseCounter {
        anchor_id,
        count: 0,
    };
    probe_stmts.visit_with(&mut counter);
    AnchorEvidence {
        helper: finder.helper_args > 0,
        other_uses: counter.count > finder.helper_args,
    }
}

/// What the startup region does with the empty-object anchor binding.
struct AnchorEvidence {
    /// The startup scope passes the anchor to `require.r` / `require.d` —
    /// webpack's export machinery.
    helper: bool,
    /// The anchor has uses beyond those helper calls — wrapper plumbing such
    /// as `module.exports = t`, or a closure capturing it. Dropping the
    /// declaration and renaming to a free `exports` would break these.
    other_uses: bool,
}

struct ExportHelperFinder<'a> {
    require_sym: &'a Atom,
    unresolved_ctxt: SyntaxContext,
    anchor_id: Id,
    /// Number of helper calls whose first argument is the anchor.
    helper_args: usize,
}

impl Visit for ExportHelperFinder<'_> {
    // Webpack emits export helpers in the startup scope itself; a helper call
    // inside a nested function may never execute and is not evidence (binding
    // identity already handles shadowing, this handles liveness).
    fn visit_function(&mut self, _function: &swc_core::ecma::ast::Function) {}
    fn visit_arrow_expr(&mut self, _arrow: &swc_core::ecma::ast::ArrowExpr) {}

    fn visit_call_expr(&mut self, call: &CallExpr) {
        call.visit_children_with(self);
        let Callee::Expr(callee) = &call.callee else {
            return;
        };
        // callee is `require.r` or `require.d` on the outer require binding
        let Expr::Member(MemberExpr { obj, prop, .. }) = strip_parens(callee) else {
            return;
        };
        if !matches!(
            strip_parens(obj),
            Expr::Ident(id) if id.sym == *self.require_sym && id.ctxt == self.unresolved_ctxt
        ) {
            return;
        }
        if !matches!(prop, MemberProp::Ident(ident) if matches!(ident.sym.as_ref(), "r" | "d")) {
            return;
        }
        // first argument is the exports binding
        let Some(first) = call.args.first() else {
            return;
        };
        if first.spread.is_none()
            && matches!(strip_parens(&first.expr), Expr::Ident(id) if id.to_id() == self.anchor_id)
        {
            self.helper_args += 1;
        }
    }
}

/// Counts references to the anchor binding at any depth. Declarator names are
/// declarations, not uses, and are skipped; a use inside a nested function
/// counts — even a never-called closure keeps the declaration alive.
struct AnchorUseCounter {
    anchor_id: Id,
    count: usize,
}

impl Visit for AnchorUseCounter {
    fn visit_var_declarator(&mut self, declarator: &VarDeclarator) {
        if let Some(init) = &declarator.init {
            init.visit_with(self);
        }
    }

    fn visit_ident(&mut self, ident: &Ident) {
        if ident.to_id() == self.anchor_id {
            self.count += 1;
        }
    }
}

/// Whether `sym` is referenced anywhere in `stmts`.
fn stmts_reference_ident(stmts: &[Stmt], sym: &Atom) -> bool {
    let mut finder = SymUsageFinder { sym, found: false };
    stmts.visit_with(&mut finder);
    finder.found
}

/// Whether any statement uses the require binding as a loader: a direct call
/// (`r(1)`) or a call through one of its members — webpack's eager
/// `import()` startup has no direct call, only
/// `Promise.resolve().then(r.bind(r, 1))`, and chunked startups call
/// `r.e(...)`.
fn stmts_call_require(stmts: &[Stmt], require_sym: &Atom) -> bool {
    let mut finder = RequireCallFinder {
        require_sym,
        found: false,
    };
    stmts.visit_with(&mut finder);
    finder.found
}

struct RequireCallFinder<'a> {
    require_sym: &'a Atom,
    found: bool,
}

impl Visit for RequireCallFinder<'_> {
    fn visit_call_expr(&mut self, call: &CallExpr) {
        call.visit_children_with(self);
        let Callee::Expr(callee) = &call.callee else {
            return;
        };
        match strip_parens(callee) {
            Expr::Ident(ident) if ident.sym == *self.require_sym => {
                self.found = true;
            }
            // `r.bind(r, 1)`, `r.e(1)`, `r.t(...)` — a member call on the
            // require binding is still the loader in use.
            Expr::Member(MemberExpr { obj, .. }) => {
                if matches!(strip_parens(obj), Expr::Ident(ident) if ident.sym == *self.require_sym)
                {
                    self.found = true;
                }
            }
            _ => {}
        }
    }
}

/// Find the webpack require function loosely: the first region-level function
/// declaration (any shape [`region_fn_candidates`] knows) whose body
/// references the modules container binding.
fn find_webpack5_require_fn(stmts: &[Stmt], modules_sym: &Atom) -> Option<(usize, Atom)> {
    region_fn_candidates(stmts)
        .into_iter()
        .find_map(|candidate| {
            let RegionFnCandidateKind::Declared(sym) = candidate.kind else {
                return None;
            };
            let mut finder = SymUsageFinder {
                sym: modules_sym,
                found: false,
            };
            candidate.body.visit_with(&mut finder);
            finder.found.then_some((candidate.stmt_idx, sym))
        })
}

struct SymUsageFinder<'a> {
    sym: &'a Atom,
    found: bool,
}

impl Visit for SymUsageFinder<'_> {
    fn visit_ident(&mut self, ident: &Ident) {
        if ident.sym == *self.sym {
            self.found = true;
        }
    }
}

struct RuntimeBoundary {
    stmt_idx: usize,
    /// For a minifier-merged boundary statement, the last runtime expression.
    /// Expressions after it execute as entry startup and must be retained.
    seq_expr_idx: Option<usize>,
}

/// Locate the end of webpack's runtime section without allowing later entry
/// mutations of the raw require object to move the boundary.
fn find_inline_runtime_boundary(
    stmts: &[Stmt],
    require_idx: usize,
    require_id: &Id,
    explicit_startup_idx: Option<usize>,
) -> Option<RuntimeBoundary> {
    let scan_from = require_idx + 1;
    let first_startup = explicit_startup_idx
        .filter(|idx| *idx >= scan_from)
        .map(|idx| (idx, None))
        .or_else(|| find_first_executed_startup(stmts, scan_from, require_id));

    let stmt_idx = if let Some((startup_stmt_idx, startup_seq_idx)) = first_startup {
        if let Some(startup_expr_idx) = startup_seq_idx {
            let Stmt::Expr(stmt) = &stmts[startup_stmt_idx] else {
                unreachable!("sequence startup point must belong to an expression statement");
            };
            let Expr::Seq(seq) = strip_parens(&stmt.expr) else {
                unreachable!("sequence startup point must retain its sequence");
            };
            if let Some(seq_expr_idx) =
                last_runtime_require_assign_in_exprs(&seq.exprs[..startup_expr_idx], require_id)
            {
                return Some(RuntimeBoundary {
                    stmt_idx: startup_stmt_idx,
                    seq_expr_idx: Some(seq_expr_idx),
                });
            }
        }

        stmts[scan_from..startup_stmt_idx]
            .iter()
            .rposition(|stmt| contains_runtime_require_assignment(stmt, require_id))
            .map(|offset| scan_from + offset)?
    } else {
        // No eagerly evaluated loader use was found. Retain the previous
        // fallback for deferred startup shapes whose require call lives in a callback.
        stmts[scan_from..]
            .iter()
            .rposition(|stmt| contains_runtime_require_assignment(stmt, require_id))
            .map(|offset| scan_from + offset)?
    };
    // Even when the first loader call is in a later statement, a runtime
    // sequence can already end with entry effects: `r.o = ..., recordStartup()`.
    let seq_expr_idx = match &stmts[stmt_idx] {
        Stmt::Expr(stmt) => match strip_parens(&stmt.expr) {
            Expr::Seq(seq) => last_runtime_require_assign_in_exprs(&seq.exprs, require_id),
            _ => None,
        },
        _ => None,
    };
    Some(RuntimeBoundary {
        stmt_idx,
        seq_expr_idx,
    })
}

fn find_first_executed_startup(
    stmts: &[Stmt],
    scan_from: usize,
    require_id: &Id,
) -> Option<(usize, Option<usize>)> {
    let mut seen_runtime_paths = HashSet::default();
    for (stmt_idx, stmt) in stmts.iter().enumerate().skip(scan_from) {
        if let Stmt::Expr(expr_stmt) = stmt {
            if let Expr::Seq(seq) = strip_parens(&expr_stmt.expr) {
                for (seq_expr_idx, expr) in seq.exprs.iter().enumerate() {
                    let effects = executed_require_effects(expr, require_id);
                    if effects.require_call
                        || effects.repeated_runtime_assignment
                        || effects
                            .runtime_assignments
                            .iter()
                            .any(|path| seen_runtime_paths.contains(path))
                    {
                        return Some((stmt_idx, Some(seq_expr_idx)));
                    }
                    seen_runtime_paths.extend(effects.runtime_assignments);
                }
                continue;
            }
        }

        let effects = executed_require_effects(stmt, require_id);
        if effects.require_call
            || effects.repeated_runtime_assignment
            || effects
                .runtime_assignments
                .iter()
                .any(|path| seen_runtime_paths.contains(path))
        {
            return Some((stmt_idx, None));
        }
        seen_runtime_paths.extend(effects.runtime_assignments);
    }
    None
}

fn find_named_exports_anchor(stmts: &[Stmt], scan_from: usize) -> Option<usize> {
    stmts
        .iter()
        .enumerate()
        .skip(scan_from)
        .find_map(|(idx, stmt)| {
            empty_object_anchor(stmt)
                .filter(|(binding, _)| binding.as_ref() == "__webpack_exports__")
                .map(|_| idx)
        })
}

fn last_runtime_require_assign_in_exprs(exprs: &[Box<Expr>], require_id: &Id) -> Option<usize> {
    exprs
        .iter()
        .rposition(|expr| contains_runtime_require_assignment(expr, require_id))
}

/// The [`Id`] `stmt` declares under `sym` — a function declaration's name or
/// a `var` declarator's binding.
fn declared_binding_id(stmt: &Stmt, sym: &Atom) -> Option<Id> {
    match stmt {
        Stmt::Decl(swc_core::ecma::ast::Decl::Fn(fn_decl)) if fn_decl.ident.sym == *sym => {
            Some(fn_decl.ident.to_id())
        }
        Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) => {
            var_decl.decls.iter().find_map(|declarator| {
                let Pat::Ident(binding) = &declarator.name else {
                    return None;
                };
                (binding.id.sym == *sym).then(|| binding.id.to_id())
            })
        }
        _ => None,
    }
}

/// Whether the node executes an assignment to a webpack-owned member of the
/// require binding, e.g. `require.d = ...` or `require.f.j = ...`. Arbitrary
/// properties are available to entry source and cannot establish a runtime
/// boundary. The node must come from a probe-resolved region.
fn contains_runtime_require_assignment<'a, N>(node: &N, require_id: &'a Id) -> bool
where
    N: VisitWith<ExecutedRequireEffectsFinder<'a>>,
{
    !executed_require_effects(node, require_id)
        .runtime_assignments
        .is_empty()
}

#[derive(Default)]
struct ExecutedRequireEffects {
    require_call: bool,
    runtime_assignments: HashSet<String>,
    repeated_runtime_assignment: bool,
}

fn executed_require_effects<'a, N>(node: &N, require_id: &'a Id) -> ExecutedRequireEffects
where
    N: VisitWith<ExecutedRequireEffectsFinder<'a>>,
{
    let mut finder = ExecutedRequireEffectsFinder {
        require_id,
        effects: ExecutedRequireEffects::default(),
    };
    node.visit_with(&mut finder);
    finder.effects
}

/// Scan only code that executes while evaluating the node. Function, arrow,
/// getter, and setter bodies are dormant; immediately-invoked function bodies
/// execute and are visited explicitly. Keeping call and assignment detection
/// in one walker prevents their execution-context rules from drifting apart.
struct ExecutedRequireEffectsFinder<'a> {
    require_id: &'a Id,
    effects: ExecutedRequireEffects,
}

impl Visit for ExecutedRequireEffectsFinder<'_> {
    fn visit_function(&mut self, _function: &swc_core::ecma::ast::Function) {}

    fn visit_arrow_expr(&mut self, _arrow: &swc_core::ecma::ast::ArrowExpr) {}

    fn visit_getter_prop(&mut self, getter: &swc_core::ecma::ast::GetterProp) {
        getter.key.visit_with(self);
    }

    fn visit_setter_prop(&mut self, setter: &swc_core::ecma::ast::SetterProp) {
        setter.key.visit_with(self);
    }

    fn visit_call_expr(&mut self, call: &CallExpr) {
        if let Callee::Expr(callee) = &call.callee {
            match strip_parens(callee) {
                Expr::Ident(ident) if ident.to_id() == *self.require_id => {
                    self.effects.require_call = true;
                }
                Expr::Member(member) if member_root_matches(member, self.require_id) => {
                    self.effects.require_call = true;
                }
                _ => {}
            }

            call.visit_children_with(self);
            match strip_parens(callee) {
                Expr::Fn(function) => {
                    if let Some(body) = &function.function.body {
                        body.visit_with(self);
                    }
                }
                Expr::Arrow(arrow) => match &*arrow.body {
                    ArrowFunctionBody::FunctionBody(body) => body.visit_with(self),
                    ArrowFunctionBody::Expr(expr) => expr.visit_with(self),
                },
                _ => {}
            }
        } else {
            call.visit_children_with(self);
        }
    }

    fn visit_assign_expr(&mut self, assign: &swc_core::ecma::ast::AssignExpr) {
        assign.visit_children_with(self);
        let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
            return;
        };
        let Some(property) = require_root_property(member, self.require_id) else {
            return;
        };
        if is_webpack_runtime_property(property) {
            let Some(path) = require_member_static_path(member, self.require_id) else {
                return;
            };
            if !self.effects.runtime_assignments.insert(path) {
                self.effects.repeated_runtime_assignment = true;
            }
        }
    }
}

fn member_root_matches(member: &MemberExpr, require_id: &Id) -> bool {
    let mut obj = &*member.obj;
    while let Expr::Member(inner) = strip_parens(obj) {
        obj = &inner.obj;
    }
    matches!(strip_parens(obj), Expr::Ident(root) if root.to_id() == *require_id)
}

fn require_root_property<'a>(member: &'a MemberExpr, require_id: &Id) -> Option<&'a str> {
    let mut current = member;
    loop {
        match strip_parens(&current.obj) {
            Expr::Ident(root) if root.to_id() == *require_id => {
                return static_member_property_name(&current.prop);
            }
            Expr::Member(inner) => current = inner,
            _ => return None,
        }
    }
}

fn require_member_static_path(member: &MemberExpr, require_id: &Id) -> Option<String> {
    let mut current = member;
    let mut segments = Vec::new();
    loop {
        segments.push(static_member_property_name(&current.prop)?);
        match strip_parens(&current.obj) {
            Expr::Ident(root) if root.to_id() == *require_id => {
                segments.reverse();
                return Some(segments.join("."));
            }
            Expr::Member(inner) => current = inner,
            _ => return None,
        }
    }
}

fn static_member_property_name(prop: &MemberProp) -> Option<&str> {
    match prop {
        MemberProp::Ident(ident) => Some(ident.sym.as_ref()),
        MemberProp::Computed(computed) => match strip_parens(&computed.expr) {
            Expr::Lit(Lit::Str(value)) => value.value.as_str(),
            _ => None,
        },
        MemberProp::PrivateName(_) => None,
    }
}

/// Stable property names assigned by webpack's built-in runtime modules, plus
/// Rspack's version metadata (`rv`, `ruid`).
/// This is intentionally positive: an unknown property may be authored by the
/// entry through webpack's public raw-require variable and must be preserved.
pub(crate) fn is_webpack_runtime_property(property: &str) -> bool {
    matches!(
        property,
        "amdD"
            | "amdO"
            | "ei"
            | "a"
            | "aD"
            | "aE"
            | "aG"
            | "b"
            | "cn"
            | "cjs"
            | "n"
            | "vs"
            | "t"
            | "ts"
            | "tu"
            | "is"
            | "R"
            | "zT"
            | "zS"
            | "d"
            | "e"
            | "f"
            | "s"
            | "C"
            | "k"
            | "u"
            | "hk"
            | "hu"
            | "h"
            | "tt"
            | "hmrF"
            | "wb"
            | "g"
            | "hmd"
            | "o"
            | "hmrM"
            | "hmrC"
            | "hmrI"
            | "hmrD"
            | "hmrS"
            | "I"
            | "v"
            | "i"
            | "l"
            | "z"
            | "r"
            | "zO"
            | "c"
            | "m"
            | "nmd"
            | "O"
            | "PA"
            | "E"
            | "F"
            | "LA"
            | "G"
            | "H"
            | "p"
            | "U"
            | "j"
            | "nc"
            | "dn"
            | "S"
            | "x"
            | "SAH"
            | "X"
            | "System"
            | "y"
            | "tb"
            | "oe"
            | "w"
            | "wc"
            | "rv"
            | "ruid"
    )
}

fn find_ncc_require_sym(bootstrap_body: &swc_core::ecma::ast::FunctionBody) -> Option<Atom> {
    bootstrap_body.stmts.iter().find_map(|stmt| {
        let Stmt::Decl(swc_core::ecma::ast::Decl::Fn(function)) = stmt else {
            return None;
        };
        function
            .ident
            .sym
            .as_ref()
            .contains("nccwpck_require")
            .then(|| function.ident.sym.clone())
    })
}

/// Recognize ncc's direct CommonJS startup:
/// `module.exports = __nccwpck_require__(<entry id>)`.
fn find_ncc_direct_entry(bootstrap_body: &swc_core::ecma::ast::FunctionBody) -> Option<String> {
    let require_sym = find_ncc_require_sym(bootstrap_body)?;
    bootstrap_body
        .stmts
        .iter()
        .rev()
        .find(|statement| !matches!(statement, Stmt::Empty(_)))
        .and_then(|statement| ncc_direct_entry_from_statement(statement, &require_sym))
}

fn ncc_direct_entry_from_statement(statement: &Stmt, require_sym: &Atom) -> Option<String> {
    let Stmt::Expr(ExprStmt { expr, .. }) = statement else {
        return None;
    };
    ncc_direct_entry_from_expr(expr, require_sym)
}

fn ncc_direct_entry_from_expr(expression: &Expr, require_sym: &Atom) -> Option<String> {
    match strip_parens(expression) {
        Expr::Assign(assign) if assign.op == AssignOp::Assign => {
            let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
                return None;
            };
            let Expr::Ident(module) = strip_parens(&member.obj) else {
                return None;
            };
            if module.sym.as_ref() != "module" || !member_prop_name_is(&member.prop, "exports") {
                return None;
            }
            extract_require_call_id(&assign.right, require_sym)
        }
        Expr::Seq(sequence) => sequence
            .exprs
            .iter()
            .rev()
            .find_map(|expression| ncc_direct_entry_from_expr(expression, require_sym)),
        _ => None,
    }
}

fn ncc_module_exports_binding(statement: &Stmt) -> Option<Atom> {
    let Stmt::Expr(ExprStmt { expr, .. }) = statement else {
        return None;
    };
    ncc_module_exports_binding_from_expr(expr)
}

fn ncc_module_exports_binding_from_expr(expression: &Expr) -> Option<Atom> {
    match strip_parens(expression) {
        Expr::Assign(assign) if assign.op == AssignOp::Assign => {
            let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
                return None;
            };
            let Expr::Ident(module) = strip_parens(&member.obj) else {
                return None;
            };
            if module.sym.as_ref() != "module" || !member_prop_name_is(&member.prop, "exports") {
                return None;
            }
            let Expr::Ident(exports) = strip_parens(&assign.right) else {
                return None;
            };
            Some(exports.sym.clone())
        }
        Expr::Seq(sequence) => sequence
            .exprs
            .iter()
            .rev()
            .find_map(|expression| ncc_module_exports_binding_from_expr(expression)),
        _ => None,
    }
}

fn is_webpack5_runtime_entry_body(body: &swc_core::ecma::ast::FunctionBody) -> bool {
    // Cheap pre-check: scan only the direct statements of the IIFE body for
    // member assignments `obj.e =`, `obj.u =`, `obj.t =`, and `obj.m =` or
    // `obj.f =` on the same identifier.  This rejects non-runtime IIFEs
    // without a full recursive traversal.
    if !has_runtime_property_assignments(body) {
        return false;
    }

    let mut collector = RuntimePropCollector::default();
    body.visit_with(&mut collector);
    collector.props_by_object.iter().any(|(object, props)| {
        collector.function_names.contains(object)
            && collector.async_chunk_load_objects.contains(object)
            && props.contains("e")
            && props.contains("u")
            && props.contains("t")
            && (props.contains("m") || props.contains("f"))
    })
}

fn has_runtime_property_assignments(body: &swc_core::ecma::ast::FunctionBody) -> bool {
    let mut bits_by_object: HashMap<Atom, u8> = HashMap::default();
    for stmt in &body.stmts {
        let Stmt::Expr(ExprStmt { expr, .. }) = stmt else {
            continue;
        };
        if check_runtime_assign(expr, &mut bits_by_object) {
            return true;
        }
        // Minified bundles pack assignments into comma sequences:
        //   f.m=o, f.t=function(){...}, f.e=..., f.u=...
        if let Expr::Seq(SeqExpr { exprs, .. }) = &**expr {
            for sub in exprs {
                if check_runtime_assign(sub, &mut bits_by_object) {
                    return true;
                }
            }
        }
    }
    false
}

fn check_runtime_assign(expr: &Expr, bits_by_object: &mut HashMap<Atom, u8>) -> bool {
    let Expr::Assign(assign) = expr else {
        return false;
    };
    let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
        return false;
    };
    let Expr::Ident(obj) = &*member.obj else {
        return false;
    };
    let MemberProp::Ident(prop) = &member.prop else {
        return false;
    };
    let flag = match prop.sym.as_str() {
        "e" => 1u8,
        "u" => 2,
        "t" => 4,
        "m" | "f" => 8,
        _ => return false,
    };
    let bits = bits_by_object.entry(obj.sym.clone()).or_default();
    *bits |= flag;
    *bits & 0b1111 == 0b1111
}

#[derive(Default)]
struct RuntimePropCollector {
    props_by_object: HashMap<String, HashSet<String>>,
    function_names: HashSet<String>,
    async_chunk_load_objects: HashSet<String>,
}

impl Visit for RuntimePropCollector {
    fn visit_fn_decl(&mut self, decl: &swc_core::ecma::ast::FnDecl) {
        self.function_names.insert(decl.ident.sym.to_string());
        decl.visit_children_with(self);
    }

    fn visit_var_declarator(&mut self, declarator: &VarDeclarator) {
        if let Pat::Ident(binding) = &declarator.name {
            if matches!(
                declarator.init.as_deref().map(strip_parens),
                Some(Expr::Fn(_) | Expr::Arrow(_))
            ) {
                self.function_names.insert(binding.id.sym.to_string());
            }
        }

        declarator.visit_children_with(self);
    }

    fn visit_assign_expr(&mut self, assign: &AssignExpr) {
        if let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left {
            self.collect_member_prop(member);
        }

        assign.visit_children_with(self);
    }

    fn visit_call_expr(&mut self, call: &CallExpr) {
        if let Some(object) = self.extract_async_chunk_load_object(call) {
            self.async_chunk_load_objects.insert(object);
        }

        call.visit_children_with(self);
    }
}

impl RuntimePropCollector {
    fn collect_member_prop(&mut self, member: &MemberExpr) {
        let Expr::Ident(obj) = &*member.obj else {
            return;
        };
        let MemberProp::Ident(prop) = &member.prop else {
            return;
        };
        self.props_by_object
            .entry(obj.sym.to_string())
            .or_default()
            .insert(prop.sym.to_string());
    }

    fn extract_async_chunk_load_object(&self, call: &CallExpr) -> Option<String> {
        let Callee::Expr(callee) = &call.callee else {
            return None;
        };
        let Expr::Member(MemberExpr {
            obj: then_obj,
            prop: then_prop,
            ..
        }) = strip_parens(callee)
        else {
            return None;
        };
        if !member_prop_name_is(then_prop, "then") {
            return None;
        }

        let Expr::Call(load_call) = strip_parens(then_obj) else {
            return None;
        };
        let load_object = callee_object_for_member_call(load_call, "e")?;
        let then_arg = call.args.first()?;
        if then_arg.spread.is_some() {
            return None;
        }
        let Expr::Call(bind_call) = strip_parens(&then_arg.expr) else {
            return None;
        };
        let bind_object = self.extract_runtime_t_bind_object(bind_call)?;

        (load_object == bind_object).then_some(load_object)
    }

    fn extract_runtime_t_bind_object(&self, call: &CallExpr) -> Option<String> {
        let Callee::Expr(callee) = &call.callee else {
            return None;
        };
        let Expr::Member(MemberExpr {
            obj: bind_obj,
            prop: bind_prop,
            ..
        }) = strip_parens(callee)
        else {
            return None;
        };
        if !member_prop_name_is(bind_prop, "bind") {
            return None;
        }

        let Expr::Member(MemberExpr {
            obj: t_obj,
            prop: t_prop,
            ..
        }) = strip_parens(bind_obj)
        else {
            return None;
        };
        if !member_prop_name_is(t_prop, "t") {
            return None;
        }
        let Expr::Ident(runtime_ident) = strip_parens(t_obj) else {
            return None;
        };

        let this_arg = call.args.first()?;
        if this_arg.spread.is_some() {
            return None;
        }
        let Expr::Ident(this_ident) = strip_parens(&this_arg.expr) else {
            return None;
        };
        (runtime_ident.sym == this_ident.sym).then(|| runtime_ident.sym.to_string())
    }
}

fn callee_object_for_member_call(call: &CallExpr, expected_prop: &str) -> Option<String> {
    let Callee::Expr(callee) = &call.callee else {
        return None;
    };
    let Expr::Member(MemberExpr { obj, prop, .. }) = strip_parens(callee) else {
        return None;
    };
    if !member_prop_name_is(prop, expected_prop) {
        return None;
    }
    let Expr::Ident(object) = strip_parens(obj) else {
        return None;
    };
    Some(object.sym.to_string())
}

/// Extract the public string id plus a numeric runtime identity when the
/// container key itself is numeric. A quoted numeric key is deliberately not
/// promoted because its property spelling does not prove the type passed to
/// webpack's runtime loader.
fn extract_module_id_from_prop_name(key: &PropName) -> Option<(String, Option<f64>)> {
    match key {
        PropName::Str(s) => Some((s.value.as_str().unwrap_or("unknown").to_string(), None)),
        PropName::Num(n) => Some((
            format!("{}", n.value as i64),
            (n.value.is_finite() && n.value.fract() == 0.0).then_some(n.value),
        )),
        PropName::Ident(i) => Some((i.sym.to_string(), None)),
        _ => None,
    }
}

struct Webpack5ModuleDescriptor<'a> {
    id: String,
    numeric_id: Option<f64>,
    filename: String,
    params: Webpack5FactoryParams<'a>,
    body_stmts: &'a [Stmt],
}

enum Webpack5FactoryParams<'a> {
    Function(&'a [swc_core::ecma::ast::Param]),
    Arrow(&'a [Pat]),
}

fn is_valid_modules_object(modules_object: &ObjectLit) -> Option<()> {
    if modules_object.props.is_empty() {
        return None;
    }
    modules_object
        .props
        .iter()
        .all(|prop| module_descriptor_from_prop(prop).is_some())
        .then_some(())
}

/// A sparse module array: every present element must be a factory function or
/// a `false` placeholder (webpack renders a suppressed module source as the
/// literal `false`), and at least one factory must exist.
fn is_valid_modules_array(array: &ArrayLit) -> Option<()> {
    let mut has_factory = false;
    for elem in array.elems.iter().flatten() {
        if elem.spread.is_some() {
            return None;
        }
        if is_false_module_placeholder(&elem.expr) {
            continue;
        }
        extract_factory_parts(&elem.expr)?;
        has_factory = true;
    }
    has_factory.then_some(())
}

fn is_false_module_placeholder(expr: &Expr) -> bool {
    matches!(strip_parens(expr), Expr::Lit(Lit::Bool(lit)) if !lit.value)
}

fn collect_module_descriptors<'a>(
    modules_container: &Webpack5ModulesContainer<'a>,
) -> Option<Vec<Webpack5ModuleDescriptor<'a>>> {
    let mut descriptors = match modules_container {
        Webpack5ModulesContainer::Object(modules_object) => {
            if modules_object.props.is_empty() {
                return None;
            }
            modules_object
                .props
                .iter()
                .map(module_descriptor_from_prop)
                .collect::<Option<Vec<_>>>()?
        }
        Webpack5ModulesContainer::Array { array, id_offset } => {
            let mut descriptors = Vec::new();
            for (index, elem) in array.elems.iter().enumerate() {
                let Some(elem) = elem else {
                    continue; // array hole
                };
                if elem.spread.is_some() {
                    return None;
                }
                if is_false_module_placeholder(&elem.expr) {
                    continue;
                }
                let (params, body_stmts) = extract_factory_parts(&elem.expr)?;
                let module_id = (id_offset + index).to_string();
                descriptors.push(Webpack5ModuleDescriptor {
                    filename: descriptor_filename(&module_id),
                    id: module_id,
                    numeric_id: Some((id_offset + index) as f64),
                    params,
                    body_stmts,
                });
            }
            if descriptors.is_empty() {
                return None;
            }
            descriptors
        }
    };

    let filenames = super::webpack_common::unique_webpack_module_filenames(
        descriptors.iter().map(|descriptor| descriptor.id.as_str()),
    );
    for (descriptor, filename) in descriptors.iter_mut().zip(filenames) {
        descriptor.filename = filename;
    }
    Some(descriptors)
}

/// Borrow the factory function from a prop, handling both `Prop::KeyValue` and `Prop::Method`.
fn module_descriptor_from_prop(prop: &PropOrSpread) -> Option<Webpack5ModuleDescriptor<'_>> {
    let PropOrSpread::Prop(prop) = prop else {
        return None;
    };
    let (module_id, numeric_id, params, body_stmts) = match &**prop {
        Prop::KeyValue(key_value) => {
            let (module_id, numeric_id) = extract_module_id_from_prop_name(&key_value.key)?;
            let (params, body_stmts) = extract_factory_parts(&key_value.value)?;
            (module_id, numeric_id, params, body_stmts)
        }
        Prop::Method(method) => {
            let (module_id, numeric_id) = extract_module_id_from_prop_name(&method.key)?;
            let body = method.function.body.as_ref()?;
            (
                module_id,
                numeric_id,
                Webpack5FactoryParams::Function(&method.function.params),
                body.stmts.as_slice(),
            )
        }
        _ => return None,
    };
    Some(Webpack5ModuleDescriptor {
        filename: descriptor_filename(&module_id),
        id: module_id,
        numeric_id,
        params,
        body_stmts,
    })
}

fn descriptor_filename(module_id: &str) -> String {
    super::webpack_common::webpack_module_filename(module_id)
}

fn extract_webpack_modules_container(
    var_decl: &VarDecl,
    allow_empty: bool,
) -> Option<(Webpack5ModulesContainer<'_>, Atom)> {
    for decl in &var_decl.decls {
        let VarDeclarator {
            name: Pat::Ident(binding),
            init: Some(init),
            ..
        } = decl
        else {
            continue;
        };
        let container = if allow_empty {
            Webpack5ModulesContainer::from_bootstrap_expr(init)
        } else {
            Webpack5ModulesContainer::from_expr(init)
        };
        let Some(container) = container else {
            continue;
        };
        return Some((container, binding.id.sym.clone()));
    }
    None
}

fn extract_factory_parts(expr: &Expr) -> Option<(Webpack5FactoryParams<'_>, &[Stmt])> {
    match strip_parens(expr) {
        Expr::Fn(FnExpr { function, .. }) => {
            let body = function.body.as_ref()?;
            Some((
                Webpack5FactoryParams::Function(&function.params),
                body.stmts.as_slice(),
            ))
        }
        Expr::Arrow(arrow) => {
            let swc_core::ecma::ast::ArrowFunctionBody::FunctionBody(body) = &*arrow.body else {
                return None;
            };
            Some((
                Webpack5FactoryParams::Arrow(&arrow.params),
                body.stmts.as_slice(),
            ))
        }
        _ => None,
    }
}

fn prepare_webpack5_module(
    descriptor: &Webpack5ModuleDescriptor<'_>,
    id_to_filename: &HashMap<usize, String>,
    str_id_to_filename: &HashMap<String, String>,
) -> Result<PreparedModuleAst, FactoryNormalizationError> {
    let span = tracing::info_span!("webpack5: prepare_module");
    let _enter = span.enter();

    let globals = Globals::new();
    let (synthetic_module, unresolved_mark) = GLOBALS.set(&globals, || {
        let (mut synthetic_module, unresolved_mark) =
            normalize_extracted_webpack_module(descriptor, id_to_filename, str_id_to_filename)?;
        let span = tracing::info_span!("webpack5: fixer");
        let _enter = span.enter();
        apply_fixer(&mut synthetic_module).map_err(|_| FactoryNormalizationError::Fatal)?;
        Ok((synthetic_module, unresolved_mark))
    })?;

    Ok(PreparedModuleAst {
        globals,
        module: synthetic_module,
        unresolved_mark,
        recoverable_parse_errors: Vec::new(),
    })
}

/// Normalize a webpack5 factory body into a standalone module.
///
/// This does only bundler-format work: standardizes factory parameter names,
/// rewrites extracted module references, expands `require.n`, and removes
/// webpack runtime helper/decorator noise. General decompiler rules run later
/// in the driver pipeline.
fn normalize_extracted_webpack_module(
    descriptor: &Webpack5ModuleDescriptor<'_>,
    id_to_filename: &HashMap<usize, String>,
    str_id_to_filename: &HashMap<String, String>,
) -> Result<(Module, Mark), FactoryNormalizationError> {
    let mut synthetic_module = build_module_from_stmts(descriptor.body_stmts.to_vec());

    let param_syms: Vec<Atom> = match descriptor.params {
        Webpack5FactoryParams::Function(params) => params
            .iter()
            .filter_map(|p| match &p.pat {
                Pat::Ident(binding) => Some(binding.sym.clone()),
                _ => None,
            })
            .collect(),
        Webpack5FactoryParams::Arrow(params) => params
            .iter()
            .filter_map(|p| match p {
                Pat::Ident(binding) => Some(binding.sym.clone()),
                _ => None,
            })
            .collect(),
    };

    let unresolved_mark = {
        let span = tracing::info_span!("webpack5: resolver");
        let _enter = span.enter();
        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        synthetic_module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));
        unresolved_mark
    };

    let reused_parameters = super::webpack_common::reused_runtime_parameters(
        &synthetic_module,
        &param_syms,
        unresolved_mark,
        true,
    );

    {
        let span = tracing::info_span!("webpack5: normalize");
        let _enter = span.enter();
        let unresolved_ctxt = SyntaxContext::empty().apply_mark(unresolved_mark);
        let renames = param_syms
            .iter()
            .zip(["module", "exports", "require"])
            .filter(|(source, target)| source.as_ref() != *target)
            .filter(|(source, _)| {
                !reused_parameters
                    .iter()
                    .any(|parameter| parameter.source == **source)
            })
            .map(|(source, target)| BindingRename {
                old: (source.clone(), unresolved_ctxt),
                new: target.into(),
            })
            .collect::<Vec<_>>();
        let external_require_call =
            |call: &CallExpr| is_external_require_call(call, str_id_to_filename);
        if !deconflict_runtime_binding_renames(
            &mut synthetic_module,
            &renames,
            Some(&external_require_call),
        ) {
            return Err(FactoryNormalizationError::FreeNameCapture);
        }
        for rename in &renames {
            let to_ident = Ident::new(rename.new.clone(), Default::default(), unresolved_ctxt);
            replace_ident(&mut synthetic_module, rename.old.clone(), &to_ident);
        }

        for parameter in reused_parameters {
            if !super::webpack_common::localize_reused_runtime_parameter(
                &mut synthetic_module,
                parameter.kind,
                &parameter.source,
                &parameter.binding,
                unresolved_mark,
                &super::webpack_common::ReusedLoaderModuleIds {
                    from_filename: &descriptor.filename,
                    numeric: id_to_filename,
                    string: str_id_to_filename,
                    normalizes_conditional_runtime_members: true,
                },
            ) {
                return Err(FactoryNormalizationError::RuntimeParameterReuse);
            }
        }

        let require_sym = Atom::from("require");

        let mut id_rewriter = RequireIdRewriter {
            require_sym: require_sym.clone(),
            unresolved_mark,
            from_filename: &descriptor.filename,
            id_to_filename,
        };
        synthetic_module.visit_mut_with(&mut id_rewriter);
        let mut str_rewriter = RequireStringIdRewriter {
            require_sym: require_sym.clone(),
            unresolved_mark,
            from_filename: &descriptor.filename,
            id_to_filename: str_id_to_filename,
        };
        synthetic_module.visit_mut_with(&mut str_rewriter);

        rewrite_require_n_accesses(&mut synthetic_module, require_sym.clone(), unresolved_mark);

        let mut normalizer = Webpack5RuntimeNormalizer {
            require_sym,
            unresolved_mark,
        };
        synthetic_module.visit_mut_with(&mut normalizer);

        // Webpack 4-era variable injection can appear inside containers that
        // the shared structural detector prepares through this path. Expose
        // the generated wrapper body before the driver reaches UnEsm.
        unwrap_webpack_global_envelopes(&mut synthetic_module, unresolved_mark);
    }

    Ok((synthetic_module, unresolved_mark))
}

fn extract_iife_stmt_body(stmt: &Stmt) -> Option<&swc_core::ecma::ast::FunctionBody> {
    let Stmt::Expr(ExprStmt { expr, .. }) = stmt else {
        return None;
    };
    extract_iife_body(expr)
}

fn extract_iife_body(expr: &Expr) -> Option<&swc_core::ecma::ast::FunctionBody> {
    let call = match strip_parens(expr) {
        Expr::Call(call) => call,
        Expr::Unary(unary) if unary.op == UnaryOp::Bang => {
            let Expr::Call(call) = strip_parens(&unary.arg) else {
                return None;
            };
            call
        }
        _ => return None,
    };
    // Extraction removes the call itself. It must not discard argument
    // evaluation or turn an async/generator invocation into module execution.
    if !call.args.is_empty() {
        return None;
    }
    extract_callee_body(&call.callee)
}

fn extract_callee_body(callee: &Callee) -> Option<&swc_core::ecma::ast::FunctionBody> {
    let Callee::Expr(callee_expr) = callee else {
        return None;
    };
    match strip_parens(callee_expr) {
        Expr::Fn(FnExpr {
            ident: None,
            function,
        }) if !function.is_async && !function.is_generator && function.params.is_empty() => {
            function.body.as_ref()
        }
        Expr::Arrow(arrow) if !arrow.is_async && arrow.params.is_empty() => match &*arrow.body {
            ArrowFunctionBody::FunctionBody(body) => Some(body),
            _ => None,
        },
        _ => None,
    }
}

#[cfg(test)]
fn sanitize_filename(module_id: &str) -> String {
    super::webpack_common::webpack_module_filename(module_id)
}

/// Scan the bootstrap body for `__webpack_require__(__webpack_require__.s = <id>)` and return
/// the entry module ID as a string.
fn find_require_s_entry(body: &swc_core::ecma::ast::FunctionBody) -> Option<String> {
    for stmt in &body.stmts {
        if let Some(id) = find_require_s_in_stmt(stmt) {
            return Some(id);
        }
    }
    None
}

/// Check a single statement for the `require(require.s = <id>)` pattern.
/// Matches both standalone expression statements and `var x = require(require.s = <id>)`.
fn find_require_s_in_stmt(stmt: &Stmt) -> Option<String> {
    match stmt {
        Stmt::Expr(ExprStmt { expr, .. }) => find_require_s_in_expr(expr),
        Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) => {
            for decl in &var_decl.decls {
                if let Some(init) = &decl.init {
                    if let Some(id) = find_require_s_in_expr(init) {
                        return Some(id);
                    }
                }
            }
            None
        }
        _ => None,
    }
}

/// Check an expression for `require(require.s = <id>)` and extract the module ID.
fn find_require_s_in_expr(expr: &Expr) -> Option<String> {
    let Expr::Call(call) = expr else {
        return None;
    };
    if call.args.len() != 1 {
        return None;
    }
    // The argument should be `require.s = <id>`
    let Expr::Assign(assign) = &*call.args[0].expr else {
        return None;
    };
    if assign.op != AssignOp::Assign {
        return None;
    }
    // Left side: require.s (a member expression)
    let AssignTarget::Simple(SimpleAssignTarget::Member(member)) = &assign.left else {
        return None;
    };
    let MemberProp::Ident(prop_ident) = &member.prop else {
        return None;
    };
    if prop_ident.sym.as_ref() != "s" {
        return None;
    }
    // Right side: the module ID (numeric literal or string)
    match &*assign.right {
        Expr::Lit(Lit::Num(n)) => Some(format!("{}", n.value as i64)),
        Expr::Lit(Lit::Str(s)) => Some(s.value.as_str().unwrap_or("unknown").to_string()),
        _ => None,
    }
}

/// Scan the bootstrap body for webpack 5 runtime startup:
/// `require.O(void 0, [chunkId], function() { return require(<id>); })`.
fn find_require_o_entry(body: &swc_core::ecma::ast::FunctionBody) -> Option<String> {
    for stmt in &body.stmts {
        if let Some(id) = find_require_o_in_stmt(stmt) {
            return Some(id);
        }
    }
    None
}

fn find_require_o_in_stmt(stmt: &Stmt) -> Option<String> {
    match stmt {
        Stmt::Expr(ExprStmt { expr, .. }) => find_require_o_in_expr(expr),
        Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl)) => {
            for decl in &var_decl.decls {
                if let Some(init) = &decl.init {
                    if let Some(id) = find_require_o_in_expr(init) {
                        return Some(id);
                    }
                }
            }
            None
        }
        _ => None,
    }
}

fn find_require_o_in_expr(expr: &Expr) -> Option<String> {
    match strip_parens(expr) {
        Expr::Call(call) => extract_require_o_entry_call(call),
        Expr::Assign(assign) => find_require_o_in_expr(&assign.right),
        Expr::Seq(seq) => seq
            .exprs
            .iter()
            .find_map(|expr| find_require_o_in_expr(expr)),
        _ => None,
    }
}

fn extract_require_o_entry_call(call: &CallExpr) -> Option<String> {
    let require_sym = extract_require_o_callee_sym(&call.callee)?;
    if call.args.len() < 3 {
        return None;
    }
    extract_require_call_from_callback(&call.args[2].expr, require_sym)
}

fn extract_require_o_callee_sym(callee: &Callee) -> Option<&Atom> {
    let Callee::Expr(callee_expr) = callee else {
        return None;
    };
    let Expr::Member(MemberExpr { obj, prop, .. }) = &**callee_expr else {
        return None;
    };
    let MemberProp::Ident(prop_ident) = prop else {
        return None;
    };
    if prop_ident.sym.as_ref() != "O" {
        return None;
    }
    let Expr::Ident(require_ident) = &**obj else {
        return None;
    };
    Some(&require_ident.sym)
}

fn extract_require_call_from_callback(expr: &Expr, require_sym: &Atom) -> Option<String> {
    match strip_parens(expr) {
        Expr::Fn(fn_expr) => {
            let body = fn_expr.function.body.as_ref()?;
            extract_require_call_from_body(body, require_sym)
        }
        Expr::Arrow(arrow) => match &*arrow.body {
            ArrowFunctionBody::FunctionBody(body) => {
                extract_require_call_from_body(body, require_sym)
            }
            ArrowFunctionBody::Expr(expr) => extract_require_call_id(expr, require_sym),
        },
        _ => None,
    }
}

fn extract_require_call_from_body(
    body: &swc_core::ecma::ast::FunctionBody,
    require_sym: &Atom,
) -> Option<String> {
    if body.stmts.len() != 1 {
        return None;
    }
    let Stmt::Return(ret) = &body.stmts[0] else {
        return None;
    };
    let arg = ret.arg.as_ref()?;
    extract_require_call_id(arg, require_sym)
}

fn extract_require_call_id(expr: &Expr, require_sym: &Atom) -> Option<String> {
    let Expr::Call(call) = strip_parens(expr) else {
        return None;
    };
    let Callee::Expr(callee_expr) = &call.callee else {
        return None;
    };
    let Expr::Ident(callee_ident) = &**callee_expr else {
        return None;
    };
    if &callee_ident.sym != require_sym || call.args.len() != 1 {
        return None;
    }
    match &*call.args[0].expr {
        Expr::Lit(Lit::Num(n)) => Some(format!("{}", n.value as i64)),
        Expr::Lit(Lit::Str(s)) => Some(s.value.as_str().unwrap_or("unknown").to_string()),
        _ => None,
    }
}

fn build_module_from_stmts(stmts: Vec<Stmt>) -> Module {
    Module {
        span: Default::default(),
        body: stmts.into_iter().map(ModuleItem::Stmt).collect(),
        shebang: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse_first_var_init(source: &str) -> Box<Expr> {
        GLOBALS.set(&Default::default(), || {
            let cm: Lrc<SourceMap> = Default::default();
            let module = super::super::parse_es_module(source, "test.js", cm.clone())
                .expect("source should parse");
            let ModuleItem::Stmt(Stmt::Decl(swc_core::ecma::ast::Decl::Var(var_decl))) =
                &module.body[0]
            else {
                panic!("expected first statement to be var declaration");
            };
            var_decl.decls[0]
                .init
                .clone()
                .expect("declarator should have init")
        })
    }

    fn parse_modules_object(source: &str) -> ObjectLit {
        let init = parse_first_var_init(source);
        let Expr::Object(object) = strip_parens(&init) else {
            panic!("expected object literal init");
        };
        object.clone()
    }

    #[test]
    fn descriptors_accept_function_arrow_and_method_factories() {
        let object = parse_modules_object(
            r#"
const modules = {
  1: function(module, exports, require) { exports.a = require(2); },
  2: (module, exports, require) => { exports.b = 1; },
  3(module, exports, require) { exports.c = 2; }
};
"#,
        );

        let descriptors = collect_module_descriptors(&Webpack5ModulesContainer::Object(&object))
            .expect("descriptors should collect");
        assert_eq!(descriptors.len(), 3);
        assert_eq!(descriptors[0].id, "1");
        assert_eq!(descriptors[1].id, "2");
        assert_eq!(descriptors[2].id, "3");
        assert!(matches!(
            descriptors[0].params,
            Webpack5FactoryParams::Function(_)
        ));
        assert!(matches!(
            descriptors[1].params,
            Webpack5FactoryParams::Arrow(_)
        ));
        assert!(matches!(
            descriptors[2].params,
            Webpack5FactoryParams::Function(_)
        ));
    }

    #[test]
    fn descriptors_reject_concise_arrow_and_non_function_props() {
        let concise_arrow = parse_modules_object(
            r#"
const modules = {
  1: (module, exports, require) => exports.a
};
"#,
        );
        assert!(
            collect_module_descriptors(&Webpack5ModulesContainer::Object(&concise_arrow)).is_none()
        );

        let non_function = parse_modules_object(
            r#"
const modules = {
  1: 42
};
"#,
        );
        assert!(
            collect_module_descriptors(&Webpack5ModulesContainer::Object(&non_function)).is_none()
        );
    }

    #[test]
    fn array_container_collects_ids_from_holey_array() {
        let init = parse_first_var_init(
            r#"
const modules = ([
  ,
  function(module, exports, require) { exports.a = 1; },
  ,
  (module, exports, require) => { exports.b = 2; }
]);
"#,
        );
        let container =
            Webpack5ModulesContainer::from_expr(&init).expect("array container should match");
        let descriptors =
            collect_module_descriptors(&container).expect("descriptors should collect");
        let ids: Vec<&str> = descriptors.iter().map(|d| d.id.as_str()).collect();
        assert_eq!(ids, vec!["1", "3"]);
        assert_eq!(descriptors[0].filename, "module-1.js");
    }

    #[test]
    fn array_container_applies_concat_offset_and_skips_false() {
        let init = parse_first_var_init(
            r#"
const modules = Array(4).concat([
  function(module, exports, require) { exports.a = 1; },
  false,
  function(module, exports, require) { exports.b = 2; }
]);
"#,
        );
        let container =
            Webpack5ModulesContainer::from_expr(&init).expect("concat container should match");
        let descriptors =
            collect_module_descriptors(&container).expect("descriptors should collect");
        let ids: Vec<&str> = descriptors.iter().map(|d| d.id.as_str()).collect();
        assert_eq!(ids, vec!["4", "6"]);
    }

    #[test]
    fn array_container_rejects_invalid_shapes() {
        // Non-function element
        let non_function = parse_first_var_init("const modules = [function(m, e, r) {}, 42];");
        assert!(Webpack5ModulesContainer::from_expr(&non_function).is_none());

        // Spread element
        let spread = parse_first_var_init("const modules = [...others];");
        assert!(Webpack5ModulesContainer::from_expr(&spread).is_none());

        // Only holes and placeholders — no factory
        let empty = parse_first_var_init("const modules = [, false];");
        assert!(Webpack5ModulesContainer::from_expr(&empty).is_none());
        let empty_object = parse_first_var_init("const modules = {};");
        assert!(Webpack5ModulesContainer::from_expr(&empty_object).is_none());
        assert!(Webpack5ModulesContainer::from_bootstrap_expr(&empty_object).is_some());

        // Concise arrow body is not a factory
        let concise = parse_first_var_init("const modules = [(m, e, r) => e.a];");
        assert!(Webpack5ModulesContainer::from_expr(&concise).is_none());
    }

    #[test]
    fn detects_wp5_cjs_min_numeric_keys_and_method_shorthand() {
        // Minified webpack 5 CJS bundle with numeric keys and method shorthand syntax
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-cjs-min/bundle.js"
        ))
        .expect("failed to read wp5-cjs-min fixture");

        let result = detect_and_extract(&source).expect("wp5-cjs-min should be detected");
        let module_ids: Vec<&str> = result.modules.iter().map(|m| m.id.as_str()).collect();

        // Should extract modules with numeric IDs
        assert!(
            result.modules.len() >= 2,
            "expected at least 2 modules, got {}: {:?}",
            result.modules.len(),
            module_ids
        );
        // Numeric module IDs should be present
        assert!(
            module_ids.iter().any(|id| id.parse::<i64>().is_ok()),
            "expected numeric module IDs, got {:?}",
            module_ids
        );
    }

    #[test]
    fn profiler_separates_webpack_fixer_and_emit() {
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-cjs-min/bundle.js"
        ))
        .expect("failed to read wp5-cjs-min fixture");

        let (result, spans) = crate::test_tracing::record_spans(|| {
            detect_and_extract(&source).expect("wp5-cjs-min should be detected")
        });

        assert!(!result.modules.is_empty());
        for expected in ["webpack5: fixer", "unpacker: prepared emit"] {
            assert!(
                spans.iter().any(|name| name == expected),
                "missing {expected:?} in {spans:?}"
            );
        }
    }

    #[test]
    fn detects_wp5_require_s_entry() {
        // Webpack 5 bundle using __webpack_require__(__webpack_require__.s = 2) for entry
        // shape: hypothetical
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack/wp5-require-s.js"
        ))
        .expect("failed to read wp5-require-s fixture");

        let result = detect_and_extract(&source).expect("wp5-require-s should be detected");
        let module_ids: Vec<&str> = result.modules.iter().map(|m| m.id.as_str()).collect();

        assert!(
            result.modules.len() >= 2,
            "expected at least 2 modules, got {}: {:?}",
            result.modules.len(),
            module_ids
        );
        // Module "2" should be marked as entry
        let entry_modules: Vec<&str> = result
            .modules
            .iter()
            .filter(|m| m.is_entry)
            .map(|m| m.id.as_str())
            .collect();
        assert!(
            entry_modules.contains(&"2"),
            "expected module '2' to be marked as entry, entries: {:?}",
            entry_modules
        );
    }

    #[test]
    fn detects_wp5_require_o_entry() {
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-require-o/bundle.js"
        ))
        .expect("failed to read wp5-require-o fixture");

        assert!(
            source.contains(".O(void 0") && source.contains("=>"),
            "fixture should reproduce webpack 5 require.O arrow startup:\n{source}"
        );

        let result = detect_and_extract(&source).expect("wp5 require.O startup should be detected");
        let entry_modules: Vec<&str> = result
            .modules
            .iter()
            .filter(|m| m.is_entry)
            .map(|m| m.id.as_str())
            .collect();

        assert!(
            entry_modules.len() == 1,
            "expected require.O callback target to be marked as entry"
        );
        let entry_id = entry_modules[0];
        let entry = result
            .modules
            .iter()
            .find(|module| module.id == entry_id)
            .expect("entry id should refer to an extracted module");
        assert!(
            entry.code.contains("entry:"),
            "entry marker should come from require-o-entry.js:\n{}",
            entry.code
        );
    }

    #[test]
    fn detects_ncc_inline_entry() {
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-ncc/index.cjs"
        ))
        .expect("failed to read generated ncc fixture");

        let result = detect_and_extract(&source).expect("ncc bundle should be detected");
        let entry = result
            .modules
            .iter()
            .find(|module| module.filename == "entry.js")
            .expect("ncc inline startup should become entry.js");

        assert!(
            entry.is_entry,
            "synthetic ncc entry should be marked as entry"
        );
        assert!(
            entry.code.contains(r#"require("./module-582.js")"#),
            "ncc runtime require should be normalized:\n{}",
            entry.code
        );
        assert!(
            !entry.code.contains("__nccwpck_require__"),
            "ncc runtime name should not survive:\n{}",
            entry.code
        );
    }

    #[test]
    fn detects_ncc_direct_commonjs_entry() {
        let mut source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-ncc/index.cjs"
        ))
        .expect("failed to read generated ncc fixture");
        let entry_start = source
            .find("var __webpack_exports__ = {};")
            .expect("fixture should contain inline entry start");
        let export = "module.exports = __webpack_exports__;";
        let entry_end = source[entry_start..]
            .find(export)
            .map(|offset| entry_start + offset + export.len())
            .expect("fixture should contain final CommonJS export");
        source.replace_range(
            entry_start..entry_end,
            "module.exports = __nccwpck_require__(582);",
        );

        let result = detect_and_extract(&source).expect("direct ncc startup should be detected");
        assert!(
            result
                .modules
                .iter()
                .any(|module| module.id == "582" && module.is_entry),
            "the directly required module should be marked as entry: {:?}",
            result
                .modules
                .iter()
                .map(|module| (&module.id, module.is_entry))
                .collect::<Vec<_>>()
        );
        assert!(
            result.modules.iter().all(|module| module.id != "entry"),
            "direct startup should not fabricate a synthetic entry"
        );
    }

    #[test]
    fn detects_ncc_export_assignment_in_sequence() {
        let mut source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-ncc/index.cjs"
        ))
        .expect("failed to read generated ncc fixture");
        source = source.replacen(
            "module.exports = __webpack_exports__;",
            "(recordStartup(), module.exports = __webpack_exports__);",
            1,
        );

        let result = detect_and_extract(&source).expect("sequenced ncc export should be detected");
        let entry = result
            .modules
            .iter()
            .find(|module| module.id == "entry")
            .expect("sequenced export should retain the synthetic entry");
        assert!(entry.is_entry);
        assert!(entry.code.contains("recordStartup()"), "{}", entry.code);
    }

    #[test]
    fn keeps_extracted_modules_when_synthetic_entry_emission_fails() {
        let mut modules = vec![UnpackedModule {
            id: "582".to_string(),
            filename: "module-582.js".to_string(),
            ..Default::default()
        }];
        let mut prepared = vec![None];

        assert!(!append_synthetic_entry(
            &mut modules,
            &mut prepared,
            Vec::new(),
            None,
        ));
        assert_eq!(modules.len(), 1);
        assert_eq!(modules[0].id, "582");
        assert_eq!(prepared.len(), modules.len());
    }

    #[test]
    fn materializes_trailing_iife_entry_with_aligned_prepared_modules() {
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-cjs/bundle.js"
        ))
        .expect("failed to read generated webpack fixture");

        let result = detect_and_extract(&source)
            .expect("webpack bundle with a trailing IIFE entry should materialize");
        assert!(
            result
                .modules
                .iter()
                .any(|module| module.filename == "entry.js" && module.is_entry),
            "trailing IIFE should become an entry module"
        );
    }

    #[test]
    fn trailing_iife_entry_rewrites_minified_require_binding() {
        let source = r#"
(()=>{
  var e={1:(m,x)=>{m.exports="dep"}},c={};
  function n(id){
    var hit=c[id];
    if(hit!==undefined)return hit.exports;
    var m=c[id]={exports:{}};
    e[id](m,m.exports,n);
    return m.exports;
  }
  (()=>{const dep=n(1);console.log(dep)})();
})();
"#;

        let result = detect_and_extract(source).expect("minified webpack bundle should unpack");
        let entry = result
            .modules
            .iter()
            .find(|module| module.filename == "entry.js")
            .expect("trailing IIFE should become entry.js");
        assert!(
            entry.code.contains(r#"require("./module-1.js")"#),
            "entry require should resolve to the extracted module:\n{}",
            entry.code
        );
        assert!(
            !entry.code.contains("n(1)"),
            "entry must not retain the discarded runtime require binding:\n{}",
            entry.code
        );
    }

    #[test]
    fn trailing_iife_entry_merged_into_runtime_sequence_is_unwrapped() {
        // shape: producer webpack@5.111.1 mode=production concatenateModules
        // (Terser): the runtime assignments and the strict-mode entry wrapper
        // share one sequence statement.
        let source = r#"
(()=>{
  var e={200(e){e.exports=function(v){return v}}};const r={};
  function t(n){const o=r[n];if(void 0!==o)return o.exports;const i=r[n]={exports:{}};return e[n](i,i.exports,t),i.exports}
  t.n=e=>{const r=e&&e.__esModule?()=>e.default:()=>e;return t.d(r,{a:r}),r},t.d=(e,r)=>{for(var n in r)t.o(r,n)&&!t.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:r[n]})},t.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),(()=>{"use strict";var e=t(200),r=t.n(e);globalThis.sink=r()(1)})()
})();
"#;

        let result = detect_and_extract(source).expect("minified webpack bundle should unpack");
        let entry = result
            .modules
            .iter()
            .find(|module| module.filename == "entry.js")
            .expect("the trailing IIFE should become entry.js");
        assert!(
            entry.code.contains(r#"require("./module-200.js")"#)
                && !entry.code.contains("=>{")
                && !entry.code.trim_end().ends_with(")();"),
            "the entry wrapper should be unwrapped like an unmerged trailing IIFE:\n{}",
            entry.code
        );
    }

    #[test]
    fn sanitize_filename_strips_dot_slash() {
        assert_eq!(sanitize_filename("./src/index.js"), "src/index.js");
    }

    #[test]
    fn sanitize_filename_strips_path_traversal() {
        assert_eq!(sanitize_filename("../../../etc/passwd"), "etc/passwd.js");
        assert_eq!(sanitize_filename("./../../foo.js"), "foo.js");
        assert_eq!(
            sanitize_filename("....//node_modules/@wakaru/cli/bin/wakaru"),
            "..../node_modules/@wakaru/cli/bin/wakaru.js"
        );
    }

    #[test]
    fn sanitize_filename_strips_backslash_traversal() {
        assert_eq!(
            sanitize_filename("./\\..\\node_modules\\debug\\src\\index"),
            "node_modules/debug/src/index.js"
        );
    }

    #[test]
    fn sanitize_filename_empty_after_strip() {
        assert_eq!(sanitize_filename("../"), "unknown.js");
        assert_eq!(sanitize_filename("./"), "unknown.js");
    }

    #[test]
    fn sanitize_filename_preserves_normal_paths() {
        assert_eq!(sanitize_filename("src/utils.js"), "src/utils.js");
        assert_eq!(sanitize_filename("index.js"), "index.js");
        assert_eq!(sanitize_filename("src/view.mts"), "src/view.mts");
        assert_eq!(sanitize_filename("src/style.css"), "src/style.css.js");
        assert_eq!(
            sanitize_filename("src/App.vue?type=script"),
            "src/App.vue.js"
        );
        assert_eq!(sanitize_filename("opaque"), "module-opaque.js");
    }

    #[test]
    fn detects_wp5_cjs_string_keys() {
        // Non-minified webpack 5 CJS bundle with string keys (and method shorthand)
        let source = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/bundles/webpack-gen/dist/wp5-cjs/bundle.js"
        ))
        .expect("failed to read wp5-cjs fixture");

        let result = detect_and_extract(&source).expect("wp5-cjs should be detected");
        let module_ids: Vec<&str> = result.modules.iter().map(|m| m.id.as_str()).collect();

        // Should have 3 modules: 2 library modules + 1 entry
        assert_eq!(
            result.modules.len(),
            3,
            "expected 3 modules, got {}: {:?}",
            result.modules.len(),
            module_ids
        );
        assert!(
            result.modules.iter().any(|m| m.is_entry),
            "expected an entry module, got {:?}",
            module_ids
        );
    }
}
