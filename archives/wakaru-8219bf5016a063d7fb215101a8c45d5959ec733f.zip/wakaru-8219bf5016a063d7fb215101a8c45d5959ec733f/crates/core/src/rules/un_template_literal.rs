use crate::collections::{HashMap, HashSet};

use swc_core::common::{Span, DUMMY_SP};
use swc_core::ecma::ast::{
    ArrowFunctionBody, AssignOp, AssignTarget, BinExpr, BinaryOp, CallExpr, Callee, Decl, Expr,
    Lit, MemberExpr, MemberProp, Module, ModuleItem, Pat, SimpleAssignTarget, Stmt, TaggedTpl, Tpl,
    TplElement,
};
use swc_core::ecma::utils::ExprFactory;
use swc_core::ecma::visit::{VisitMut, VisitMutWith};

use super::cross_module_helper_refs::{
    collect_cross_module_helper_refs, cross_module_member_helper_kind, CrossModuleHelperRefs,
};
use super::helper_matcher::{
    binding_key, expr_binding_key, removable_without_remaining_refs, remove_fn_decls_by_binding,
    remove_import_specifiers_by_binding, remove_var_declarators_by_binding,
    var_declarator_binding_key, BindingKey,
};
use super::transpiler_helper_utils::{LocalHelperContext, TranspilerHelperKind};
use super::RewriteLevel;
use crate::facts::ModuleFactsMap;
use crate::utils::paren::strip_parens;

pub struct UnTemplateLiteral<'a> {
    level: RewriteLevel,
    module_facts: Option<&'a ModuleFactsMap>,
    current_filename: Option<&'a str>,
}

impl UnTemplateLiteral<'_> {
    pub fn new() -> Self {
        Self::new_with_level(RewriteLevel::Standard)
    }

    pub fn new_with_level(level: RewriteLevel) -> Self {
        Self {
            level,
            module_facts: None,
            current_filename: None,
        }
    }
}

impl<'a> UnTemplateLiteral<'a> {
    pub fn new_with_facts(level: RewriteLevel, module_facts: &'a ModuleFactsMap) -> Self {
        Self {
            level,
            module_facts: Some(module_facts),
            current_filename: None,
        }
    }

    pub(crate) fn set_current_filename(&mut self, current_filename: Option<&'a str>) {
        self.current_filename = current_filename;
    }

    pub(crate) fn run_with_helpers(
        &mut self,
        module: &mut Module,
        local_helpers: &LocalHelperContext,
    ) {
        // Tagged-template recovery consumes helper, cache, and factory
        // bindings; a `with` statement or a direct eval anywhere in the module
        // can still reach them by name, so only the binding-free concat and
        // plus-chain rewrites run (docs/rewrite-assumptions.md, dynamic-scope
        // skip).
        if super::eval_utils::has_dynamic_scope_construct(module) {
            module.visit_mut_children_with(self);
            return;
        }
        let cross_module_helpers = self
            .module_facts
            .map(|facts| {
                collect_cross_module_helper_refs(module, facts, self.current_filename, |kind| {
                    kind == TranspilerHelperKind::TaggedTemplateLiteral
                })
            })
            .unwrap_or_default();
        let factories = collect_template_factories(module, &cross_module_helpers, local_helpers);
        let mut replacer = TaggedTemplateReplacer {
            factories: &factories,
            cross_module_helpers: &cross_module_helpers,
            local_helpers,
            consumed_helpers: HashSet::default(),
            consumed_caches: HashSet::default(),
            consumed_factories: HashSet::default(),
        };
        module.visit_mut_children_with(&mut replacer);
        module.visit_mut_children_with(self);

        let mut removable = replacer.consumed_helpers;
        removable.extend(replacer.consumed_caches);
        removable.extend(replacer.consumed_factories);
        if !removable.is_empty() {
            remove_unused_template_bindings(module, &removable);
        }
    }
}

impl Default for UnTemplateLiteral<'_> {
    fn default() -> Self {
        Self::new()
    }
}

enum Part {
    /// Cooked text and the span of the string literal it came from. A string
    /// with a lone surrogate has no UTF-8 form, so the rewrite bails instead
    /// of building text from it.
    Text(String, Span),
    Expr(Box<Expr>),
}

#[derive(Clone)]
struct TemplateData {
    cooked: Vec<Option<String>>,
    raw: Vec<String>,
    helper: Option<BindingKey>,
}

struct TemplateMatch {
    data: TemplateData,
    cache: Option<BindingKey>,
    factory: Option<BindingKey>,
}

impl VisitMut for UnTemplateLiteral<'_> {
    fn visit_mut_module(&mut self, module: &mut Module) {
        let local_helpers = LocalHelperContext::collect(module);
        self.run_with_helpers(module, &local_helpers);
    }

    fn visit_mut_expr(&mut self, expr: &mut Expr) {
        if let Some(next) = rewrite_concat_chain(expr, self.level) {
            *expr = next;
            expr.visit_mut_children_with(self);
        } else if let Some(next) = rewrite_plus_chain(expr, self.level) {
            *expr = next;
            expr.visit_mut_children_with(self);
        } else {
            expr.visit_mut_children_with(self);
        }
        if let Expr::Tpl(tpl) = expr {
            normalize_escaped_newline_template_raw(tpl, self.level);
        }
    }
}

struct TaggedTemplateReplacer<'a> {
    factories: &'a HashMap<BindingKey, TemplateData>,
    cross_module_helpers: &'a CrossModuleHelperRefs,
    local_helpers: &'a LocalHelperContext,
    consumed_helpers: HashSet<BindingKey>,
    consumed_caches: HashSet<BindingKey>,
    consumed_factories: HashSet<BindingKey>,
}

impl VisitMut for TaggedTemplateReplacer<'_> {
    fn visit_mut_with_stmt(&mut self, _stmt: &mut swc_core::ecma::ast::WithStmt) {
        // Dynamic lookup can override even a resolver-proven helper binding.
    }

    fn visit_mut_expr(&mut self, expr: &mut Expr) {
        expr.visit_mut_children_with(self);

        let Expr::Call(call) = expr else {
            return;
        };
        let Some(next) = rewrite_tagged_template_call(
            call,
            self.factories,
            self.cross_module_helpers,
            self.local_helpers,
            &mut self.consumed_helpers,
            &mut self.consumed_caches,
            &mut self.consumed_factories,
        ) else {
            return;
        };
        *expr = next;
    }
}

/// `"a".concat(b, "c")` → `` `a${b}c` `` — the Babel 7+ spec-mode, SWC
/// (non-loose), esbuild ≥ 0.12.6, and TypeScript ≥ 4.5 lowering of a template
/// literal.
///
/// `String.prototype.concat` evaluates every argument before coercing any of
/// them; a template coerces each substitution before evaluating the next. The
/// two differ only when a substitution's coercion has effects a later
/// substitution's evaluation can observe. `standard` accepts that under the
/// `concat_coercion_order` assumption (`rewrite-assumptions.md`); the
/// string-literal receiver is strong producer evidence, not a proof. `minimal`
/// rewrites only when every substitution is a syntax-proven primitive, where
/// coercion is the identity and the two orders coincide. Like every rewrite
/// of a builtin method call, this relies on the execution-environment
/// baseline (`String.prototype.concat` is the intrinsic; see
/// `rewrite-assumptions.md`), not on anything the AST proves.
fn rewrite_concat_chain(expr: &Expr, level: RewriteLevel) -> Option<Expr> {
    let Expr::Call(call) = expr else {
        return None;
    };

    let mut parts = Vec::new();
    if !collect_concat_parts(call, &mut parts) {
        return None;
    }
    if level == RewriteLevel::Minimal && !substitutions_are_syntax_proven_primitive(&parts) {
        return None;
    }

    let tpl = parts_to_template(parts, call.span);
    Some(Expr::Tpl(tpl))
}

fn collect_concat_parts(call: &CallExpr, out: &mut Vec<Part>) -> bool {
    let Callee::Expr(callee_expr) = &call.callee else {
        return false;
    };
    let Expr::Member(MemberExpr { obj, prop, .. }) = &**callee_expr else {
        return false;
    };
    if !matches!(prop, MemberProp::Ident(ident) if ident.sym == "concat") {
        return false;
    }

    match &**obj {
        Expr::Call(prev_call) => {
            if !collect_concat_parts(prev_call, out) {
                return false;
            }
        }
        Expr::Lit(Lit::Str(s)) => {
            let Some(text) = s.value.as_str() else {
                return false;
            };
            out.push(Part::Text(text.to_owned(), s.span))
        }
        _ => return false,
    }

    for arg in &call.args {
        if arg.spread.is_some() {
            return false;
        }
        match &*arg.expr {
            Expr::Lit(Lit::Str(s)) => {
                let Some(text) = s.value.as_str() else {
                    return false;
                };
                out.push(Part::Text(text.to_owned(), s.span))
            }
            other => out.push(Part::Expr(Box::new(other.clone()))),
        }
    }

    true
}

fn rewrite_tagged_template_call(
    call: &CallExpr,
    factories: &HashMap<BindingKey, TemplateData>,
    cross_module_helpers: &CrossModuleHelperRefs,
    local_helpers: &LocalHelperContext,
    consumed_helpers: &mut HashSet<BindingKey>,
    consumed_caches: &mut HashSet<BindingKey>,
    consumed_factories: &mut HashSet<BindingKey>,
) -> Option<Expr> {
    if call.args.is_empty() || call.args.iter().any(|arg| arg.spread.is_some()) {
        return None;
    }

    let template_match = extract_template_match(
        call.args[0].expr.as_ref(),
        factories,
        cross_module_helpers,
        local_helpers,
    )?;
    if template_match.data.cooked.len() != call.args.len() {
        return None;
    }

    if let Some(helper) = &template_match.data.helper {
        if !cross_module_helpers.direct.contains_key(helper) {
            consumed_helpers.insert(helper.clone());
        }
    }
    if let Some(cache) = template_match.cache {
        consumed_caches.insert(cache);
    }
    if let Some(factory) = template_match.factory {
        consumed_factories.insert(factory);
    }

    let Callee::Expr(tag) = &call.callee else {
        return None;
    };
    let exprs = call
        .args
        .iter()
        .skip(1)
        .map(|arg| arg.expr.clone())
        .collect();

    Some(Expr::TaggedTpl(TaggedTpl {
        span: call.span,
        ctxt: call.ctxt,
        tag: tag.clone(),
        type_params: call.type_args.clone(),
        tpl: Box::new(template_match.data.into_tpl(exprs, call.span)),
    }))
}

fn extract_template_match(
    expr: &Expr,
    factories: &HashMap<BindingKey, TemplateData>,
    cross_module_helpers: &CrossModuleHelperRefs,
    local_helpers: &LocalHelperContext,
) -> Option<TemplateMatch> {
    let expr = strip_parens(expr);

    if let Some((data, helper)) =
        extract_direct_template_helper_call(expr, cross_module_helpers, local_helpers)
    {
        return Some(TemplateMatch {
            data: TemplateData { helper, ..data },
            cache: None,
            factory: None,
        });
    }

    if let Some((factory, data)) = extract_template_factory_call(expr, factories) {
        return Some(TemplateMatch {
            data: data.clone(),
            cache: None,
            factory: Some(factory),
        });
    }

    let Expr::Bin(BinExpr {
        op: BinaryOp::LogicalOr,
        left,
        right,
        ..
    }) = expr
    else {
        return None;
    };
    let cache = expr_binding_key(strip_parens(left))?;
    let Expr::Assign(assign) = strip_parens(right) else {
        return None;
    };
    if assign.op != AssignOp::Assign {
        return None;
    }
    let AssignTarget::Simple(SimpleAssignTarget::Ident(target)) = &assign.left else {
        return None;
    };
    let target_key = binding_key(&target.id);
    if target_key != cache {
        return None;
    }
    let (data, helper) = extract_direct_template_helper_call(
        strip_parens(&assign.right),
        cross_module_helpers,
        local_helpers,
    )?;

    Some(TemplateMatch {
        data: TemplateData { helper, ..data },
        cache: Some(cache),
        factory: None,
    })
}

fn extract_template_factory_call<'a>(
    expr: &Expr,
    factories: &'a HashMap<BindingKey, TemplateData>,
) -> Option<(BindingKey, &'a TemplateData)> {
    let Expr::Call(call) = expr else {
        return None;
    };
    if !call.args.is_empty() {
        return None;
    }
    let Callee::Expr(callee) = &call.callee else {
        return None;
    };
    let key = expr_binding_key(strip_parens(callee))?;
    factories
        .get_key_value(&key)
        .map(|(key, data)| (key.clone(), data))
}

fn extract_direct_template_helper_call(
    expr: &Expr,
    cross_module_helpers: &CrossModuleHelperRefs,
    local_helpers: &LocalHelperContext,
) -> Option<(TemplateData, Option<BindingKey>)> {
    let Expr::Call(call) = expr else {
        return None;
    };
    if call.args.is_empty()
        || call.args.len() > 2
        || call.args.iter().any(|arg| arg.spread.is_some())
    {
        return None;
    }

    let helper = match &call.callee {
        Callee::Expr(callee) => {
            let callee = strip_parens(callee);
            if let Some(helper) = expr_binding_key(callee) {
                if !is_template_helper_name(helper.0.as_ref())
                    && !cross_module_helpers.direct.contains_key(&helper)
                    && !local_helpers
                        .is_helper_callee(callee, TranspilerHelperKind::TaggedTemplateLiteral)
                {
                    return None;
                }
                Some(helper)
            } else if cross_module_member_helper_kind(callee, &cross_module_helpers.namespaces)
                == Some(TranspilerHelperKind::TaggedTemplateLiteral)
                || local_helpers
                    .is_helper_callee(callee, TranspilerHelperKind::TaggedTemplateLiteral)
                || is_inline_template_helper(callee)
            {
                None
            } else {
                return None;
            }
        }
        _ => return None,
    };

    let cooked = collect_template_array(call.args[0].expr.as_ref())?;
    let raw = if call.args.len() == 2 {
        collect_template_array(call.args[1].expr.as_ref())?
            .into_iter()
            .collect::<Option<Vec<_>>>()?
    } else {
        cooked
            .iter()
            .map(|value| value.as_deref().map(escape_template_raw_cooked_copy))
            .collect::<Option<Vec<_>>>()?
    };

    if cooked.len() != raw.len() || cooked.is_empty() {
        return None;
    }

    Some((
        TemplateData {
            cooked,
            raw,
            helper: None,
        },
        helper,
    ))
}

fn is_inline_template_helper(expr: &Expr) -> bool {
    match strip_parens(expr) {
        Expr::Fn(fn_expr) => {
            if fn_expr.function.params.len() != 2 {
                return false;
            }
            if !fn_expr
                .function
                .params
                .iter()
                .all(|param| matches!(param.pat, Pat::Ident(_)))
            {
                return false;
            }
            fn_expr.function.body.as_ref().is_some_and(|body| {
                body.stmts
                    .iter()
                    .any(|stmt| matches!(stmt, Stmt::Return(_)))
            })
        }
        Expr::Arrow(arrow) => {
            arrow.params.len() == 2
                && arrow
                    .params
                    .iter()
                    .all(|param| matches!(param, Pat::Ident(_)))
                && match arrow.body.as_ref() {
                    ArrowFunctionBody::Expr(_) => true,
                    ArrowFunctionBody::FunctionBody(body) => body
                        .stmts
                        .iter()
                        .any(|stmt| matches!(stmt, Stmt::Return(_))),
                }
        }
        _ => false,
    }
}

/// Convert `"str" + a + b` (binary `+` chains with at least one string literal)
/// into a template literal.
///
/// Safety: only transforms when at least one operand in the chain is a string
/// literal. All non-string elements that appear **before** the first string
/// literal are grouped into a single sub-expression to preserve arithmetic
/// semantics (e.g. `a + b + "c"` → `` `${a + b}c` `` not `` `${a}${b}c` ``).
///
/// A plus chain evaluates and coerces its operands in the same order a
/// template does; the only difference is the coercion hint (`+` uses
/// `default`, a template uses `string`), which matters for objects whose
/// `valueOf` and `toString` disagree. Babel loose mode, Babel 6, SWC loose
/// (≥ 1.2.155), TypeScript ≤ 4.4, esbuild ≤ 0.12.5, and Closure (ES5 output)
/// lower templates to this exact shape, indistinguishable from handwritten
/// concatenation. `standard` accepts the hint change under the
/// `string_coercion_hint` assumption (`rewrite-assumptions.md`); `minimal`
/// rewrites only when every substitution is a syntax-proven primitive, where
/// the hint is irrelevant.
fn rewrite_plus_chain(expr: &Expr, level: RewriteLevel) -> Option<Expr> {
    // Collect the flat left-associative operand list
    let mut operands: Vec<&Expr> = Vec::new();
    collect_add_chain(expr, &mut operands);

    // Must have at least 2 operands and at least one string literal
    if operands.len() < 2 {
        return None;
    }
    let first_str_idx = operands.iter().position(|e| is_str_lit(e))?;

    // Determine the span for the resulting template
    let span = match expr {
        Expr::Bin(b) => b.span,
        _ => DUMMY_SP,
    };

    // Build the parts list:
    // – everything before the first string literal is grouped into one Expr part
    //   (to avoid splitting arithmetic sub-expressions like `a + b`)
    // – from the first string literal onward, each element becomes Text or Expr
    let mut parts: Vec<Part> = Vec::new();

    if first_str_idx > 0 {
        let grouped = rebuild_add_chain(&operands[..first_str_idx]);
        parts.push(Part::Expr(grouped));
    }

    for op in &operands[first_str_idx..] {
        if let Expr::Lit(Lit::Str(s)) = op {
            parts.push(Part::Text(s.value.as_str()?.to_owned(), s.span));
        } else {
            parts.push(Part::Expr(Box::new((*op).clone())));
        }
    }

    // Must have at least one Expr part — a pure string-literal chain is not worth
    // converting (it would just be `\`constant\``).
    if !parts.iter().any(|p| matches!(p, Part::Expr(_))) {
        return None;
    }
    if level == RewriteLevel::Minimal && !substitutions_are_syntax_proven_primitive(&parts) {
        return None;
    }

    Some(Expr::Tpl(parts_to_template(parts, span)))
}

fn substitutions_are_syntax_proven_primitive(parts: &[Part]) -> bool {
    parts.iter().all(|part| match part {
        Part::Text(..) => true,
        Part::Expr(expr) => is_syntax_proven_primitive(expr),
    })
}

/// Whether an expression's value is a primitive by syntax alone. ToPrimitive
/// is the identity on primitives, so for these substitutions neither the
/// coercion hint nor the coercion order can be observed and the template
/// rewrite is exact at every level.
///
/// Unary and binary operators always produce primitives (any exception they
/// raise happens while evaluating the operand, identically in both forms), so
/// they count regardless of their operands. Identifiers do not: even
/// `undefined` or `NaN` would need the resolver mark to be trusted here.
fn is_syntax_proven_primitive(expr: &Expr) -> bool {
    match strip_parens(expr) {
        Expr::Lit(lit) => !matches!(lit, Lit::Regex(_) | Lit::JSXText(_)),
        Expr::Tpl(_) => true,
        Expr::Unary(_) | Expr::Update(_) => true,
        // Logical operators yield one of their operands unchanged; every
        // other binary operator yields a number, bigint, boolean, or string.
        Expr::Bin(bin) => match bin.op {
            BinaryOp::LogicalAnd | BinaryOp::LogicalOr | BinaryOp::NullishCoalescing => {
                is_syntax_proven_primitive(&bin.left) && is_syntax_proven_primitive(&bin.right)
            }
            _ => true,
        },
        Expr::Cond(cond) => {
            is_syntax_proven_primitive(&cond.cons) && is_syntax_proven_primitive(&cond.alt)
        }
        Expr::Seq(seq) => seq
            .exprs
            .last()
            .is_some_and(|last| is_syntax_proven_primitive(last)),
        _ => false,
    }
}

/// Flatten a left-associative `+` chain into individual operands.
fn collect_add_chain<'a>(expr: &'a Expr, out: &mut Vec<&'a Expr>) {
    if let Expr::Bin(BinExpr {
        op: BinaryOp::Add,
        left,
        right,
        ..
    }) = expr
    {
        collect_add_chain(left, out);
        out.push(right);
    } else {
        out.push(expr);
    }
}

fn is_str_lit(expr: &Expr) -> bool {
    matches!(expr, Expr::Lit(Lit::Str(_)))
}

fn normalize_escaped_newline_template_raw(tpl: &mut Tpl, level: RewriteLevel) {
    if level == RewriteLevel::Minimal {
        return;
    }

    for quasi in &mut tpl.quasis {
        if quasi.cooked.is_none() {
            continue;
        }
        let raw = quasi.raw.to_string();
        let Some(next) = normalize_newline_escapes(&raw) else {
            continue;
        };
        quasi.raw = next.into();
    }
}

fn normalize_newline_escapes(raw: &str) -> Option<String> {
    if !raw.contains("\\n") || raw.contains("\\r") {
        return None;
    }

    let mut output = String::with_capacity(raw.len());
    let mut chars = raw.chars().peekable();
    let mut changed = false;

    while let Some(ch) = chars.next() {
        if ch != '\\' {
            output.push(ch);
            continue;
        }

        match chars.peek().copied() {
            Some('n') => {
                chars.next();
                output.push('\n');
                changed = true;
            }
            Some(next) => {
                chars.next();
                output.push('\\');
                output.push(next);
            }
            None => output.push('\\'),
        }
    }

    changed.then_some(output)
}

fn collect_template_factories(
    module: &Module,
    cross_module_helpers: &CrossModuleHelperRefs,
    local_helpers: &LocalHelperContext,
) -> HashMap<BindingKey, TemplateData> {
    module
        .body
        .iter()
        .filter_map(|item| {
            let ModuleItem::Stmt(Stmt::Decl(Decl::Fn(func))) = item else {
                return None;
            };
            let body = func.function.body.as_ref()?;
            let data = extract_template_from_factory_body(
                &body.stmts,
                cross_module_helpers,
                local_helpers,
            )?;
            Some((binding_key(&func.ident), data))
        })
        .collect()
}

fn extract_template_from_factory_body(
    stmts: &[Stmt],
    cross_module_helpers: &CrossModuleHelperRefs,
    local_helpers: &LocalHelperContext,
) -> Option<TemplateData> {
    let mut locals: HashMap<BindingKey, TemplateData> = HashMap::default();

    for stmt in stmts {
        match stmt {
            Stmt::Decl(Decl::Var(var)) => {
                for decl in &var.decls {
                    let Some(key) = var_declarator_binding_key(decl) else {
                        continue;
                    };
                    let Some(init) = decl.init.as_deref() else {
                        continue;
                    };
                    if let Some((data, helper)) = extract_direct_template_helper_call(
                        init,
                        cross_module_helpers,
                        local_helpers,
                    ) {
                        locals.insert(key, TemplateData { helper, ..data });
                    }
                }
            }
            Stmt::Return(ret) => {
                let arg = ret.arg.as_deref()?;
                if let Some(key) = expr_binding_key(strip_parens(arg)) {
                    if let Some(data) = locals.get(&key) {
                        return Some(data.clone());
                    }
                }
                if let Some((data, helper)) =
                    extract_direct_template_helper_call(arg, cross_module_helpers, local_helpers)
                {
                    return Some(TemplateData { helper, ..data });
                }
            }
            _ => {}
        }
    }

    None
}

fn collect_template_array(expr: &Expr) -> Option<Vec<Option<String>>> {
    let Expr::Array(array) = strip_parens(expr) else {
        return None;
    };
    array
        .elems
        .iter()
        .map(|elem| {
            let elem = elem.as_ref()?;
            if elem.spread.is_some() {
                return None;
            }
            match elem.expr.as_ref() {
                Expr::Lit(Lit::Str(s)) => Some(Some(s.value.as_str()?.to_owned())),
                Expr::Ident(id) if id.sym.as_ref() == "undefined" => Some(None),
                Expr::Unary(unary)
                    if unary.op == swc_core::ecma::ast::UnaryOp::Void
                        && matches!(unary.arg.as_ref(), Expr::Lit(Lit::Num(_))) =>
                {
                    Some(None)
                }
                _ => None,
            }
        })
        .collect()
}

fn is_template_helper_name(name: &str) -> bool {
    matches!(
        name,
        "_taggedTemplateLiteral"
            | "_taggedTemplateLiteralLoose"
            | "_tagged_template_literal"
            | "_tagged_template_literal_loose"
            | "__makeTemplateObject"
            | "__template"
    )
}

/// Re-assemble a slice of expressions into a left-associative `+` chain.
fn rebuild_add_chain(exprs: &[&Expr]) -> Box<Expr> {
    debug_assert!(!exprs.is_empty());
    let mut acc = Box::new((*exprs[0]).clone());
    for e in &exprs[1..] {
        acc = Box::new((*acc).make_bin(BinaryOp::Add, (*e).clone()));
    }
    acc
}

impl TemplateData {
    fn into_tpl(self, exprs: Vec<Box<Expr>>, span: swc_core::common::Span) -> Tpl {
        let last = self.cooked.len().saturating_sub(1);
        let quasis = self
            .cooked
            .into_iter()
            .zip(self.raw)
            .enumerate()
            .map(|(index, (cooked, raw))| TplElement {
                span,
                tail: index == last,
                cooked: cooked.map(Into::into),
                raw: raw.into(),
            })
            .collect();

        Tpl {
            span,
            exprs,
            quasis,
        }
    }
}

/// Each quasi spans the string literals merged into it, so its text maps to
/// those literals; a quasi with no literal (an empty head or tail) keeps the
/// whole template's span.
fn parts_to_template(parts: Vec<Part>, span: swc_core::common::Span) -> Tpl {
    let mut quasis = Vec::new();
    let mut exprs = Vec::new();
    let mut current = String::new();
    let mut current_span: Option<Span> = None;

    for part in parts {
        match part {
            Part::Text(text, text_span) => {
                current.push_str(&text);
                if !text_span.is_dummy() {
                    current_span = Some(match current_span {
                        Some(merged) => Span::new(merged.lo, text_span.hi),
                        None => text_span,
                    });
                }
            }
            Part::Expr(expr) => {
                quasis.push(TplElement {
                    span: current_span.take().unwrap_or(span),
                    tail: false,
                    cooked: Some(current.clone().into()),
                    raw: escape_template_raw(&current).into(),
                });
                current.clear();
                exprs.push(expr);
            }
        }
    }

    quasis.push(TplElement {
        span: current_span.unwrap_or(span),
        tail: true,
        cooked: Some(current.clone().into()),
        raw: escape_template_raw(&current).into(),
    });

    Tpl {
        span,
        exprs,
        quasis,
    }
}

fn escape_template_raw(input: &str) -> String {
    input
        .replace('\\', "\\\\")
        .replace('`', "\\`")
        .replace('$', "\\$")
        .replace('\n', "\\n")
        .replace('\t', "\\t")
        .replace('\r', "\\r")
}

fn escape_template_raw_cooked_copy(input: &str) -> String {
    input
        .replace('\\', "\\\\")
        .replace('`', "\\`")
        .replace("${", "\\${")
}

fn remove_unused_template_bindings(module: &mut Module, candidates: &HashSet<BindingKey>) {
    let unused = removable_without_remaining_refs(module, candidates);
    if unused.is_empty() {
        return;
    }

    remove_fn_decls_by_binding(module, &unused);
    remove_import_specifiers_by_binding(&mut module.body, &unused);
    remove_var_declarators_by_binding(&mut module.body, &unused);
}
