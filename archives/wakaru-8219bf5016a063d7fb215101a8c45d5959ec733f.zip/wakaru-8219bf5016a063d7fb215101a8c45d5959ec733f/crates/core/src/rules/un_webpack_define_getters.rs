use crate::collections::HashSet;

use swc_core::common::{Mark, Span, Spanned, SyntaxContext, DUMMY_SP};
use swc_core::ecma::ast::{
    Bool, CallExpr, Callee, Decl, Expr, ExprStmt, Ident, IdentName, KeyValueProp, Lit, Module,
    ModuleDecl, ModuleItem, ObjectLit, Pat, Prop, PropName, PropOrSpread, Stmt, Str, VarDeclarator,
};
use swc_core::ecma::utils::ExprFactory;
use swc_core::ecma::visit::{VisitMut, VisitMutWith};

use super::decl_utils::BindingId;

pub struct UnWebpackDefineGetters {
    unresolved_mark: Mark,
}

impl UnWebpackDefineGetters {
    pub fn new(unresolved_mark: Mark) -> Self {
        Self { unresolved_mark }
    }
}

impl VisitMut for UnWebpackDefineGetters {
    fn visit_mut_module(&mut self, module: &mut Module) {
        // The rewrite reads `require` as the webpack runtime and emits a
        // reference to the global `Object`; a `with` statement or a direct
        // eval anywhere in the module can rebind either, so the module is
        // left as is (docs/rewrite-assumptions.md, dynamic-scope skip).
        if super::eval_utils::has_dynamic_scope_construct(module) {
            return;
        }
        module.visit_mut_children_with(self);
        rewrite_module_items(&mut module.body, self.unresolved_mark);
    }

    fn visit_mut_stmts(&mut self, stmts: &mut Vec<Stmt>) {
        stmts.visit_mut_children_with(self);
        rewrite_stmts(stmts, self.unresolved_mark);
    }
}

fn take_item(items: &mut [ModuleItem], i: usize) -> ModuleItem {
    std::mem::replace(
        &mut items[i],
        ModuleItem::Stmt(Stmt::Empty(swc_core::ecma::ast::EmptyStmt {
            span: DUMMY_SP,
        })),
    )
}

fn take_stmt(stmts: &mut [Stmt], i: usize) -> Stmt {
    std::mem::replace(
        &mut stmts[i],
        Stmt::Empty(swc_core::ecma::ast::EmptyStmt { span: DUMMY_SP }),
    )
}

fn rewrite_module_items(items: &mut Vec<ModuleItem>, unresolved_mark: Mark) {
    let mut original = std::mem::take(items);
    let mut rewritten = Vec::with_capacity(original.len());
    let mut i = 0;

    while i < original.len() {
        if let Some(binding) = extract_empty_object_binding_from_module_item(&original[i]) {
            let (replacement, next_index, exports) =
                maybe_build_define_properties_item(&original, i + 1, &binding, unresolved_mark);
            if let Some(item) = replacement {
                rewritten.push(take_item(&mut original, i));
                rewritten.push(item);
                for index in exports {
                    rewritten.push(take_item(&mut original, index));
                }
                i = next_index;
                continue;
            }
        }

        rewritten.push(take_item(&mut original, i));
        i += 1;
    }

    *items = rewritten;
}

fn rewrite_stmts(stmts: &mut Vec<Stmt>, unresolved_mark: Mark) {
    let mut original = std::mem::take(stmts);
    let mut rewritten = Vec::with_capacity(original.len());
    let mut i = 0;

    while i < original.len() {
        if let Some(binding) = extract_empty_object_binding_from_stmt(&original[i]) {
            let (replacement, next_index) =
                maybe_build_define_properties_stmt(&original, i + 1, &binding, unresolved_mark);
            if let Some(stmt) = replacement {
                rewritten.push(take_stmt(&mut original, i));
                rewritten.push(stmt);
                i = next_index;
                continue;
            }
        }

        rewritten.push(take_stmt(&mut original, i));
        i += 1;
    }

    *stmts = rewritten;
}

fn maybe_build_define_properties_item(
    items: &[ModuleItem],
    start: usize,
    target: &BindingId,
    unresolved_mark: Mark,
) -> (Option<ModuleItem>, usize, Vec<usize>) {
    let (descriptors, first_span, next_index, exports) =
        collect_require_d_descriptors_module(items, start, target, unresolved_mark);
    if descriptors.len() < 2 {
        return (None, start, Vec::new());
    }

    let stmt_span = if first_span.lo.0 != 0 {
        first_span
    } else {
        DUMMY_SP
    };

    (
        Some(ModuleItem::Stmt(Stmt::Expr(ExprStmt {
            span: stmt_span,
            expr: Box::new(build_define_properties_call(
                target.clone(),
                descriptors,
                stmt_span,
                unresolved_mark,
            )),
        }))),
        next_index,
        exports,
    )
}

fn maybe_build_define_properties_stmt(
    stmts: &[Stmt],
    start: usize,
    target: &BindingId,
    unresolved_mark: Mark,
) -> (Option<Stmt>, usize) {
    let (descriptors, first_span, next_index) =
        collect_require_d_descriptors_stmt(stmts, start, target, unresolved_mark);
    if descriptors.len() < 2 {
        return (None, start);
    }

    let stmt_span = if first_span.lo.0 != 0 {
        first_span
    } else {
        DUMMY_SP
    };

    (
        Some(Stmt::Expr(ExprStmt {
            span: stmt_span,
            expr: Box::new(build_define_properties_call(
                target.clone(),
                descriptors,
                stmt_span,
                unresolved_mark,
            )),
        })),
        next_index,
    )
}

/// The `require.d(target, ...)` run after `start`. Local export specifiers
/// in the run (`export { target as name }`, placed after the declaration)
/// run no code; their indices are returned so they can follow the merged
/// call.
fn collect_require_d_descriptors_module(
    items: &[ModuleItem],
    start: usize,
    target: &BindingId,
    unresolved_mark: Mark,
) -> (Vec<(String, Box<Expr>)>, Span, usize, Vec<usize>) {
    let mut descriptors = Vec::new();
    let mut seen = HashSet::default();
    let mut index = start;
    let mut first_span = DUMMY_SP;
    let mut exports = Vec::new();
    let mut end = start;

    while index < items.len() {
        let stmt = match &items[index] {
            ModuleItem::Stmt(stmt) => stmt,
            ModuleItem::ModuleDecl(ModuleDecl::ExportNamed(export)) if export.src.is_none() => {
                exports.push(index);
                index += 1;
                continue;
            }
            _ => break,
        };
        let Some((name, getter)) = extract_require_d_descriptor(stmt, target, unresolved_mark)
        else {
            break;
        };
        if descriptors.is_empty() {
            first_span = stmt.span();
        }
        if !seen.insert(name.clone()) {
            return (Vec::new(), DUMMY_SP, start, Vec::new());
        }
        descriptors.push((name, getter));
        index += 1;
        end = index;
    }
    // Specifiers after the last descriptor stay where they are.
    exports.retain(|&export| export < end);

    (descriptors, first_span, end, exports)
}

fn collect_require_d_descriptors_stmt(
    stmts: &[Stmt],
    start: usize,
    target: &BindingId,
    unresolved_mark: Mark,
) -> (Vec<(String, Box<Expr>)>, Span, usize) {
    let mut descriptors = Vec::new();
    let mut seen = HashSet::default();
    let mut index = start;
    let mut first_span = DUMMY_SP;

    while index < stmts.len() {
        let Some((name, getter)) =
            extract_require_d_descriptor(&stmts[index], target, unresolved_mark)
        else {
            break;
        };
        if index == start {
            first_span = stmts[index].span();
        }
        if !seen.insert(name.clone()) {
            return (Vec::new(), DUMMY_SP, start);
        }
        descriptors.push((name, getter));
        index += 1;
    }

    (descriptors, first_span, index)
}

fn extract_empty_object_binding_from_module_item(item: &ModuleItem) -> Option<BindingId> {
    match item {
        ModuleItem::Stmt(stmt) => extract_empty_object_binding_from_stmt(stmt),
        ModuleItem::ModuleDecl(ModuleDecl::ExportDecl(export_decl)) => {
            let Decl::Var(var_decl) = &export_decl.decl else {
                return None;
            };
            extract_empty_object_binding_from_var_decl(&var_decl.decls)
        }
        _ => None,
    }
}

fn extract_empty_object_binding_from_stmt(stmt: &Stmt) -> Option<BindingId> {
    let Stmt::Decl(Decl::Var(var_decl)) = stmt else {
        return None;
    };
    extract_empty_object_binding_from_var_decl(&var_decl.decls)
}

fn extract_empty_object_binding_from_var_decl(decls: &[VarDeclarator]) -> Option<BindingId> {
    if decls.len() != 1 {
        return None;
    }
    let decl = &decls[0];
    let Pat::Ident(binding) = &decl.name else {
        return None;
    };
    let Expr::Object(obj) = decl.init.as_deref()? else {
        return None;
    };
    if !obj.props.is_empty() {
        return None;
    }
    Some((binding.id.sym.clone(), binding.id.ctxt))
}

fn extract_require_d_descriptor(
    stmt: &Stmt,
    target: &BindingId,
    unresolved_mark: Mark,
) -> Option<(String, Box<Expr>)> {
    let Stmt::Expr(ExprStmt { expr, .. }) = stmt else {
        return None;
    };
    let Expr::Call(call) = expr.as_ref() else {
        return None;
    };
    let Callee::Expr(callee_expr) = &call.callee else {
        return None;
    };
    let Expr::Member(member) = callee_expr.as_ref() else {
        return None;
    };
    let Expr::Ident(require_ident) = member.obj.as_ref() else {
        return None;
    };
    if require_ident.sym.as_ref() != "require" || require_ident.ctxt.outer() != unresolved_mark {
        return None;
    }
    let swc_core::ecma::ast::MemberProp::Ident(prop) = &member.prop else {
        return None;
    };
    if prop.sym.as_ref() != "d" || call.args.len() != 3 {
        return None;
    }

    let Expr::Ident(target_ident) = call.args[0].expr.as_ref() else {
        return None;
    };
    if target_ident.sym != target.0 || target_ident.ctxt != target.1 {
        return None;
    }

    let Expr::Lit(Lit::Str(name)) = call.args[1].expr.as_ref() else {
        return None;
    };
    let prop_name = name.value.as_str()?.to_string();

    match call.args[2].expr.as_ref() {
        Expr::Fn(_) | Expr::Arrow(_) => Some((prop_name, call.args[2].expr.clone())),
        _ => None,
    }
}

fn build_define_properties_call(
    target: BindingId,
    descriptors: Vec<(String, Box<Expr>)>,
    span: Span,
    unresolved_mark: Mark,
) -> Expr {
    let descriptor_props: Vec<PropOrSpread> = descriptors
        .into_iter()
        .map(|(name, getter)| {
            PropOrSpread::Prop(Box::new(Prop::KeyValue(KeyValueProp {
                key: make_prop_name(&name),
                value: Box::new(Expr::Object(ObjectLit {
                    span: DUMMY_SP,
                    props: vec![
                        PropOrSpread::Prop(Box::new(Prop::KeyValue(KeyValueProp {
                            key: PropName::Ident(IdentName::new("enumerable".into(), DUMMY_SP)),
                            value: Box::new(Expr::Lit(Lit::Bool(Bool {
                                span: DUMMY_SP,
                                value: true,
                            }))),
                        }))),
                        PropOrSpread::Prop(Box::new(Prop::KeyValue(KeyValueProp {
                            key: PropName::Ident(IdentName::new("get".into(), DUMMY_SP)),
                            value: getter,
                        }))),
                    ],
                })),
            })))
        })
        .collect();

    Expr::Call(CallExpr {
        span,
        ctxt: Default::default(),
        callee: Expr::Member(swc_core::ecma::ast::MemberExpr {
            span: DUMMY_SP,
            // Carry the unresolved mark so downstream scope-aware matchers
            // (UnWebpackObjectGetters) recognize the synthesized global.
            obj: Box::new(Expr::Ident(Ident::new(
                "Object".into(),
                DUMMY_SP,
                SyntaxContext::empty().apply_mark(unresolved_mark),
            ))),
            prop: swc_core::ecma::ast::MemberProp::Ident(IdentName::new(
                "defineProperties".into(),
                DUMMY_SP,
            )),
        })
        .as_callee(),
        args: vec![
            Expr::Ident(Ident::new(target.0, DUMMY_SP, target.1)).as_arg(),
            Expr::Object(ObjectLit {
                span: DUMMY_SP,
                props: descriptor_props,
            })
            .as_arg(),
        ],
        type_args: None,
    })
}

fn make_prop_name(name: &str) -> PropName {
    if is_valid_js_ident(name) {
        PropName::Ident(IdentName::new(name.into(), DUMMY_SP))
    } else {
        PropName::Str(Str {
            span: DUMMY_SP,
            value: name.into(),
            raw: None,
        })
    }
}

fn is_valid_js_ident(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }
    let mut chars = s.chars();
    let first = chars.next().unwrap();
    if !first.is_ascii_alphabetic() && first != '_' && first != '$' {
        return false;
    }
    chars.all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '$')
}
