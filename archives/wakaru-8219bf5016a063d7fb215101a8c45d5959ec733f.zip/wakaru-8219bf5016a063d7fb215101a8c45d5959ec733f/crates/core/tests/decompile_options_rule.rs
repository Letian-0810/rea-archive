mod common;

use common::assert_eq_normalized;
use wakaru_core::{decompile, validate_output_modules, DecompileOptions, RewriteLevel};

#[test]
fn dce_mode_off_preserves_dead_code() {
    let input = r#"
import unused from "./x.js";
function helper() { return 1; }
export const value = 2;
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
import unused from "./x.js";
function helper() { return 1; }
export const value = 2;
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn dce_mode_is_off_by_default() {
    let input = r#"
import unused from "./x.js";
function helper() { return 1; }
export const value = 2;
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("import unused"),
        "default should preserve unused imports: {output}"
    );
    assert!(
        output.contains("function helper"),
        "default should preserve unused functions: {output}"
    );
}

#[test]
fn dce_mode_full_removes_dead_code() {
    let input = r#"
import unused from "./x.js";
function helper() { return 1; }
export const value = 2;
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            dce_mode: wakaru_core::DceMode::Full,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
import "./x.js";
export const value = 2;
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_loose_optional_chaining_recovery() {
    let input = r#"const x = U == null ? undefined : U.name;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn standard_keeps_loose_optional_chaining_recovery_enabled() {
    let input = r#"const x = U == null ? undefined : U.name;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"const x = U?.name;"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn rewrite_levels_preserve_use_strict_directives() {
    let input = r#"
"use strict";
function foo(a, b, c) {
  "use strict";
  for (var value of arguments) {
    a = b;
    b = c;
    c = value;
  }
}
"#;

    for level in [
        RewriteLevel::Minimal,
        RewriteLevel::Standard,
        RewriteLevel::Aggressive,
    ] {
        let output = decompile(
            input,
            DecompileOptions {
                filename: "fixture.js".to_string(),
                level,
                ..Default::default()
            },
        )
        .expect("decompile should succeed")
        .code;

        assert_eq!(
            output.matches("\"use strict\"").count(),
            2,
            "{level:?} must preserve top-level and nested strict directives: {output}"
        );
    }
}

#[test]
fn strict_only_final_output_is_empty() {
    let output = decompile(
        r#"
"use strict";
Object.defineProperty(exports, "__esModule", {
  value: true
});
"#,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.trim().is_empty(),
        "a consumed module marker must not leave an inert strict-only file: {output}"
    );
    assert!(
        validate_output_modules(&[("fixture.js".to_string(), output.clone())]).is_empty(),
        "empty output must remain valid JavaScript: {output}"
    );
}

#[test]
fn proven_module_removes_only_top_level_use_strict() {
    let input = r#"
"use strict";
export const value = 1;
function inspectThis() {
  "use strict";
  return this;
}
"use strict";
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq!(
        output.matches("\"use strict\"").count(),
        1,
        "only the function-level directive should remain: {output}"
    );
    assert!(
        validate_output_modules(&[("fixture.js".to_string(), output.clone())]).is_empty(),
        "output must remain valid JavaScript: {output}"
    );
}

#[test]
fn module_extension_removes_top_level_use_strict_without_module_declarations() {
    let output = decompile(
        r#"
"use strict";
function inspectThis() {
  "use strict";
  return this;
}
"#,
        DecompileOptions {
            filename: "fixture.mjs".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq!(
        output.matches("\"use strict\"").count(),
        1,
        "the .mjs goal should remove only the top-level directive: {output}"
    );
}

#[test]
fn import_meta_proves_module_goal_for_top_level_use_strict_cleanup() {
    let output = decompile(
        "\"use strict\";\nconsole.log(import.meta.url);",
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        !output.contains("\"use strict\""),
        "import.meta is module-only syntax: {output}"
    );
}

#[test]
fn dynamic_import_does_not_prove_module_goal() {
    let output = decompile(
        "\"use strict\";\nload(import(\"./dependency.js\"));",
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("\"use strict\""),
        "dynamic import is valid in scripts and must not prove module goal: {output}"
    );
}

#[test]
fn commonjs_esmodule_marker_does_not_prove_module_goal() {
    let output = decompile(
        r#"
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log(this);
"#,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("\"use strict\""),
        "a CommonJS interop marker is not trustworthy module provenance: {output}"
    );
}

#[test]
fn explicit_script_extension_wins_over_conflicting_module_syntax() {
    let output = decompile(
        "\"use strict\";\nexport const value = 1;",
        DecompileOptions {
            filename: "fixture.cjs".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("\"use strict\""),
        "a conflicting .cjs signal must fail closed: {output}"
    );
}

const CJS_INPUT: &str = r#""use strict";
const value = require("./value.cjs");
module.exports = { value };
"#;

fn decompile_cjs_input_as(filename: &str) -> String {
    decompile(
        CJS_INPUT,
        DecompileOptions {
            filename: filename.to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code
}

/// Node loads a `.cjs` file as CommonJS whatever it contains, so ESM syntax
/// recovered into one makes a file its runtime cannot load.
#[test]
fn explicit_script_extension_keeps_require_and_module_exports() {
    for filename in ["fixture.cjs", "fixture.cts", "FIXTURE.CJS"] {
        let output = decompile_cjs_input_as(filename);
        assert!(
            output.contains("require(\"./value.cjs\")") && output.contains("module.exports"),
            "{filename} must keep its CommonJS shape: {output}"
        );
        assert!(
            !output.contains("import ") && !output.contains("export "),
            "{filename} must not gain ESM syntax: {output}"
        );
    }
}

/// The gate is the extension, not the content: the same source under a `.js`
/// name still recovers ESM.
#[test]
fn ambiguous_extension_still_recovers_esm_from_commonjs() {
    let output = decompile_cjs_input_as("fixture.js");
    assert!(
        output.contains("import value from") && output.contains("export default"),
        ".js must still recover ESM: {output}"
    );
}

/// Current limitation, not a contract: unpack's first phases also run up to
/// `UnEsm` with no module facts, and the `.cjs` gate is not applied there, so
/// a recovered module or an input file named `.cjs` still gets ESM syntax
/// (`docs/unpacking.md`, Known gaps). Standing down there without handling
/// the module's bundler runtime calls would leave `require.r(...)` and
/// `require.d(...)` in a harmony module, so a fix must do more than lift this
/// gate.
#[test]
fn un_esm_phase_does_not_apply_the_script_extension_gate_yet() {
    let output = common::render_pipeline_until_with_filename(CJS_INPUT, "UnEsm", "version.cjs");
    assert!(
        output.contains("import ") && !output.contains("require("),
        "the unpack phase still recovers ESM for a .cjs name: {output}"
    );
}

#[test]
fn uppercase_module_extension_removes_top_level_use_strict() {
    let output = decompile(
        "\"use strict\";\nconsole.log(1);",
        DecompileOptions {
            filename: "FIXTURE.MJS".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        !output.contains("\"use strict\""),
        "an uppercase .MJS name states the module goal like .mjs: {output}"
    );
}

#[test]
fn direct_strict_functions_remain_parseable_with_simple_parameters() {
    let input = r#"
function withDefault() {
  "use strict";
  var value = arguments.length > 0 && arguments[0] !== void 0
    ? arguments[0]
    : 1;
  return value;
}
function withRest() {
  "use strict";
  return arguments[0] + arguments[1];
}
"#;

    for level in [RewriteLevel::Standard, RewriteLevel::Aggressive] {
        let output = decompile(
            input,
            DecompileOptions {
                filename: "fixture.js".to_string(),
                level,
                ..Default::default()
            },
        )
        .expect("decompile should succeed")
        .code;

        assert!(
            validate_output_modules(&[("fixture.js".to_string(), output.clone())]).is_empty(),
            "{level:?} output must remain valid JavaScript: {output}"
        );
        assert!(
            !output.contains("function withDefault(value = 1)"),
            "{level:?} must not synthesize a default parameter: {output}"
        );
        assert!(
            !output.contains("function withRest(..."),
            "{level:?} must not synthesize a rest parameter: {output}"
        );
    }
}

fn assert_pipeline_output_is_valid(input: &str) -> String {
    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        validate_output_modules(&[("fixture.js".to_string(), output.clone())]).is_empty(),
        "output must remain valid JavaScript: {output}"
    );
    output
}

#[test]
fn default_recovery_does_not_promote_a_strict_directive() {
    let output = assert_pipeline_output_is_valid(
        r#"
function foo(a) {
  if (a === void 0) a = 1;
  "use strict";
  return a;
}
"#,
    );

    assert!(!output.contains("foo(a = 1)"), "{output}");
}

#[test]
fn rest_recovery_does_not_promote_a_strict_directive() {
    let output = assert_pipeline_output_is_valid(
        r#"
function foo() {
  for (var len = arguments.length, args = Array(len), i = 0; i < len; i++) {
    args[i] = arguments[i];
  }
  "use strict";
  return args;
}
"#,
    );

    assert!(!output.contains("foo(...args)"), "{output}");
}

#[test]
fn sliced_callback_recovery_does_not_promote_a_strict_directive() {
    let output = assert_pipeline_output_is_valid(
        r#"
import sliced from "@babel/runtime/helpers/slicedToArray";
const out = entries.filter(function(entry) {
  const value = sliced(entry, 2)[1];
  "use strict";
  return value != null;
});
"#,
    );

    assert!(!output.contains("filter(([, value])"), "{output}");
}

#[test]
fn minimal_simplifies_safe_identifier_indirect_calls() {
    let input = r#"
const value = (0, fn)(arg);
const ref = (0, s.useRef)(0);
const result = (0, eval)("this");
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
const value = fn(arg);
const ref = (0, s.useRef)(0);
const result = (0, eval)("this");
"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn minimal_preserves_jsx_runtime_calls() {
    let input = r#"
import { jsx as _jsx } from "react/jsx-runtime";
export function view() {
  return _jsx("div", {
    children: "hi"
  });
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("jsx(\"div\""),
        "minimal output should keep executable JSX runtime calls: {output}"
    );
    assert!(
        !output.contains("<div"),
        "minimal output should not emit raw JSX syntax: {output}"
    );
}

#[test]
fn standard_simplifies_indirect_calls() {
    let input = r#"
const ref = (0, s.useRef)(0);
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
const ref = s.useRef(0);
"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn minimal_preserves_function_expressions() {
    let input = r#"
const fn = function() {
  return value;
};
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input.trim());
}

#[test]
fn standard_keeps_arrow_function_recovery() {
    let input = r#"
setTimeout(function() {
  return value;
});
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
setTimeout(() => value);
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn standard_keeps_babel_strict_optional_chaining_assignment_recovery() {
    // Babel declares its temp; the declared-temp proof is what `standard` relies on.
    let input = r#"var _a;
const x = (_a = e.ownerDocument) === null || _a === void 0 ? void 0 : _a.defaultView;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"const x = e.ownerDocument?.defaultView;"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn aggressive_enables_non_babel_strict_optional_chaining_assignment_recovery() {
    // The temp is declared (`var n;`), as every producer emits; an undeclared
    // `n` is preserved at every level (its assignment would throw or write a
    // global), and so is a declared-with-initializer one.
    let input = r#"var n;
const x = (n = e.ownerDocument) === null || n === void 0 ? void 0 : n.defaultView;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Aggressive,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("const x = e.ownerDocument?.defaultView;")
            && !output.contains("(n = e.ownerDocument)"),
        "aggressive should drop the isolated declared temp's assignment:\n{output}"
    );
}

#[test]
fn aggressive_enables_loose_optional_chaining_assignment_recovery() {
    let input = r#"var n;
const x = (n = e.ownerDocument) == null ? undefined : n.defaultView;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Aggressive,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("const x = e.ownerDocument?.defaultView;")
            && !output.contains("n = e.ownerDocument"),
        "aggressive should drop the isolated declared temp's assignment:\n{output}"
    );
}

#[test]
fn minimal_disables_smart_inline_temp_var_inlining() {
    let input = r#"
const t = foo;
bar(t);
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
const t = foo;
bar(t);
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_keeps_var_decl_to_let_const_recovery_safe() {
    let input = r#"
function readBeforeInit() {
    var value = read();
    var limit = 1;
    function read() { return limit; }
    return value;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function readBeforeInit() {
    const value = read();
    var limit = 1;
    function read() { return limit; }
    return value;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn standard_keeps_smart_inline_temp_var_inlining() {
    let input = r#"
function read(foo) {
  const t = foo;
  return t.value;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function read(foo) {
  return foo.value;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_iife_param_rewrites() {
    let input = r#"
((i, s, o) => {
  return s.createElement(o);
})(window, document, 'script');
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"((i, s, o) => s.createElement(o))(window, document, 'script');"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_smart_rename_passes() {
    let input = r#"
export function f(e) {
  var o = e.scrollLeft;
  return o;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("o = e.scrollLeft") && !output.contains("e_scrollLeft"),
        "minimal output should keep the original local names: {output}"
    );
}

#[test]
fn standard_keeps_iife_param_rewrites() {
    let input = r#"
((i, s, o) => {
  return s.createElement(o);
})(window, document, 'script');
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
((window_1, document_1) => {
  const O = 'script';
  return document_1.createElement(O);
})(window, document);
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn standard_disables_dynamic_jsx_component_alias_synthesis() {
    let input = r#"
function fn() {
  return React.createElement(r ? "a" : "div", null, "Hello");
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input.trim());
}

#[test]
fn minimal_preserves_executable_jsx_runtime_calls() {
    let input = r#"
function fn() {
  return _jsx("div", {
    className: "hero",
    children: "Hello"
  });
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input.trim());
}

#[test]
fn standard_enables_dynamic_jsx_component_alias_synthesis_for_strong_runtime_shape() {
    let input = r#"
function fn() {
  return _jsx(tt(), {
    className: "hero",
    children: "Hello"
  });
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function FnComponent() {
  const Component = tt();
  return <Component className="hero">Hello</Component>;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn aggressive_enables_dynamic_jsx_component_alias_synthesis() {
    let input = r#"
function fn() {
  return React.createElement(r ? "a" : "div", null, "Hello");
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Aggressive,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function FnComponent() {
  const Component = r ? "a" : "div";
  return <Component>Hello</Component>;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_argument_spread_recovery() {
    let input = r#"fn.apply(undefined, args);"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn minimal_disables_array_concat_spread_recovery() {
    let input = r#"const x = [a].concat(b);"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn standard_keeps_argument_spread_recovery() {
    let input = r#"fn.apply(undefined, args);"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"fn(...args);"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn minimal_disables_array_concat_spread_recovery_for_call_args() {
    let input = r#"const x = [this].concat(args);"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn standard_preserves_unknown_array_concat_argument() {
    let input = r#"const x = [this].concat(args);"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn minimal_keeps_var_decl_recovery_without_default_param_recovery() {
    let input = r#"
function foo(a) {
  var b = !(arguments.length > 1 && arguments[1] !== undefined) || arguments[1];
  return b;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function foo(a) {
  const b = !(arguments.length > 1 && arguments[1] !== undefined) || arguments[1];
  return b;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn standard_keeps_arguments_default_param_recovery() {
    let input = r#"
function foo(a) {
  var b = !(arguments.length > 1 && arguments[1] !== undefined) || arguments[1];
  return b;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function foo(a, b = true) {
  return b;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_object_alias_default_param_recovery() {
    let input = r#"
function foo(options) {
  const opts = options === undefined ? {} : options;
  return opts.name;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input.trim());
}

#[test]
fn standard_keeps_object_alias_default_param_recovery() {
    let input = r#"
function foo(options) {
  const o = options === undefined ? {} : options;
  return o.name;
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function foo(options = {}) {
  return options.name;
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_esm_reconstruction() {
    let input = r#"module.exports = 1;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn standard_keeps_esm_reconstruction() {
    let input = r#"module.exports = 1;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"export default 1;"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn minimal_disables_type_constructor_recovery() {
    let input = r#"+x;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn standard_disables_type_constructor_recovery() {
    let input = r#"+x;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn aggressive_enables_type_constructor_recovery() {
    let input = r#"+x;"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Aggressive,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"Number(x);"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn minimal_disables_static_class_field_recovery() {
    let input = r#"
var User = (function () {
    function User() {}
    User.role = "admin";
    return User;
}());
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("User.role = \"admin\""),
        "minimal mode should preserve assignment semantics: {output}"
    );
    assert!(
        !output.contains("static role = \"admin\""),
        "static field recovery requires standard+: {output}"
    );
}

#[test]
fn standard_keeps_static_class_field_recovery() {
    let input = r#"
var User = (function () {
    function User() {}
    User.role = "admin";
    return User;
}());
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("static role = \"admin\""),
        "standard mode should recover static fields: {output}"
    );
}

#[test]
fn minimal_disables_instance_class_field_recovery() {
    let input = r#"
function _defineProperty(e, r, t) {
    if (r in e) {
        Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true });
    } else {
        e[r] = t;
    }
    return e;
}
class Foo {
    constructor() {
        _defineProperty(this, "value", 1);
    }
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("this.value = 1"),
        "minimal mode should preserve constructor assignment semantics: {output}"
    );
    assert!(
        !output.contains("\n    value = 1"),
        "instance field recovery requires standard+: {output}"
    );
}

#[test]
fn standard_keeps_instance_class_field_recovery() {
    let input = r#"
function _defineProperty(e, r, t) {
    if (r in e) {
        Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true });
    } else {
        e[r] = t;
    }
    return e;
}
class Foo {
    constructor() {
        _defineProperty(this, "value", 1);
    }
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("\n    value = 1"),
        "standard mode should recover instance fields: {output}"
    );
    assert!(
        !output.contains("_defineProperty(this, \"value\", 1)"),
        "Babel helper call should be promoted in standard mode: {output}"
    );
}

#[test]
fn minimal_disables_define_property_instance_class_field_recovery() {
    let input = r#"
class Foo {
    constructor() {
        Object.defineProperty(this, "value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
    }
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("Object.defineProperty(this, \"value\""),
        "minimal mode should preserve descriptor assignment semantics: {output}"
    );
    assert!(
        !output.contains("\n    value = 1"),
        "defineProperty instance field recovery requires standard+: {output}"
    );
}

#[test]
fn standard_keeps_define_property_instance_class_field_recovery() {
    let input = r#"
class Foo {
    constructor() {
        Object.defineProperty(this, "value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
    }
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("\n    value = 1"),
        "standard mode should recover descriptor instance field: {output}"
    );
    assert!(
        !output.contains("Object.defineProperty(this, \"value\""),
        "descriptor call should be promoted in standard mode: {output}"
    );
}

#[test]
fn minimal_disables_tsc_private_class_field_recovery() {
    let input = r#"
var __classPrivateFieldGet = function(receiver, state, kind, f) {
    return state.get(receiver);
};
var _Foo_x;
class Foo {
    constructor() {
        _Foo_x.set(this, 1);
    }
    getX() {
        return __classPrivateFieldGet(this, _Foo_x, "f");
    }
}
_Foo_x = new WeakMap();
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(!output.contains("#x"), "{output}");
    assert!(output.contains("_Foo_x.set(this, 1)"), "{output}");
    assert!(
        output.contains("__classPrivateFieldGet(this, _Foo_x, \"f\")"),
        "{output}"
    );
}

#[test]
fn standard_keeps_tsc_private_class_field_recovery() {
    let input = r#"
var __classPrivateFieldGet = function(receiver, state, kind, f) {
    return state.get(receiver);
};
var _Foo_x;
class Foo {
    constructor() {
        _Foo_x.set(this, 1);
    }
    getX() {
        return __classPrivateFieldGet(this, _Foo_x, "f");
    }
}
_Foo_x = new WeakMap();
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(output.contains("#x = 1"), "{output}");
    assert!(output.contains("return this.#x"), "{output}");
}

#[test]
fn minimal_disables_arg_rest_recovery() {
    let input = r#"
function foo() {
  return arguments[0];
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input.trim());
}

#[test]
fn standard_keeps_arg_rest_recovery() {
    let input = r#"
function foo() {
  return arguments[0];
}
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"
function foo(...args) {
  return args[0];
}
"#;
    assert_eq_normalized(&output, expected.trim());
}

#[test]
fn minimal_disables_for_of_recovery() {
    let input = r#"for (let i = 0, arr = items; i < arr.length; i++) { const x = arr[i]; console.log(x); }"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Minimal,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert_eq_normalized(&output, input);
}

#[test]
fn standard_keeps_for_of_recovery() {
    let input = r#"for (let i = 0, arr = items; i < arr.length; i++) { const x = arr[i]; console.log(x); }"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    let expected = r#"for (const x of items) { console.log(x); }"#;
    assert_eq_normalized(&output, expected);
}

#[test]
fn strict_script_top_level_awaiter_reading_this_keeps_the_wrapper() {
    // wakaru preserves the script goal for input without module syntax. A
    // strict script's top-level `this` is the global object, which the helper
    // passes to the generator; a receiver-less async IIFE would see
    // `undefined`. There is no module-level exception in the awaiter gate.
    let input = r#""use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) { step(generator.next(value)); }
    function rejected(value) { step(generator["throw"](value)); }
    function step(result) { result.done ? resolve(result.value) : Promise.resolve(result.value).then(fulfilled, rejected); }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
__awaiter(this, void 0, void 0, function* () {
  yield this.flag;
});
"#;

    let output = decompile(
        input,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level: RewriteLevel::Standard,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code;

    assert!(
        output.contains("__awaiter(this") && output.contains("this.flag"),
        "top-level this must not be rebound by an IIFE in a strict script:\n{output}"
    );
    assert!(
        !output.contains("async function"),
        "no async IIFE may be synthesized here:\n{output}"
    );
}
