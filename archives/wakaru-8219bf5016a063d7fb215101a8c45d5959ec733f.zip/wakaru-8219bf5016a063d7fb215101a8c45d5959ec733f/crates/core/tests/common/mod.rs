use swc_core::common::{sync::Lrc, FileName, Mark, SourceMap, GLOBALS};
use swc_core::ecma::ast::Module;
use swc_core::ecma::codegen::{text_writer::JsWriter, Config, Emitter};
use swc_core::ecma::parser::{lexer::Lexer, EsSyntax, Parser, StringInput, Syntax};
use swc_core::ecma::transforms::base::{fixer::fixer, resolver};
use swc_core::ecma::visit::{VisitMut, VisitMutWith};
use wakaru_core::ModuleFactsMap;
use wakaru_core::{
    apply_rules, decompile, trace_rules, DecompileOptions, RewriteLevel, RulePipelineOptions,
    RuleTraceEvent, RuleTraceOptions,
};

#[allow(dead_code)]
pub fn render_pipeline(source: &str) -> String {
    decompile(
        source,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code
}

#[allow(dead_code)]
pub fn render(source: &str) -> String {
    render_pipeline(source)
}

#[allow(dead_code)]
pub fn render_with_level(source: &str, level: RewriteLevel) -> String {
    decompile(
        source,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            level,
            ..Default::default()
        },
    )
    .expect("decompile should succeed")
    .code
}

#[allow(dead_code)]
pub fn render_rule<R, F>(source: &str, build_rule: F) -> String
where
    R: VisitMut,
    F: FnOnce(Mark) -> R,
{
    render_rule_with_filename(source, "fixture.js", build_rule)
}

#[allow(dead_code)]
pub fn render_rule_with_filename<R, F>(source: &str, filename: &str, build_rule: F) -> String
where
    R: VisitMut,
    F: FnOnce(Mark) -> R,
{
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let mut module = parse_module_with_filename(source, filename, cm.clone());

        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));

        let mut rule = build_rule(unresolved_mark);
        module.visit_mut_with(&mut rule);
        module.visit_mut_with(&mut fixer(None));

        emit_module(&module, cm)
    })
}

/// Run a single rule like [`render_rule`], then hand the rewritten module
/// and the input text to `inspect` instead of emitting. For assertions the
/// printed code cannot express, such as which input span a node carries.
#[allow(dead_code)]
pub fn inspect_rule_output<R, F, T>(
    source: &str,
    build_rule: F,
    inspect: impl FnOnce(&Module, &SpanText) -> T,
) -> T
where
    R: VisitMut,
    F: FnOnce(Mark) -> R,
{
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let mut module = parse_module_with_filename(source, "fixture.js", cm.clone());

        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));
        module.visit_mut_with(&mut build_rule(unresolved_mark));

        inspect(&module, &SpanText { cm, source })
    })
}

/// Resolves spans of a module parsed by [`inspect_rule_output`] to input text.
#[allow(dead_code)]
pub struct SpanText<'a> {
    cm: Lrc<SourceMap>,
    source: &'a str,
}

#[allow(dead_code)]
impl SpanText<'_> {
    /// Input text from `span.lo` to the end of the input; `None` for a
    /// dummy span.
    pub fn starting_at(&self, span: swc_core::common::Span) -> Option<&str> {
        if span.lo.0 == 0 {
            return None;
        }
        let offset = self.cm.lookup_byte_offset(span.lo).pos.0 as usize;
        Some(&self.source[offset..])
    }
}

/// Run the decompile pipeline up through `stop_after_rule`, then emit.
/// Rule names match struct names (e.g. "SmartInline", "UnEsm").
/// Second passes use suffixed names: "UnWebpackInterop2", "UnIife2".
#[allow(dead_code)]
pub fn render_pipeline_until(source: &str, stop_after_rule: &str) -> String {
    render_pipeline_until_with_level(source, stop_after_rule, RewriteLevel::Standard)
}

#[allow(dead_code)]
pub fn render_pipeline_until_with_filename(
    source: &str,
    stop_after_rule: &str,
    filename: &str,
) -> String {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let mut module = parse_module_with_filename(source, filename, cm.clone());

        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));

        apply_rules(
            &mut module,
            unresolved_mark,
            RulePipelineOptions::until(stop_after_rule).with_current_filename(filename),
        );
        module.visit_mut_with(&mut fixer(None));

        emit_module(&module, cm)
    })
}

#[allow(dead_code)]
pub fn render_pipeline_until_with_level(
    source: &str,
    stop_after_rule: &str,
    level: RewriteLevel,
) -> String {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let mut module = parse_module_with_filename(source, "fixture.js", cm.clone());

        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));

        apply_rules(
            &mut module,
            unresolved_mark,
            RulePipelineOptions::until(stop_after_rule).with_rewrite_level(level),
        );
        module.visit_mut_with(&mut fixer(None));

        emit_module(&module, cm)
    })
}

/// Run only the rules from `start_from` through `stop_after` (inclusive).
/// Useful for testing a rule's behavior given realistic pre-processed input
/// without the full pipeline's downstream effects.
#[allow(dead_code)]
pub fn render_pipeline_between(source: &str, start_from: &str, stop_after: &str) -> String {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let mut module = parse_module_with_filename(source, "fixture.js", cm.clone());

        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));

        apply_rules(
            &mut module,
            unresolved_mark,
            RulePipelineOptions::between(start_from, stop_after),
        );
        module.visit_mut_with(&mut fixer(None));

        emit_module(&module, cm)
    })
}

/// Run an isolated pipeline span with cross-module facts available.
#[allow(dead_code)]
pub fn render_pipeline_between_with_facts(
    source: &str,
    start_from: &str,
    stop_after: &str,
    module_facts: &ModuleFactsMap,
    current_filename: Option<&str>,
) -> String {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let filename = current_filename.unwrap_or("fixture.js");
        let mut module = parse_module_with_filename(source, filename, cm.clone());

        let unresolved_mark = Mark::new();
        let top_level_mark = Mark::new();
        module.visit_mut_with(&mut resolver(unresolved_mark, top_level_mark, false));

        let mut options =
            RulePipelineOptions::between(start_from, stop_after).with_module_facts(module_facts);
        if let Some(filename) = current_filename {
            options = options.with_current_filename(filename);
        }
        apply_rules(&mut module, unresolved_mark, options);
        module.visit_mut_with(&mut fixer(None));

        emit_module(&module, cm)
    })
}

#[allow(dead_code)]
pub fn trace_pipeline(source: &str, options: RuleTraceOptions) -> Vec<RuleTraceEvent> {
    trace_rules(
        source,
        DecompileOptions {
            filename: "fixture.js".to_string(),
            ..Default::default()
        },
        options,
    )
    .expect("trace should succeed")
}

#[allow(dead_code)]
pub fn changed_rules(source: &str) -> Vec<&'static str> {
    trace_pipeline(
        source,
        RuleTraceOptions {
            only_changed: true,
            ..Default::default()
        },
    )
    .into_iter()
    .map(|event| event.rule)
    .collect()
}

#[allow(dead_code)]
pub fn normalize(input: &str) -> String {
    GLOBALS.set(&Default::default(), || {
        let cm: Lrc<SourceMap> = Default::default();
        let module = parse_module_with_filename(input, "normalize.js", cm.clone());
        emit_module(&module, cm)
    })
}

#[allow(dead_code)]
pub fn assert_eq_normalized(actual: &str, expected: &str) {
    assert_eq!(normalize(actual), normalize(expected));
}

#[allow(dead_code)]
pub fn parse_module_with_filename(code: &str, filename: &str, cm: Lrc<SourceMap>) -> Module {
    let fm = cm.new_source_file(
        FileName::Custom(filename.to_string()).into(),
        code.to_string(),
    );
    let lexer = Lexer::new(
        Syntax::Es(EsSyntax {
            jsx: true,
            ..Default::default()
        }),
        Default::default(),
        StringInput::from(&*fm),
        None,
    );
    let mut parser = Parser::new_from(lexer);

    let parser_errors = parser.take_errors();
    assert!(
        parser_errors.is_empty(),
        "failed to parse for normalization: {:?}",
        parser_errors
    );

    parser
        .parse_module()
        .expect("failed to parse module for normalization")
}

#[allow(dead_code)]
pub fn emit_module(module: &Module, cm: Lrc<SourceMap>) -> String {
    let mut output = Vec::new();
    {
        let mut emitter = Emitter {
            cfg: Config::default().with_minify(false),
            cm: cm.clone(),
            comments: None,
            wr: JsWriter::new(cm, "\n", &mut output, None),
        };
        emitter
            .emit_module(module)
            .expect("failed to emit module for normalization");
    }
    String::from_utf8(output).expect("normalization output is not utf-8")
}

/// Runs `assert` on every `(name, code)` pair, then fails once, naming every
/// pair whose assertion panicked. A plain loop over `insta::assert_snapshot!`
/// stops at the first mismatch, so a later drift only shows up after the
/// first one is accepted.
///
/// Pass the snapshot macro in a closure written in the test file: the macro
/// takes its snapshot directory and file-name prefix from where it expands.
#[allow(dead_code)]
pub fn assert_each_snapshot<I, N, C>(snapshots: I, assert: impl Fn(&str, &str))
where
    I: IntoIterator<Item = (N, C)>,
    N: AsRef<str>,
    C: AsRef<str>,
{
    let mut failed = Vec::new();
    for (name, code) in snapshots {
        let (name, code) = (name.as_ref(), code.as_ref());
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| assert(name, code)));
        if result.is_err() {
            failed.push(name.to_string());
        }
    }
    assert!(
        failed.is_empty(),
        "{} snapshot(s) failed: {}",
        failed.len(),
        failed.join(", ")
    );
}
