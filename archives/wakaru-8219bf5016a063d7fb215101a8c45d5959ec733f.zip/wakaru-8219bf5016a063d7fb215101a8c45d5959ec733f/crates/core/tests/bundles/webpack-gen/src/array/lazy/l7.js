module.exports = 70;
