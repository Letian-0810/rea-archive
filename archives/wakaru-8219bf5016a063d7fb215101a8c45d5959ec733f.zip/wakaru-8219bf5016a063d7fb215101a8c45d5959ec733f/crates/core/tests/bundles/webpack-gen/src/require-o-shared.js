exports.sharedValue = 'shared';
