module.exports = "lazy";
