module.exports = "static";
