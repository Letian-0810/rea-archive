use wakaru_core::driver::test_support::{unpack, unpack_raw};
use wakaru_core::{validate_output_modules, DecompileOptions, OutputFindingKind};

fn expect_unpack(source: &str, filename: &str) -> Vec<(String, String)> {
    let output = unpack(
        source,
        DecompileOptions {
            filename: filename.to_string(),
            ..Default::default()
        },
    )
    .expect("unpack should succeed");
    assert!(
        !output.has_errors(),
        "unexpected warnings: {:?}",
        output.warnings
    );
    output.modules
}

fn expect_heuristic_unpack(source: &str, filename: &str) -> Vec<(String, String)> {
    let output = unpack(
        source,
        DecompileOptions {
            filename: filename.to_string(),
            heuristic_split: true,
            ..Default::default()
        },
    )
    .expect("unpack should succeed");
    assert!(
        !output.has_errors(),
        "unexpected warnings: {:?}",
        output.warnings
    );
    output.modules
}

fn expect_unpack_raw(source: &str) -> Vec<(String, String)> {
    let output =
        unpack_raw(source, &DecompileOptions::default()).expect("unpack_raw should succeed");
    assert!(
        !output.has_errors(),
        "unexpected warnings: {:?}",
        output.warnings
    );
    output.modules
}

fn expect_heuristic_unpack_raw(source: &str) -> Vec<(String, String)> {
    let output = unpack_raw(
        source,
        &DecompileOptions {
            heuristic_split: true,
            ..Default::default()
        },
    )
    .expect("unpack_raw should succeed");
    assert!(
        !output.has_errors(),
        "unexpected warnings: {:?}",
        output.warnings
    );
    output.modules
}

/// Minimal synthetic esbuild bundle: two lazy modules + entry code.
fn make_bundle(helper: &str, helper_name: &str) -> String {
    format!(
        r#"
var {helper_name} = {helper};
var mod_a = {helper_name}(() => {{
    mod_a_val = 42;
}});
var mod_b = {helper_name}(() => {{
    mod_b_val = "hello";
}});
var mod_c = {helper_name}(() => {{ mod_c_val = true; }});
var mod_d = {helper_name}(() => {{ mod_d_val = null; }});
var mod_e = {helper_name}(() => {{ mod_e_val = undefined; }});
// entry
mod_a();
mod_b();
mod_c();
mod_d();
mod_e();
console.log(mod_a_val);
"#
    )
}

#[test]
fn esbuild_detects_minified_lazy_helper() {
    // esbuild's minified __esm: (q, K) => () => (q && (K = q(q = 0)), K)
    let bundle = make_bundle("(q,K)=>()=>(q&&(K=q(q=0)),K)", "y");
    let pairs = expect_unpack(&bundle, "bundle.js");

    // Should split into factory modules + entry
    assert!(
        pairs.len() >= 6,
        "expected ≥6 modules (5 factories + entry), got {}",
        pairs.len()
    );

    let has_entry = pairs.iter().any(|(name, _)| name == "entry.js");
    assert!(
        has_entry,
        "entry.js not found: {:?}",
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );

    let has_mod_a = pairs.iter().any(|(name, _)| name == "mod_a.js");
    assert!(has_mod_a, "mod_a.js not found");
}

#[test]
fn esbuild_detects_minified_cjs_helper() {
    // esbuild's minified __commonJS: (q, K) => () => (K || q((K = {exports:{}}).exports, K), K.exports)
    let bundle = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let pairs = expect_unpack(&bundle, "bundle.js");

    assert!(pairs.len() >= 6, "expected ≥6 modules, got {}", pairs.len());
    assert!(
        pairs.iter().any(|(n, _)| n == "entry.js"),
        "missing entry.js"
    );
}

#[test]
fn commonjs_factory_emits_callable_module_exports_wrapper() {
    let bundle = r#"
var m = (q, K) => () => (K || q((K = { exports: {} }).exports, K), K.exports);
var f1 = m((exports, module) => { module.exports = function() { return 1; }; });
var f2 = m((exports, module) => { module.exports = 2; });
var f3 = m((exports) => { exports.value = 3; });
var f4 = m((exports, module) => { module.exports = 4; });
var f5 = m((exports, module) => { module.exports = 5; });
console.log(f1()());
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let f1_code = &raw_pairs.iter().find(|(n, _)| n == "f1.js").unwrap().1;
    assert!(
        f1_code.contains("export function f1()"),
        "CommonJS factory should emit a callable export:\n{f1_code}"
    );
    assert!(
        f1_code.contains("var __wakaru_f1_cache")
            && f1_code.contains("if (__wakaru_f1_cache)")
            && f1_code.contains("return __wakaru_f1_cache.exports")
            && f1_code.contains("var exports = {}")
            && f1_code.contains("var module =")
            && f1_code.contains("exports: exports")
            && f1_code.contains("__wakaru_f1_cache = module")
            && f1_code.contains("return module.exports"),
        "CommonJS factory should cache module state before running the body:\n{f1_code}"
    );

    let f3_code = &raw_pairs.iter().find(|(n, _)| n == "f3.js").unwrap().1;
    assert!(
        f3_code.contains("export function f3()")
            && f3_code.contains("var __wakaru_f3_cache")
            && f3_code.contains("if (__wakaru_f3_cache)")
            && f3_code.contains("return __wakaru_f3_cache")
            && f3_code.contains("var exports = {}")
            && f3_code.contains("__wakaru_f3_cache = exports")
            && f3_code.contains("exports.value = 3")
            && f3_code.contains("return exports"),
        "one-param CommonJS factory should cache and return the exports object:\n{f3_code}"
    );
}

#[test]
fn esbuild_factory_code_is_non_empty() {
    let bundle = make_bundle("(q,K)=>()=>(q&&(K=q(q=0)),K)", "y");
    let pairs = expect_unpack(&bundle, "bundle.js");

    for (name, code) in &pairs {
        assert!(!code.trim().is_empty(), "module {name} has empty code");
    }
}

#[test]
fn esbuild_scope_hoisted_modules_are_extracted() {
    // Synthetic bundle: 5 factory modules + scope-hoisted entry containing
    // an __export helper and 2 scope-hoisted modules.
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
var ns_b = {};
__export(ns_b, { add: () => add, PI: () => PI });
var PI = 3.14;
function add(a, b) { return a + b; }
console.log(greet(), add(1, 2));
export { ns_a, ns_b };
"#;
    // Use raw unpack first to verify extraction without pipeline interference
    let raw_pairs = expect_unpack_raw(bundle);
    let raw_names: Vec<&str> = raw_pairs.iter().map(|(n, _)| n.as_str()).collect();

    // 5 factory modules + 2 scope-hoisted modules + entry.js
    assert!(
        raw_pairs.len() >= 8,
        "expected ≥8 modules (5 factories + 2 scope-hoisted + entry), got {}: {raw_names:?}",
        raw_pairs.len()
    );

    assert!(
        raw_names.contains(&"ns_a.js"),
        "ns_a.js not found in {raw_names:?}"
    );
    assert!(
        raw_names.contains(&"ns_b.js"),
        "ns_b.js not found in {raw_names:?}"
    );

    // ns_a should contain the greet function
    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a_code.contains("greet"),
        "ns_a.js should contain 'greet': {ns_a_code}"
    );

    // ns_b should contain add, PI, and the console.log side effect
    let ns_b_code = &raw_pairs.iter().find(|(n, _)| n == "ns_b.js").unwrap().1;
    assert!(
        ns_b_code.contains("add") && ns_b_code.contains("3.14"),
        "ns_b.js should contain 'add' and PI: {ns_b_code}"
    );

    // console.log(greet(), add(1, 2)) references `add` from ns_b's exports,
    // so it stays with ns_b as a module-level side effect.
    assert!(
        ns_b_code.contains("console.log"),
        "ns_b.js should contain console.log (references module binding `add`): {ns_b_code}"
    );
}

#[test]
fn heuristic_scope_hoist_restores_esbuild_dynamic_require_imports() {
    let bundle = r#"
(()=>{
var H=Object.create;
var P=Object.defineProperty;
var q=Object.getOwnPropertyDescriptor;
var G=Object.getOwnPropertyNames;
var Q=Object.getPrototypeOf,W=Object.prototype.hasOwnProperty;
var r=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,o)=>(typeof require<"u"?require:t)[o]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')});
var X=(e,t,o,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let l of G(t))!W.call(e,l)&&l!==o&&P(e,l,{get:()=>t[l],enumerable:!(a=q(t,l))||a.enumerable});return e};
var Y=(e,t,o)=>(o=e!=null?H(Q(e)):{},X(t||!e||!e.__esModule?P(o,"default",{value:e,enumerable:!0}):o,e));
var Z=Math.max;
var react=r("react"),jsx=r("react/jsx-runtime"),D=(0,react.createContext)(null);
var wrapped=Y(r("react"));
function App(){return (0,jsx.jsx)(wrapped.default.Fragment,{children:(0,jsx.jsx)(D.Provider,{value:null,children:"ok"})})}
var Root=App;
console.log(Root);
})();
"#;

    let raw_pairs = expect_heuristic_unpack_raw(bundle);
    let raw_app = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("createContext"))
        .expect("should split app chunk");
    assert!(
        !raw_app.1.contains("import { r }"),
        "dynamic require helper should not be synthesized as an import:\n{}",
        raw_app.1
    );
    assert!(
        (raw_app.1.contains("require(\"react\")")
            && raw_app.1.contains("require(\"react/jsx-runtime\")"))
            || (raw_app.1.contains("from \"react\"")
                && raw_app.1.contains("from \"react/jsx-runtime\"")),
        "dynamic require helper calls should be restored to direct module references:\n{}",
        raw_app.1
    );
    assert!(
        !raw_app.1.contains("import { Y }") && !raw_app.1.contains("Y(require("),
        "esbuild __toESM helper should not be synthesized as an import:\n{}",
        raw_app.1
    );
    assert!(
        raw_app.1.contains("wrapped.Fragment") && !raw_app.1.contains("wrapped.default"),
        "default interop member access should be unwrapped with the helper call:\n{}",
        raw_app.1
    );

    let pairs = expect_heuristic_unpack(bundle, "bundle.js");
    let app = pairs
        .iter()
        .find(|(_, code)| code.contains("createContext"))
        .expect("should decompile app chunk");
    assert!(
        app.1.contains("from \"react\"") && app.1.contains("from \"react/jsx-runtime\""),
        "require() calls should be restored to imports after UnEsm:\n{}",
        app.1
    );
    assert!(
        !app.1.contains("r(\"react\")"),
        "dynamic require alias should not survive decompilation:\n{}",
        app.1
    );
    assert!(
        !app.1.contains("Y(require(") && !app.1.contains(".default.Fragment"),
        "esbuild __toESM wrapper should not survive decompilation:\n{}",
        app.1
    );
}

const EXPORTED_RUNTIME_HELPER_BUNDLE: &str = r#"
var H=Object.create;
var P=Object.defineProperty;
var q=Object.getOwnPropertyDescriptor;
var G=Object.getOwnPropertyNames;
var Q=Object.getPrototypeOf,W=Object.prototype.hasOwnProperty;
var r=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,o)=>(typeof require<"u"?require:t)[o]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')});
var X=(e,t,o,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let l of G(t))!W.call(e,l)&&l!==o&&P(e,l,{get:()=>t[l],enumerable:!(a=q(t,l))||a.enumerable});return e};
var Y=(e,t,o)=>(o=e!=null?H(Q(e)):{},X(t||!e||!e.__esModule?P(o,"default",{value:e,enumerable:!0}):o,e));
var Z=Math.max;
var react=r("react"),jsx=r("react/jsx-runtime"),D=(0,react.createContext)(null);
var wrapped=Y(r("react"));
function App(){return (0,jsx.jsx)(wrapped.default.Fragment,{children:(0,jsx.jsx)(D.Provider,{value:null,children:"ok"})})}
var Root=App;
console.log(Root,Z(1,2));
export { __HELPER__ as __ALIAS__ };
"#;

fn assert_exported_runtime_helper_keeps_cross_cluster_link(helper: &str, alias: &str) {
    let bundle = EXPORTED_RUNTIME_HELPER_BUNDLE
        .replace("__HELPER__", helper)
        .replace("__ALIAS__", alias);

    let raw_pairs = expect_heuristic_unpack_raw(&bundle);
    assert!(
        raw_pairs.len() > 1,
        "fixture must exercise a cross-cluster link: {raw_pairs:#?}"
    );
    let public_module = raw_pairs
        .iter()
        .find(|(_, code)| code.contains(&format!("as {alias}")))
        .expect("public helper alias should survive raw emission");
    let imports_helper = public_module.1.lines().any(|line| {
        line.strip_prefix("import { ")
            .and_then(|rest| rest.split_once(" } from"))
            .is_some_and(|(names, _)| names.split(", ").any(|name| name == helper))
    });
    assert!(
        imports_helper,
        "public helper alias must import its surviving local reference:\n{}",
        public_module.1
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "raw scope modules should have a complete helper link"
    );

    let normal_pairs = expect_heuristic_unpack(&bundle, "bundle.js");
    assert!(
        normal_pairs
            .iter()
            .any(|(_, code)| code.contains(&format!("as {alias}"))),
        "normal cleanup must not prune the public helper alias: {normal_pairs:#?}"
    );
    assert_eq!(
        validate_output_modules(&normal_pairs),
        vec![],
        "normal scope modules should retain a valid helper export"
    );
}

#[test]
fn exported_esbuild_to_esm_helper_keeps_cross_cluster_link() {
    assert_exported_runtime_helper_keeps_cross_cluster_link("Y", "toEsmRuntime");
}

#[test]
fn exported_dynamic_require_helper_keeps_cross_cluster_link() {
    assert_exported_runtime_helper_keeps_cross_cluster_link("r", "dynamicRequireRuntime");
}

fn entry_code(pairs: &[(String, String)]) -> &str {
    &pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .unwrap_or_else(|| panic!("missing entry.js: {pairs:#?}"))
        .1
}

fn exports_name(code: &str, name: &str) -> bool {
    code.contains(&format!(" as {name},"))
        || code.contains(&format!(" as {name} }}"))
        || code.contains(&format!("export const {name} ="))
}

#[test]
fn exported_commonjs_helper_keeps_its_declaration() {
    // A code-splitting chunk shares its `__commonJS` helper with other chunks.
    let bundle = r#"
var v=(l,e)=>()=>(e||l((e={exports:{}}).exports,e),e.exports);
var b=v((g,u)=>{u.exports={value:42}});
console.log(b().value);
export{v as a,b as d};
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let raw_entry = entry_code(&raw_pairs);
    assert!(
        raw_entry.contains("var v = ") && raw_entry.contains("v as a"),
        "the exported helper should keep its declaration:\n{raw_entry}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);

    let normal_pairs = expect_unpack(bundle, "bundle.js");
    let normal_entry = entry_code(&normal_pairs);
    assert!(
        exports_name(normal_entry, "a"),
        "cleanup must keep the helper export:\n{normal_entry}"
    );
    assert_eq!(validate_output_modules(&normal_pairs), vec![]);
}

#[test]
fn exported_export_helper_keeps_its_dependencies() {
    // `__export` stays because the chunk exports it, so the property-define
    // alias it calls must stay too.
    let bundle = r#"
var o=Object.defineProperty;
var c=(l,e)=>{for(var r in e)o(l,r,{get:e[r],enumerable:!0})};
var ns={};c(ns,{one:()=>one,two:()=>two});var one=1;function two(){return 2}
var ns2={};c(ns2,{three:()=>three});var three=3;
console.log(ns,ns2);
export{c as b,ns as c,ns2 as d};
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let raw_entry = entry_code(&raw_pairs);
    assert!(
        raw_entry.contains("var o = Object.defineProperty;") && raw_entry.contains("c as b"),
        "the exported helper should keep its dependency:\n{raw_entry}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);

    let normal_pairs = expect_unpack(bundle, "bundle.js");
    let normal_entry = entry_code(&normal_pairs);
    assert!(
        exports_name(normal_entry, "b"),
        "cleanup must keep the helper export:\n{normal_entry}"
    );
    assert_eq!(validate_output_modules(&normal_pairs), vec![]);
}

#[test]
fn scope_module_imports_bindings_referenced_only_by_export_getters() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { source: () => source });
var source = 42;
var ns_b = {};
__export(ns_b, { reexported: () => source });
function local() { return "local"; }
var ns_c = {};
__export(ns_c, { tail: () => tail });
var tail = "tail";
export { ns_a, ns_b, ns_c };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a_code.contains("export") && ns_a_code.contains("source"),
        "ns_a.js should contain and export source:\n{ns_a_code}"
    );

    let ns_b_code = &raw_pairs.iter().find(|(n, _)| n == "ns_b.js").unwrap().1;
    assert!(
        ns_b_code.contains("import { source }") && ns_b_code.contains("./ns_a.js"),
        "ns_b.js should import source because its export getter references it:\n{ns_b_code}"
    );
    assert!(
        ns_b_code.contains("export { source"),
        "ns_b.js should re-export the imported source binding without dangling exports:\n{ns_b_code}"
    );
}

#[test]
fn scope_module_exports_namespace_object_when_referenced_by_another_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { renamed: () => value });
function value() { return 1; }
var ns_b = {};
__export(ns_b, { read: () => read });
function read() { return ns_a.renamed(); }
export { ns_a, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a_code.contains("export var ns_a = {}")
            && ns_a_code.contains("\"renamed\"")
            && ns_a_code.contains("get: ()=>value"),
        "provider module should export its namespace object with getters:\n{ns_a_code}"
    );

    let ns_b_code = &raw_pairs.iter().find(|(n, _)| n == "ns_b.js").unwrap().1;
    assert!(
        ns_b_code.contains("import { ns_a }") && ns_b_code.contains("./ns_a.js"),
        "consumer module should import the namespace from the provider module, not entry:\n{ns_b_code}"
    );
}

#[test]
fn restored_entry_namespace_does_not_restore_late_export_helper() {
    let bundle = r#"
var ns_a = {};
T8(ns_a, { value: () => value });
function value() { return 1; }
var { defineProperty } = Object;
function KK5(target, name, getter) {
    defineProperty(target, name, { enumerable: true, get: getter });
}
var T8 = (target, all) => {
    for (var name in all)
        KK5(target, name, all[name]);
};
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let entry_code = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    assert!(
        entry_code.contains("Object.defineProperty(ns_a")
            && entry_code.contains("\"value\"")
            && entry_code.contains("get: ()=>value"),
        "entry namespace should be restored with direct getters:\n{entry_code}"
    );
    assert!(
        !entry_code.contains("T8(ns_a")
            && !entry_code.contains("var T8")
            && !entry_code.contains("function KK5")
            && !entry_code.contains("defineProperty } = Object"),
        "entry should not keep the late export helper prelude:\n{entry_code}"
    );
}

#[test]
fn scope_module_imports_external_bindings_used_in_body() {
    let bundle = r#"
import { randomUUID as uid } from "crypto";
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { make: () => make });
function make() { return uid(); }
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a_code.contains("import { randomUUID as uid } from \"crypto\""),
        "scope module should preserve external imports referenced by its body:\n{ns_a_code}"
    );
    assert!(
        ns_a_code.contains("return uid()"),
        "scope module should keep the imported binding reference:\n{ns_a_code}"
    );
}

#[test]
fn scope_module_does_not_duplicate_external_import_already_in_body() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { make: () => make });
import { randomUUID as uid } from "crypto";
function make() { return uid(); }
var ns_b = {};
__export(ns_b, { value: () => value });
var value = 1;
export { ns_a, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    let import_count = ns_a_code
        .matches("import { randomUUID as uid } from \"crypto\"")
        .count();
    assert_eq!(
        import_count, 1,
        "scope module should not duplicate package imports already present in its body:\n{ns_a_code}"
    );
}

/// Known limitation: entry expressions referencing a last-module binding
/// are absorbed into that module because minified bundles have no
/// structural marker distinguishing them from module-level side effects.
/// See the KNOWN LIMITATION comment in esbuild.rs.
#[test]
fn esbuild_last_module_entry_ref_absorbed() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
var ns_b = {};
__export(ns_b, { value: () => value });
var value = 42;
console.log("entry", value);
export { ns_a, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // The entry `console.log("entry", value)` references `value` from ns_b.
    // In minified output there is no structural marker to distinguish it
    // from a module-level side effect. It currently stays with ns_b.
    let ns_b_code = &raw_pairs.iter().find(|(n, _)| n == "ns_b.js").unwrap().1;
    assert!(
        ns_b_code.contains("console.log"),
        "known limitation: entry expression referencing last-module binding is absorbed into ns_b"
    );
}

#[test]
fn esbuild_member_property_does_not_extend_scope_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { read: () => read });
function read(obj) { return obj.value; }
var value = "entry";
export { ns_a, value };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a_code.contains("value = \"entry\""),
        "member property name should not pull unrelated value binding into ns_a: {ns_a_code}"
    );
}

#[test]
fn esbuild_export_decl_extends_last_scope_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { value: () => value });
export var value = read();
function read() { return "module"; }
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a_code.contains("export var value") && ns_a_code.contains("function read"),
        "export declarations should count as module declarations and include referenced helpers: {ns_a_code}"
    );
}

#[test]
fn esbuild_shadowed_name_does_not_extend_last_scope_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { read: () => read });
function read() {
    function inner() {
        let helper = "local";
        return helper;
    }
    return inner();
}
function helper() { return "entry"; }
export { ns_a, helper };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a_code.contains("function helper"),
        "shadowed local helper should not pull top-level helper into ns_a: {ns_a_code}"
    );
}

#[test]
fn esbuild_shadowed_trailing_expr_does_not_extend_last_scope_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { read: () => read });
function read() { return "module"; }
(function() {
    let read = "entry";
    console.log(read);
})();
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a_code.contains("console.log"),
        "shadowed trailing expression should stay out of ns_a: {ns_a_code}"
    );
}

#[test]
fn esbuild_destructured_export_decl_extends_last_scope_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { value: () => value });
var source = { value: "module" };
export var { value } = source;
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a_code.contains("export var { value }"),
        "destructured export declarations should count as module declarations: {ns_a_code}"
    );
}

#[test]
fn esbuild_scope_hoisted_duplicate_namespace_names() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var a = {};
__export(a, { x: () => x });
var x = 1;
var a = {};
__export(a, { y: () => y2 });
var y2 = 2;
console.log(x, y2);
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let raw_names: Vec<&str> = raw_pairs.iter().map(|(n, _)| n.as_str()).collect();

    assert!(
        raw_names.contains(&"a.js"),
        "a.js not found in {raw_names:?}"
    );
    assert!(
        raw_names.contains(&"a_2.js"),
        "a_2.js (deduped) not found in {raw_names:?}"
    );
}

#[test]
fn scope_module_skips_factory_owned_suffixes() {
    // Factories own `a.js` (from `var a = y(...)`) and the scope boundary
    // also uses namespace atom `a`.  The counter-based dedup used to assign
    // `a_2.js` which shadows the CLI-deduped factory `a_2.js` when the
    // CLI separately deduplicates `a.js` → `a_2.js`.  The probe loop must
    // skip all taken names.
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var a = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var a = {};
__export(a, { greet: () => greet });
function greet() { return "hello"; }
export { a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let raw_names: Vec<&str> = raw_pairs.iter().map(|(n, _)| n.as_str()).collect();

    // Factory gets `a.js`. Scope module must NOT also claim `a.js`;
    // it should get `a_2.js` (or higher if `a_2.js` is also taken).
    let scope_module = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("greet"))
        .expect("should find scope module containing greet");
    assert_ne!(
        scope_module.0, "a.js",
        "scope module should not shadow factory a.js: {raw_names:?}"
    );

    // The scope module's filename must exist in the raw output (not orphaned).
    assert!(
        raw_names.contains(&scope_module.0.as_str()),
        "scope module filename {} should be in output: {raw_names:?}",
        scope_module.0
    );
}

#[test]
fn scope_module_skips_cli_deduped_factory_suffixes() {
    // Factories `a` and `A` produce raw filenames `a.js` and `A.js`.
    // The CLI case-dedup turns them into `a.js` and `A_2.js`.
    // A scope module with namespace `A_2` must not claim `A_2.js`;
    // it should probe past it to `A_2_2.js`.
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var a = y(() => { v1 = 1; });
var A = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var c = {};
__export(c, { use: () => use });
function use() { return greet(); }
var A_2 = {};
__export(A_2, { greet: () => greet });
function greet() { return "hello"; }
export { c, A_2 };
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let raw_names: Vec<&str> = raw_pairs.iter().map(|(n, _)| n.as_str()).collect();

    // The scope module exporting `greet` must not shadow the CLI-deduped
    // factory `A_2.js`.
    let greet_module = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function greet()"))
        .expect("should find scope module declaring greet");

    assert_ne!(
        greet_module.0.to_ascii_lowercase(),
        "a_2.js",
        "scope module should not shadow CLI-deduped factory A_2.js: {raw_names:?}"
    );

    // The `c` module imports greet — verify its import target matches greet's actual filename.
    let c_module = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function use()"))
        .expect("should find scope module declaring use");
    let import_target = c_module
        .1
        .lines()
        .find(|l| l.contains("import") && l.contains("greet"))
        .unwrap_or("");
    assert!(
        import_target.contains(&greet_module.0),
        "c module should import greet from {}, but import line is: {import_target}",
        greet_module.0
    );
}

#[test]
fn small_file_with_few_factories_is_not_detected() {
    // Only 2 factories — below the threshold of 5, so we should NOT detect as esbuild.
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var a = y(() => { x = 1; });
var b = y(() => { z = 2; });
a(); b();
"#;
    let pairs = expect_unpack(bundle, "bundle.js");

    // Falls through to single-module path
    assert_eq!(
        pairs.len(),
        1,
        "should not detect as esbuild bundle with only 2 factories"
    );
}

#[test]
fn single_boundary_without_esm_export_is_not_detected() {
    // One __export boundary but the namespace is NOT re-exported via ESM.
    // This pattern can appear in non-bundled code — it should NOT be
    // treated as an esbuild bundle.
    let code = r#"
var defProp = Object.defineProperty;
var helper = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var api = {};
helper(api, { greet: () => greet });
function greet() { return "hello"; }
console.log(api.greet());
"#;
    let pairs = expect_unpack(code, "app.js");

    assert_eq!(
        pairs.len(),
        1,
        "single boundary without ESM export should not split: {:?}",
        pairs.iter().map(|(n, _)| n.as_str()).collect::<Vec<_>>()
    );
}

/// Factory modules that reference bindings from scope-hoisted modules should
/// get synthesized imports, and the scope-hoisted modules should export those
/// bindings.  Without this, Dead Code Elimination incorrectly removes code
/// that appears unreferenced within its own module but is used by factories.
#[test]
fn factory_referencing_scope_hoisted_binding_gets_import() {
    // Synthetic bundle: 5 factory modules (f1..f4 are trivial, f5 references
    // `helperFn` which is declared in scope-hoisted module ns_a).
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { var result = helperFn(42); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
function helperFn(x) { return x + 1; }
var ns_b = {};
__export(ns_b, { value: () => value });
var value = 99;
export { ns_a, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let raw_names: Vec<&str> = raw_pairs.iter().map(|(n, _)| n.as_str()).collect();

    // Verify we got the expected modules.
    assert!(
        raw_pairs.len() >= 7,
        "expected factories + scope modules + entry, got {}: {raw_names:?}",
        raw_pairs.len()
    );

    // f5 references helperFn from ns_a — it should have an import statement.
    let f5_code = &raw_pairs.iter().find(|(n, _)| n == "f5.js").unwrap().1;
    assert!(
        f5_code.contains("import") && f5_code.contains("helperFn"),
        "f5.js should import helperFn from the scope-hoisted module:\n{f5_code}"
    );

    // ns_a should export helperFn (it's referenced by f5, a factory module).
    let ns_a_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function greet"))
        .unwrap()
        .1;
    assert!(
        ns_a_code.contains("export") && ns_a_code.contains("helperFn"),
        "ns_a should export helperFn (referenced by factory f5):\n{ns_a_code}"
    );
}

/// When multiple factory modules reference different bindings from the same
/// scope-hoisted module, all referenced bindings should be exported.
#[test]
fn multiple_factories_referencing_scope_hoisted_bindings() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { var x = add(1, 2); });
var f5 = y(() => { var p = PI; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var math_exports = {};
__export(math_exports, { add: () => add, PI: () => PI });
var PI = 3.14;
function add(a, b) { return a + b; }
export { math_exports as math };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // f4 should import add.
    let f4_code = &raw_pairs.iter().find(|(n, _)| n == "f4.js").unwrap().1;
    assert!(
        f4_code.contains("import") && f4_code.contains("add"),
        "f4.js should import add:\n{f4_code}"
    );

    // f5 should import PI.
    let f5_code = &raw_pairs.iter().find(|(n, _)| n == "f5.js").unwrap().1;
    assert!(
        f5_code.contains("import") && f5_code.contains("PI"),
        "f5.js should import PI:\n{f5_code}"
    );

    // The math module should export both add and PI (they were in the original
    // __export map, plus referenced by factories).
    let math_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("3.14"))
        .unwrap()
        .1;
    assert!(
        math_code.contains("export"),
        "math module should have exports:\n{math_code}"
    );
}

/// Factory modules that don't reference any scope-hoisted bindings should not
/// get any spurious import statements.
#[test]
fn factory_without_scope_hoisted_refs_gets_no_imports() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // All factory modules should have no import statements.
    for (name, code) in &raw_pairs {
        if name.starts_with("f") && name.ends_with(".js") {
            assert!(
                !code.contains("import"),
                "{name} should not have import statements (no scope-hoisted refs):\n{code}"
            );
        }
    }
}

/// Factory modules that reference a scope-hoisted namespace object (e.g.
/// `ns_a.greet()`) should import it from the scope module that owns the
/// namespace getters, avoiding an entry.js cycle.
#[test]
fn factory_referencing_namespace_imports_from_entry() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { var result = ns_a.greet(); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // f5 should import ns_a from the restored namespace module.
    let f5_code = &raw_pairs.iter().find(|(n, _)| n == "f5.js").unwrap().1;
    assert!(
        f5_code.contains("import") && f5_code.contains("ns_a"),
        "f5.js should import ns_a:\n{f5_code}"
    );
    assert!(
        f5_code.contains("./ns_a.js"),
        "f5.js should import ns_a from the namespace module:\n{f5_code}"
    );

    // The scope-hoisted module should export the synthesized namespace object.
    let ns_a_module = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function greet"))
        .unwrap()
        .1;
    assert!(
        ns_a_module.contains("export var ns_a") && ns_a_module.contains("Object.defineProperty"),
        "scope module should export synthesized ns_a namespace:\n{ns_a_module}"
    );
}

/// When the bundle has no ESM `export { ns_a }` but a factory references the
/// namespace, the owning scope module must still export it so the factory
/// import resolves.
#[test]
fn factory_namespace_ref_without_entry_export_adds_export() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { var result = ns_a.greet(); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
var ns_b = {};
__export(ns_b, { value: () => value });
var value = 99;
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // f5 should import ns_a from the restored namespace module.
    let f5_code = &raw_pairs.iter().find(|(n, _)| n == "f5.js").unwrap().1;
    assert!(
        f5_code.contains("import") && f5_code.contains("ns_a") && f5_code.contains("./ns_a.js"),
        "f5.js should import ns_a from the namespace module:\n{f5_code}"
    );

    // The scope module must synthesize an ESM namespace export even though
    // the bundle had no direct `export { ns_a }` declaration.
    let ns_a_module = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns_a.js")
        .expect("ns_a module should exist")
        .1;
    assert!(
        ns_a_module.contains("export var ns_a") && ns_a_module.contains("Object.defineProperty"),
        "ns_a.js should synthesize a namespace export for the factory import:\n{ns_a_module}"
    );
}

/// When the entry has an aliased export like `export { math_exports as math }`,
/// `math_exports` is NOT directly importable by that name.  A factory that
/// references `math_exports` still needs a synthesized `export { math_exports }`.
#[test]
fn factory_namespace_ref_with_aliased_entry_export_adds_export() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { var result = math_exports.add(1, 2); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var math_exports = {};
__export(math_exports, { add: () => add });
function add(a, b) { return a + b; }
export { math_exports as math };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // f5 should import math_exports from entry.js.
    let f5_code = &raw_pairs.iter().find(|(n, _)| n == "f5.js").unwrap().1;
    assert!(
        f5_code.contains("import") && f5_code.contains("math_exports"),
        "f5.js should import math_exports:\n{f5_code}"
    );

    // entry.js must have an unaliased `export { math_exports }` in addition to
    // the existing `export { math_exports as math }`.
    let entry_code = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    // Check there's an `export { math_exports }` (unaliased) — not just
    // `export { math_exports as math }`.
    let has_unaliased = entry_code.lines().any(|line| {
        line.contains("export {") && line.contains("math_exports") && !line.contains(" as ")
    });
    assert!(
        has_unaliased,
        "entry.js needs unaliased `export {{ math_exports }}`:\n{entry_code}"
    );
}

/// `export { ns_a as ns_a }` is semantically identical to `export { ns_a }` —
/// both make the binding importable as `ns_a`. No duplicate export should be
/// synthesized.
#[test]
fn same_name_alias_export_does_not_duplicate() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { var result = ns_a.greet(); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
export { ns_a as ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let entry_code = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    // Count how many `export {` lines mention ns_a — should be exactly one.
    let export_ns_a_count = entry_code
        .lines()
        .filter(|line| line.contains("export {") && line.contains("ns_a"))
        .count();
    assert_eq!(
        export_ns_a_count, 1,
        "entry.js should have exactly one export of ns_a (no duplicate):\n{entry_code}"
    );
}

/// Private helpers only referenced by factory modules (not by other scope-
/// hoisted code) should still be absorbed into the last scope-hoisted module,
/// not left in entry.js.
#[test]
fn factory_only_ref_extends_last_scope_module() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { var x = privateHelper(1); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
function privateHelper(x) { return x + 1; }
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // privateHelper should be in the scope-hoisted module (ns_a), not entry.
    let ns_a_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function greet"))
        .unwrap()
        .1;
    assert!(
        ns_a_code.contains("privateHelper"),
        "privateHelper should be in the scope-hoisted module, not entry:\n{ns_a_code}"
    );

    // f5 should import privateHelper.
    let f5_code = &raw_pairs.iter().find(|(n, _)| n == "f5.js").unwrap().1;
    assert!(
        f5_code.contains("import") && f5_code.contains("privateHelper"),
        "f5.js should import privateHelper:\n{f5_code}"
    );

    // entry should NOT contain privateHelper.
    let entry_code = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    assert!(
        !entry_code.contains("privateHelper"),
        "entry.js should NOT contain privateHelper:\n{entry_code}"
    );
}

/// Init factory that reads a binding from another scope module must synthesize
/// an import in the standalone lazy factory module.
#[test]
fn standalone_init_factory_imports_cross_module_reads() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_a = y(() => { target = source + 1; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var a_exports = {};
__export(a_exports, { target: () => target });
var target;
var b_exports = {};
__export(b_exports, { source: () => source });
var source = 42;
export { a_exports, b_exports };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_a.js")
        .expect("init_a module should exist")
        .1;
    // The init body uses `source` from b_exports — must have an import.
    assert!(
        init_code.contains("import { source } from \"./b_exports.js\""),
        "init_a should import `source` from b_exports:\n{init_code}"
    );
    assert!(
        init_code.contains("export function init_a")
            && init_code.contains("target = source + 1")
            && init_code.contains("__wakaru_init_a_initialized")
            && init_code.contains("export { target"),
        "init_a should contain the guarded lazy body and written export:\n{init_code}"
    );
}

/// A CommonJS factory that writes scope-owned state and also unclaimed entry
/// state merges into the scope module, which adopts the entry state. Left
/// standalone, the factory file would declare a second copy of the scope
/// module's state, and writes would no longer reach the reader.
#[test]
fn factory_writing_scope_and_entry_state_merges_and_adopts_the_entry_state() {
    let bundle = r#"
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var other = 0;
var first = __commonJS((exports, module) => { ready = 1; other = 2; module.exports = 1; });
var second = __commonJS((exports, module) => { ready = 3; module.exports = 2; });
var ns = {}; __export(ns, { get: () => get });
var ready = 0;
function get() { ready += 1; return ready; }
console.log(second(), first(), ns.get(), other);
export { ns };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let names: Vec<&String> = raw_pairs.iter().map(|(name, _)| name).collect();
    let (_, scope_code) = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function get"))
        .expect("scope module should exist");
    assert!(
        scope_code.contains("export function first")
            && scope_code.contains("export function second")
            && scope_code.contains("var other")
            && scope_code.matches("var ready").count() == 1,
        "the scope module should absorb both factories and adopt `other`:\n{scope_code}"
    );
    assert!(
        !names.iter().any(|name| name.as_str() == "first.js"),
        "no standalone file should keep a copy of the state: {names:?}"
    );
    let declaring_ready = raw_pairs
        .iter()
        .filter(|(_, code)| code.contains("var ready"))
        .count();
    assert_eq!(
        declaring_ready, 1,
        "`ready` must be declared once: {raw_pairs:#?}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);

    let output = unpack(
        bundle,
        DecompileOptions {
            filename: "bundle.js".to_string(),
            ..Default::default()
        },
    )
    .expect("unpack should succeed");
    assert!(!output.modules.is_empty());
}

/// Adopted state can make another factory an init of the same scope module.
/// That factory comes first in source order, so partition must revisit it.
#[test]
fn factory_writing_only_adopted_state_merges_on_a_later_round() {
    let bundle = r#"
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var other = 0;
var zero = __commonJS((exports, module) => { other = 7; module.exports = 0; });
var first = __commonJS((exports, module) => { ready = 1; other = 2; module.exports = 1; });
var second = __commonJS((exports, module) => { ready = 3; module.exports = 2; });
var ns = {}; __export(ns, { get: () => get });
var ready = 0;
function get() { ready += 1; return ready; }
console.log(zero(), second(), first(), ns.get(), other);
export { ns };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let (_, scope_code) = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function get"))
        .expect("scope module should exist");
    let first_at = scope_code.find("export function first");
    let zero_at = scope_code.find("export function zero");
    assert!(
        zero_at.is_some() && first_at.is_some() && zero_at < first_at,
        "both writers of `other` merge, in source order:\n{scope_code}"
    );
    let declaring_other = raw_pairs
        .iter()
        .filter(|(_, code)| code.contains("var other"))
        .count();
    assert_eq!(
        declaring_other, 1,
        "`other` must be declared once: {raw_pairs:#?}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);
}

/// Entry state that an entry statement also writes cannot move into the scope
/// module, so the factory stays standalone. It must not declare its own copy
/// of the scope module's state: the unlinked write is left for output
/// validation to report.
#[test]
fn standalone_factory_does_not_copy_scope_owned_state() {
    let bundle = r#"
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var other = 0;
var first = __commonJS((exports, module) => { ready = 1; other = 2; module.exports = 1; });
var second = __commonJS((exports, module) => { ready = 3; module.exports = 2; });
var ns = {}; __export(ns, { get: () => get });
var ready = 0;
function get() { ready += 1; return ready; }
other = 5;
console.log(second(), first(), ns.get(), other);
export { ns };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let (_, first_code) = raw_pairs
        .iter()
        .find(|(name, _)| name == "first.js")
        .expect("the factory stays standalone");
    assert!(
        !first_code.contains("var ready") && !first_code.contains("export { other, ready }"),
        "the standalone factory must not declare the scope module's state:\n{first_code}"
    );
    let findings = validate_output_modules(&raw_pairs);
    assert!(
        findings.iter().any(|finding| {
            finding.kind == OutputFindingKind::UnresolvedReference && finding.filename == "first.js"
        }),
        "the unlinked write should be reported: {findings:?}"
    );
}

/// If a scope-hoisted module also writes state initialized by a lazy factory,
/// the factory must merge into that scope module. Otherwise the scope module
/// would assign to a read-only ESM import.
#[test]
fn scope_writer_claims_factory_owned_state_and_init() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_state = y(() => { shared = { count: 0 }; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { read: () => read, write: () => write });
var shared;
function read() { return shared; }
function write(value) { shared = value; }
init_state();
console.log(shared);
export { ns_writer };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    assert!(
        raw_pairs.iter().all(|(name, _)| name != "init_state.js"),
        "init factory should merge into the scope writer module: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );

    let (writer_name, writer_code) = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function write"))
        .expect("scope writer module should exist");
    assert!(
        writer_code.contains("var shared")
            && writer_code.contains("export { shared }")
            && writer_code.contains("export function init_state")
            && writer_code.contains("shared = value")
            && !writer_code.contains("import { shared"),
        "writer module should own the shared mutable state and init factory:\n{writer_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "entry.js")
        .expect("entry module should exist")
        .1;
    let writer_import = format!("from \"./{writer_name}\"");
    assert!(
        entry_code.contains(&writer_import) && !entry_code.contains("from \"./init_state.js\""),
        "entry should import claimed factory state from the scope writer:\n{entry_code}"
    );
}

/// esbuild hoists function declarations ahead of a module's namespace/export
/// boundary. Such support declarations are adopted into the recovered module
/// after the initial partition, so their writes must still participate in
/// factory-state ownership.
#[test]
fn adopted_scope_writer_claims_factory_owned_state_and_init() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_state = y(() => { shared = { count: 0 }; });
var shared;
function read() { return shared; }
function write(value) { shared = value; }
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { marker: () => marker, read: () => read, write: () => write });
var marker = "writer";
init_state();
console.log(marker, shared);
export { ns_writer };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    assert!(
        raw_pairs.iter().all(|(name, _)| name != "init_state.js"),
        "the adopted writer should claim the init factory: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );
    let writer_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function write"))
        .expect("scope writer module should exist")
        .1;
    assert!(
        writer_code.contains("var shared")
            && writer_code.contains("export function init_state")
            && writer_code.contains("shared = value")
            && !writer_code.contains("import { shared"),
        "the adopted writer must own the mutable state and initializer:\n{writer_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "the adopted writer must not assign to an imported binding"
    );
}

/// When a scope writer claims a lazy factory, every support binding owned by
/// that factory moves with it. Other recovered modules must import those
/// bindings from the new owner rather than the removed factory filename.
#[test]
fn claimed_factory_support_bindings_follow_scope_owner() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
function seed() { return { count: 0 }; }
var init_state = y(() => { shared = seed(); });
var shared;
function write(value) { shared = value; }
function readSeed() { return seed(); }
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { marker: () => marker, write: () => write });
var marker = "writer";
var ns_reader = {};
__export(ns_reader, { markerReader: () => markerReader, readSeed: () => readSeed });
var markerReader = "reader";
init_state();
console.log(marker, markerReader, readSeed(), shared);
export { ns_writer, ns_reader };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    assert!(
        raw_pairs.iter().all(|(name, _)| name != "init_state.js"),
        "the claimed init factory should not leave a standalone module: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );
    let owner_name = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("export function init_state"))
        .expect("scope owner should contain the init factory")
        .0;
    let reader_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function readSeed"))
        .expect("reader module should exist")
        .1;
    assert!(
        reader_code.contains(&format!("from \"./{owner_name}\""))
            && !reader_code.contains("from \"./init_state.js\""),
        "factory support imports must follow the claimed owner:\n{reader_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "claiming a factory must not leave dangling imports"
    );
}

/// A binding referenced by a claimed lazy factory may already belong to the
/// scope module that claims it. It must not be materialized a second time as
/// relocated factory support.
#[test]
fn claimed_factory_does_not_duplicate_existing_scope_binding() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_state = y(() => { shared = new Marker(); });
var shared;
function write(value) { shared = value; }
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { Marker: () => Marker, write: () => write });
class Marker {}
init_state();
console.log(shared);
export { ns_writer };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let owner_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("export function init_state"))
        .expect("scope owner should contain the init factory")
        .1;
    assert_eq!(
        owner_code.matches("class Marker").count(),
        1,
        "the scope-local class must not be copied as factory support:\n{owner_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "the claimed factory owner must remain valid ESM"
    );
}

/// A claimed factory can call support that already belongs to another scope
/// module. Keep that declaration with its existing mutable state instead of
/// relocating it into the factory's new owner.
#[test]
fn claimed_factory_preserves_existing_support_owner() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_target = y(() => { state = 1; register("ready"); });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_registry = {};
__export(ns_registry, { readRegistry: () => readRegistry, register: () => register });
var registry;
function readRegistry() { return registry; }
function register(value) { registry = value; }
var ns_target = {};
__export(ns_target, { readState: () => readState, writeState: () => writeState });
var state;
function readState() { return state; }
function writeState(value) { state = value; }
init_target();
console.log(readRegistry(), readState());
export { ns_registry, ns_target };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    assert!(
        raw_pairs.iter().all(|(name, _)| name != "init_target.js"),
        "the state writer should still claim its init factory: {raw_pairs:#?}"
    );
    let (registry_name, registry_code) = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function register"))
        .expect("registry scope module should own its support function");
    let target_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("export function init_target"))
        .expect("target scope module should own the init factory")
        .1;
    assert!(
        registry_code.contains("var registry")
            && target_code.contains(&format!("from \"./{registry_name}\""))
            && !target_code.contains("function register"),
        "scope-owned support and its state must stay together:\nregistry:\n{registry_code}\ntarget:\n{target_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "preserving the support owner must avoid imported-binding writes"
    );
}

/// A standalone lazy factory can close over a hoisted support function that
/// writes state initialized by another lazy factory. Those factories and the
/// support declaration must share one ESM owner; otherwise both the writer
/// module and the retained entry copy assign to imported bindings.
#[test]
fn standalone_factory_support_writer_shares_mutable_state_owner() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
function writeBoth(value) { left = value; right = value; }
function runWrite(value) { writeBoth(value); }
var init_left = y(() => { left = 0; });
var init_right = y(() => { right = 0; runWrite(1); });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var left;
var right;
init_left();
init_right();
runWrite(2);
console.log(left, right);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let owner_modules: Vec<_> = raw_pairs
        .iter()
        .filter(|(_, code)| {
            code.contains("export function init_left")
                || code.contains("export function init_right")
        })
        .collect();
    assert_eq!(
        owner_modules.len(),
        1,
        "cross-writing lazy factories should emit one owner module: {raw_pairs:#?}"
    );
    let owner_code = &owner_modules[0].1;
    assert!(
        owner_code.contains("export function init_left")
            && owner_code.contains("export function init_right")
            && owner_code.contains("function writeBoth")
            && owner_code.contains("function runWrite")
            && !owner_code.contains("import { left")
            && !owner_code.contains("import { right"),
        "the combined owner must contain both initializers, support writers, and state:\n{owner_code}"
    );
    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("import {")
            && entry_code.contains("runWrite")
            && !entry_code.contains("function writeBoth")
            && !entry_code.contains("function runWrite"),
        "entry should call the relocated support function instead of retaining a writer copy:\n{entry_code}"
    );
    // The mutable state must relocate with its writers. A retained entry
    // declaration would fork the binding: writers mutate the owner's copy
    // while the entry reads its own dead one.
    assert!(
        !entry_code.contains("var left") && !entry_code.contains("var right"),
        "entry must not redeclare relocated mutable state:\n{entry_code}"
    );
    assert!(
        entry_code.contains("left") && entry_code.contains("right"),
        "entry reads must resolve through imports of the relocated state:\n{entry_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "factory support writers must not assign to imports"
    );
}

/// An adopted helper has the same write restrictions as an ordinary body
/// declaration: entry-owned state cannot become an immutable import.
#[test]
fn adopted_support_writes_do_not_import_entry_state() {
    for body in [
        "state = 1;",
        "state++;",
        "[state] = [1];",
        "for (state of [1]) {}",
    ] {
        let bundle = format!(
            r#"{SCOPE_HELPERS}
function write() {{ {body} }}
var ns = {{}}; __export(ns, {{ write: () => write }});
function start() {{ write(); }}
var extra = {{}}; __export(extra, {{ read: () => read }});
function read() {{ return 7; }}
var state = 0;
ns.write(); record(state); export {{ ns, extra }};
"#
        );
        for pairs in [
            expect_unpack_raw(&bundle),
            expect_unpack(&bundle, "bundle.js"),
        ] {
            let owner = &pairs.iter().find(|(name, _)| name == "ns.js").unwrap().1;
            assert!(
                owner.contains("function write"),
                "helper must be adopted: {owner}"
            );
            assert!(
                !owner.contains("from \"./entry.js\""),
                "writer cannot import state: {owner}"
            );
            let findings = validate_output_modules(&pairs);
            assert!(
                findings.len() == 1 && findings[0].kind == OutputFindingKind::UnresolvedReference,
                "keep the unlinked boundary visible instead of an import write: {findings:#?}"
            );
        }
    }
}

/// The write inventory is binding-aware: local assignments and property
/// mutations do not prevent a deferred read of the imported object binding.
#[test]
fn adopted_support_reads_still_import_entry_state() {
    for body in [
        "return state;",
        "function local(state) { state = 1; } local(0); return state;",
        "state.value = 1; return state;",
    ] {
        let bundle = format!(
            r#"{SCOPE_HELPERS}
function read() {{ {body} }}
var ns = {{}}; __export(ns, {{ read: () => read }});
function start() {{ return read(); }}
var extra = {{}}; __export(extra, {{ other: () => other }});
function other() {{ return 7; }}
var state = {{ value: 0 }};
record(ns.read()); export {{ ns, extra }};
"#
        );
        for pairs in [
            expect_unpack_raw(&bundle),
            expect_unpack(&bundle, "bundle.js"),
        ] {
            let owner = &pairs.iter().find(|(name, _)| name == "ns.js").unwrap().1;
            assert!(
                owner.contains("from \"./entry.js\""),
                "deferred read stays linked: {owner}"
            );
            assert_eq!(validate_output_modules(&pairs), vec![]);
        }
    }
}

/// A CommonJS factory keeps its callable/cache boundary when its support
/// writer shares state with a lazy ESM initializer.
#[test]
fn cjs_support_writer_shares_lazy_state_owner() {
    let bundle = r#"
var __esm = (fn, value) => () => (fn && (value = fn(fn = 0)), value);
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var ready;
function enable() { ready = true; return ready; }
var init_state = __esm(() => { record('state'); ready = false; });
var require_lib = __commonJS((exports, module) => {
  init_state(); record('lib');
  module.exports = { enable, read: () => ready };
});
record('before');
var one = require_lib(); var two = require_lib();
record([one === two, one.read(), one.enable(), two.read()]);
"#;
    let pairs = expect_unpack_raw(bundle);
    let owner = &pairs
        .iter()
        .find(|(_, code)| code.contains("function enable"))
        .unwrap()
        .1;
    assert!(
        owner.contains("export function init_state")
            && owner.contains("export function require_lib"),
        "state, writer, and both callable factories must share an owner: {pairs:#?}"
    );
    let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
    assert!(
        !entry.contains("function enable") && !entry.contains("var ready"),
        "entry must not retain a second copy of the mutable state: {entry}"
    );
    assert_eq!(validate_output_modules(&pairs), vec![]);
    assert_eq!(
        validate_output_modules(&expect_unpack(bundle, "bundle.js")),
        vec![]
    );
}

/// An entry-owned hoisted function may write state extracted into a namespace
/// module even when that module never calls the writer itself.
#[test]
fn scope_state_adopts_entry_hoisted_writer() {
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var ns = {}; __export(ns, { read: () => read });
function read() { return ready; }
var ready = false;
function enable() { if (!ready) { ready = true; record('enabled'); } }
record(read()); enable(); enable(); record(read());
export { ns };
"#;
    let pairs = expect_unpack_raw(bundle);
    let owner = &pairs
        .iter()
        .find(|(_, code)| code.contains("var ready"))
        .unwrap()
        .1;
    assert!(
        owner.contains("function enable"),
        "state must own its hoisted writer: {pairs:#?}"
    );
    let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
    assert!(
        !entry.contains("function enable"),
        "entry must call the relocated writer: {entry}"
    );
    assert_eq!(validate_output_modules(&pairs), vec![]);
    assert_eq!(
        validate_output_modules(&expect_unpack(bundle, "bundle.js")),
        vec![]
    );
}

#[test]
fn scope_writer_adoption_requires_local_dependencies_and_binding_writes() {
    let prefix = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var ns = {}; __export(ns, { read: () => read });
function read() { return state; }
var state = {};
"#;
    for tail in [
        "function write(state) { state = {}; } write({});",
        "function write() { state.value = true; } write();",
    ] {
        let pairs = expect_unpack_raw(&format!("{prefix} {tail} export {{ ns }};"));
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(
            entry.contains("function write"),
            "shadowed/property writes must not nominate a writer: {pairs:#?}"
        );
    }
}

#[test]
fn scope_entry_writer_reads_entry_class_after_initialization() {
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var ns = {}; __export(ns, { read: () => read });
function read() { return ready; }
var ready = false;
class Value { static read() { return true; } }
function enable() { ready = Value.read(); }
enable(); record(read());
export { ns };
"#;
    let pairs = expect_unpack_raw(bundle);
    let owner = &pairs
        .iter()
        .find(|(_, code)| code.contains("var ready"))
        .unwrap()
        .1;
    assert!(
        owner.contains("function enable") && owner.contains("from \"./entry.js\""),
        "the deferred writer must import its entry dependency: {pairs:#?}"
    );
    let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
    assert!(
        entry.contains("class Value") && !entry.contains("function enable"),
        "entry retains the class initializer and calls the relocated function: {entry}"
    );
    assert_eq!(validate_output_modules(&pairs), vec![]);
    assert_eq!(
        validate_output_modules(&expect_unpack(bundle, "bundle.js")),
        vec![]
    );
}

#[test]
fn scope_writer_with_reassigned_function_binding_stays_in_entry() {
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var ns = {}; __export(ns, { read: () => read });
function read() { return ready; }
var ready = false;
function enable() { ready = true; }
enable = replacement;
enable();
export { ns };
"#;
    let pairs = expect_unpack_raw(bundle);
    let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
    assert!(
        entry.contains("function enable"),
        "moving a reassigned function would create a new import write: {pairs:#?}"
    );
}

#[test]
fn deferred_writer_import_is_independent_of_an_unsafe_sibling_consumer() {
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var early_ns = {}; __export(early_ns, { early: () => early });
function early() { return Value.read(); }
consume(early);
var late_ns = {}; __export(late_ns, { read: () => read });
function read() { return ready; }
var ready = false;
class Value { static read() { return true; } }
function enable() { ready = Value.read(); }
enable();
export { early_ns, late_ns };
"#;
    for pairs in [
        expect_unpack_raw(bundle),
        expect_unpack(bundle, "bundle.js"),
    ] {
        let late = &pairs
            .iter()
            .find(|(_, code)| code.contains("function enable"))
            .unwrap()
            .1;
        assert!(
            late.contains("from \"./entry.js\""),
            "safe consumer must get its import despite an unsafe sibling: {pairs:#?}"
        );
        let early = &pairs
            .iter()
            .find(|(_, code)| code.contains("function early"))
            .unwrap()
            .1;
        assert!(
            !early.contains("from \"./entry.js\""),
            "unsafe consumer must not acquire an eager entry edge: {early}"
        );
    }
}

#[test]
fn scope_entry_writer_does_not_adopt_a_reassigned_entry_dependency() {
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
function value() { return false; }
var ns = {}; __export(ns, { read: () => read });
function read() { return ready; }
var ready = false;
function enable() { ready = value(); }
value = () => true;
enable();
export { ns };
"#;
    let pairs = expect_unpack_raw(bundle);
    let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
    assert!(
        entry.contains("function value") && !entry.contains("function enable"),
        "writer dependencies must keep their entry ownership and writes: {pairs:#?}"
    );
    assert_eq!(validate_output_modules(&pairs), vec![]);
    assert_eq!(
        validate_output_modules(&expect_unpack(bundle, "bundle.js")),
        vec![]
    );
}

#[test]
fn scope_entry_writer_keeps_external_import_dependency() {
    let bundle = r#"
import { notify } from "external";
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
var ns = {}; __export(ns, { read: () => read });
function read() { return ready; }
var ready = false;
function enable() { ready = true; notify(); }
enable();
export { ns };
"#;
    let pairs = expect_unpack_raw(bundle);
    let owner = &pairs
        .iter()
        .find(|(_, code)| code.contains("var ready"))
        .unwrap()
        .1;
    assert!(
        owner.contains("function enable") && owner.contains("from \"external\""),
        "relocated writer must retain its external dependency: {pairs:#?}"
    );
    assert_eq!(validate_output_modules(&pairs), vec![]);
}

/// Factories that assign a top-level binding directly are writers of that
/// state, like support declarations. Every such factory joins one ownership
/// group, the group declares the state once, and entry.js re-imports it
/// instead of keeping a second copy.
#[test]
fn standalone_factories_writing_shared_state_share_one_owner() {
    let bundle = r#"
var __esm = (fn, value) => () => (fn && (value = fn(fn = 0)), value);
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var ready = 0;
var require_lib = __commonJS((exports, module) => { ready = 1; module.exports = { read: () => ready }; });
var init_lib = __esm(() => { ready = 2; });
record(require_lib().read()); init_lib(); record(require_lib().read()); record(ready);
"#;
    for pairs in [
        expect_unpack_raw(bundle),
        expect_unpack(bundle, "bundle.js"),
    ] {
        let declarations: Vec<&String> = pairs
            .iter()
            .filter(|(_, code)| code.contains("var ready = 0") || code.contains("let ready = 0"))
            .map(|(name, _)| name)
            .collect();
        assert_eq!(
            declarations.len(),
            1,
            "the state must be declared exactly once: {pairs:#?}"
        );
        let owner = &pairs
            .iter()
            .find(|(name, _)| name == declarations[0])
            .unwrap()
            .1;
        assert!(
            owner.contains("export function require_lib")
                && owner.contains("export function init_lib"),
            "both writers must share the state owner: {owner}"
        );
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(
            !entry.contains("var ready") && !entry.contains("let ready") && entry.contains("ready"),
            "entry must import the single mutable copy: {entry}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
    }
}

/// An entry function declaration that writes factory-owned state joins the
/// ownership unit like a support declaration: the group declares the state
/// and exports the writer, and entry calls it through an import.
#[test]
fn entry_function_writer_joins_factory_state_group() {
    for factory in [
        "var load = __commonJS((exports, module) => { ready = 1; module.exports = 1; });",
        "var load = __esm(() => { ready = 1; });",
    ] {
        let bundle = format!(
            r#"
var __esm = (fn, value) => () => (fn && (value = fn(fn = 0)), value);
var __commonJS = (cb, mod) => () => (mod || cb((mod = {{ exports: {{}} }}).exports, mod), mod.exports);
var require_dummy = __commonJS((exports, module) => {{ module.exports = {{}}; }});
var ready = 0;
{factory}
function reset() {{ ready = 2; }}
record(load()); reset(); record(ready); record(require_dummy());
export {{ reset }};
"#
        );
        for pairs in [
            expect_unpack_raw(&bundle),
            expect_unpack(&bundle, "bundle.js"),
        ] {
            let owners: Vec<&(String, String)> = pairs
                .iter()
                .filter(|(_, code)| code.contains("ready = 0"))
                .collect();
            assert_eq!(owners.len(), 1, "state declared once: {pairs:#?}");
            let owner = &owners[0].1;
            assert!(
                owner.contains("function reset") && owner.contains("export function load"),
                "writer and factory share the state owner: {owner}"
            );
            let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
            assert!(
                !entry.contains("ready = 0")
                    && !entry.contains("function reset")
                    && entry.contains("reset()")
                    && entry.contains("export { reset }"),
                "entry calls and re-exports the relocated writer: {entry}"
            );
            assert_eq!(validate_output_modules(&pairs), vec![]);
        }
    }
}

/// An entry writer that cannot move or join the group cancels the split. A
/// CommonJS factory demotes like a lazy ESM initializer: the entry keeps the
/// state, the writer, and a synthesized cached callable.
#[test]
fn unrelocatable_entry_writer_demotes_cjs_factory_group() {
    for writer in [
        "var reset = () => { ready = 2; };",
        "function reset() { ready = 2; } reset = () => { ready = 3; };",
    ] {
        let bundle = format!(
            r#"
var __commonJS = (cb, mod) => () => (mod || cb((mod = {{ exports: {{}} }}).exports, mod), mod.exports);
var ready = 0;
var load = __commonJS((exports, module) => {{ ready = 1; module.exports = {{ read: () => ready }}; }});
{writer}
record(load().read()); reset(); record(ready);
"#
        );
        for pairs in [
            expect_unpack_raw(&bundle),
            expect_unpack(&bundle, "bundle.js"),
        ] {
            assert!(
                pairs.iter().all(|(name, _)| name != "load.js"),
                "the group must demote into entry: {pairs:#?}"
            );
            let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
            assert!(
                entry.contains("ready = 0")
                    && entry.contains("function load()")
                    && entry.contains("__wakaru_load_cache")
                    && entry.contains("ready = 1")
                    && entry.contains("ready = 2"),
                "entry keeps state, writer, and the cached factory: {entry}"
            );
            assert_eq!(validate_output_modules(&pairs), vec![]);
        }
    }
}

/// Cancelling a multi-factory split must remove its compatibility aliases,
/// while aliases of a surviving writer group still point to a real owner.
#[test]
fn demoted_factory_group_leaves_no_forwarding_modules() {
    let bundle = format!(
        r#"{SCOPE_HELPERS}
var state = 0;
var first = __commonJS((exports, module) => {{ state = 1; module.exports = () => state; }});
var second = __commonJS((exports, module) => {{ state = 2; module.exports = () => state; }});
var reset = () => {{ state = 3; }};
var other = 0;
var keep_first = __commonJS((exports, module) => {{ other = 4; module.exports = () => other; }});
var keep_second = __commonJS((exports, module) => {{ other = 5; module.exports = () => other; }});
record(first()()); record(second()()); reset(); record(state);
record(keep_first()()); record(keep_second()());
"#
    );
    for pairs in [
        expect_unpack_raw(&bundle),
        expect_unpack(&bundle, "bundle.js"),
    ] {
        assert!(
            pairs
                .iter()
                .all(|(name, _)| name != "first.js" && name != "second.js"),
            "demoted members must leave no standalone or forwarding file: {pairs:#?}"
        );
        assert!(pairs.iter().any(|(name, _)| name == "keep_first.js"));
        assert!(pairs.iter().any(|(name, _)| name == "keep_second.js"));
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(entry.contains("function first()") && entry.contains("function second()"));
        assert_eq!(validate_output_modules(&pairs), vec![]);
    }
}

/// Scope extraction precedes factory demotion. Imports for those provisional
/// owners must not survive after both state and callables return to entry.
#[test]
fn demoted_factory_state_has_no_stale_entry_import() {
    for factories in [
        "var first = __esm(() => { state = 1; }); var second = __esm(() => { state = 2; });",
        "var first = __commonJS(() => { state = 1; }); var second = __commonJS(() => { state = 2; });",
    ] {
        let bundle = format!(
            r#"{SCOPE_HELPERS}
var state = 0;
{factories}
var reset = () => {{ state = 3; }};
first(); record(state); second(); record(state); reset(); record(state);
var extra = {{}}; __export(extra, {{ get: () => get }});
function get() {{ return 7; }}
record(extra.get()); export {{ extra }};
"#
        );
        for pairs in [expect_unpack_raw(&bundle), expect_unpack(&bundle, "bundle.js")] {
            let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
            assert!(entry.contains("function first()") && entry.contains("function second()"));
            assert!(entry.contains("state = 0"));
            assert!(
                !entry.contains("from \"./first.js\"") && !entry.contains("from \"./second.js\""),
                "entry cannot import demoted factory state: {entry}"
            );
            assert_eq!(validate_output_modules(&pairs), vec![]);
        }
    }
}

/// A factory declared in a mixed declaration leaves its sibling declarator
/// in entry. With an unrelocatable entry writer the group still cancels its
/// split, and no assignment to an import survives.
#[test]
fn mixed_declaration_factory_group_demotes_with_entry_writer() {
    let bundle = r#"
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var ready = 0, load = __commonJS((exports, module) => { ready = 1; module.exports = 1; });
var reset = () => { ready = 2; };
record(load()); reset(); record(ready);
"#;
    for pairs in [
        expect_unpack_raw(bundle),
        expect_unpack(bundle, "bundle.js"),
    ] {
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(
            entry.contains("ready = 0") && entry.contains("ready = 2"),
            "entry keeps the state its writer assigns: {pairs:#?}"
        );
        assert!(
            validate_output_modules(&pairs)
                .iter()
                .all(|finding| finding.kind != OutputFindingKind::AssignToImport),
            "no import write may remain: {pairs:#?}"
        );
    }
}

/// A demoted factory's synthesized cache or guard must not reuse a name the
/// entry already declares: a `var` collision silently skips the factory body
/// and a lexical collision is a duplicate declaration.
#[test]
fn demoted_factory_helpers_avoid_entry_declarations() {
    let cjs = "var load = __commonJS((exports, module) => { ready = 1; module.exports = 1; });";
    let esm = "var load = __esm(() => { ready = 1; });";
    let cjs_local = "var load = __commonJS((exports, module) => { var __wakaru_load_cache$2 = 7; ready = 1; module.exports = __wakaru_load_cache$2; });";
    let esm_local = "var load = __esm(() => { var __wakaru_load_initialized$2 = 7; ready = __wakaru_load_initialized$2; });";
    for (factory, existing, helper, fresh) in [
        (
            cjs,
            "var __wakaru_load_cache = 42;",
            "__wakaru_load_cache",
            "$2",
        ),
        (
            cjs,
            "let __wakaru_load_cache = 42;",
            "__wakaru_load_cache",
            "$2",
        ),
        (
            esm,
            "var __wakaru_load_initialized = 42;",
            "__wakaru_load_initialized",
            "$2",
        ),
        (
            esm,
            "let __wakaru_load_initialized = 42;",
            "__wakaru_load_initialized",
            "$2",
        ),
        // A factory-local binding occupying the next candidate would shadow
        // the cache inside the callable and re-run the body on every call.
        (
            cjs_local,
            "var __wakaru_load_cache = 42;",
            "__wakaru_load_cache",
            "$3",
        ),
        (
            esm_local,
            "var __wakaru_load_initialized = 42;",
            "__wakaru_load_initialized",
            "$3",
        ),
    ] {
        let bundle = format!(
            r#"
var __esm = (fn, value) => () => (fn && (value = fn(fn = 0)), value);
var __commonJS = (cb, mod) => () => (mod || cb((mod = {{ exports: {{}} }}).exports, mod), mod.exports);
var require_dummy = __commonJS((exports, module) => {{ module.exports = {{}}; }});
{existing}
var ready = 0;
{factory}
var reset = () => {{ ready = 2; }};
load(); reset(); record([ready, {helper}]); record(require_dummy());
"#
        );
        let pairs = expect_unpack_raw(&bundle);
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(
            entry.contains("function load()")
                && entry.contains(&format!("{helper} = 42"))
                && entry.contains(&format!("var {helper}{fresh}")),
            "the demoted helper must take a fresh name: {entry}"
        );
        assert_eq!(
            entry.matches(&format!("{helper} = 42")).count(),
            1,
            "the existing declaration stays untouched: {entry}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
        assert_eq!(
            validate_output_modules(&expect_unpack(&bundle, "bundle.js")),
            vec![]
        );
    }
}

const SCOPE_HELPERS: &str = r#"
var __esm = (fn, value) => () => (fn && (value = fn(fn = 0)), value);
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __defProp = Object.defineProperty;
var __export = (target, all) => { for (var name in all) __defProp(target, name, { get: all[name], enumerable: true }); };
"#;

/// A CommonJS factory whose written state sits inside a scope module's
/// region follows the lazy ESM initializer path: the factory keeps its
/// cached callable next to the state it owns, and the module's call to it
/// resolves either locally or through an import.
#[test]
fn scope_module_reaches_cjs_factory_writing_region_state() {
    let bundle = format!(
        r#"{SCOPE_HELPERS}
var ns = {{}}; __export(ns, {{ get: () => get }});
function get() {{ return load(); }}
var ready = 0;
var load = __commonJS((exports, module) => {{ ready = 1; module.exports = 1; }});
record(ns.get()); record(ready);
export {{ ns }};
"#
    );
    for pairs in [
        expect_unpack_raw(&bundle),
        expect_unpack(&bundle, "bundle.js"),
    ] {
        let owners: Vec<&(String, String)> = pairs
            .iter()
            .filter(|(_, code)| code.contains("function load()"))
            .collect();
        assert_eq!(owners.len(), 1, "the factory is emitted once: {pairs:#?}");
        let (owner_name, owner) = owners[0];
        assert!(
            owner.contains("__wakaru_load_cache")
                && owner.contains("ready = 1")
                && owner.contains("ready = 0"),
            "the factory keeps its cached callable next to its state: {owner}"
        );
        let ns = &pairs.iter().find(|(name, _)| name == "ns.js").unwrap().1;
        assert!(
            owner_name == "ns.js" || ns.contains("import { load }"),
            "the scope module must reach the factory it calls: {ns}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
    }
}

/// A scope module that calls a standalone CommonJS factory imports it even
/// when that factory assigns entry-owned state.
#[test]
fn scope_module_imports_cjs_factory_that_writes_entry_state() {
    let bundle = format!(
        r#"{SCOPE_HELPERS}
var ready = 0;
var ns = {{}}; __export(ns, {{ get: () => get }});
function get() {{ return load(); }}
var load = __commonJS((exports, module) => {{ ready = 1; module.exports = 1; }});
record(ns.get()); record(ready);
export {{ ns }};
"#
    );
    for pairs in [
        expect_unpack_raw(&bundle),
        expect_unpack(&bundle, "bundle.js"),
    ] {
        let ns = &pairs.iter().find(|(name, _)| name == "ns.js").unwrap().1;
        assert!(
            ns.contains("import { load } from \"./load.js\""),
            "the scope module must import the factory it calls: {ns}"
        );
        let load = &pairs.iter().find(|(name, _)| name == "load.js").unwrap().1;
        assert!(
            load.contains("export function load()") && load.contains("ready = 0"),
            "the standalone factory owns the state it writes: {load}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
    }
}

/// A scope module that writes a CommonJS factory's state claims the factory.
/// The merged factory keeps its cached callable, is exported for entry
/// callers, and still imports the sibling factory its body calls.
#[test]
fn merged_cjs_factory_imports_sibling_factory() {
    let bundle = format!(
        r#"{SCOPE_HELPERS}
var ns = {{}}; __export(ns, {{ get: () => get }});
function get() {{ value += 1; return value; }}
var value = 0;
var fill = __commonJS((exports, module) => {{ value = load(); module.exports = 1; }});
var ready = 0;
var load = __commonJS((exports, module) => {{ ready = 1; module.exports = 1; }});
record(fill()); record(ns.get()); record(ready);
export {{ ns }};
"#
    );
    for pairs in [
        expect_unpack_raw(&bundle),
        expect_unpack(&bundle, "bundle.js"),
    ] {
        let ns = &pairs.iter().find(|(name, _)| name == "ns.js").unwrap().1;
        assert!(
            ns.contains("export function fill()")
                && ns.contains("__wakaru_fill_cache")
                && ns.contains("value = load()")
                && ns.contains("import { load } from \"./load.js\""),
            "the merged factory is emitted with its import: {ns}"
        );
        assert!(
            pairs.iter().all(|(name, _)| name != "fill.js"),
            "no standalone file remains for the merged factory: {pairs:#?}"
        );
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(
            entry.contains("fill()"),
            "entry keeps calling the merged factory: {entry}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
    }
}

/// When a merged factory references a group that an unrelocatable entry
/// writer would demote, the split cannot be cancelled. The writer's
/// assignment to the imported state remains and output validation reports
/// it; the state is never forked into a second silent copy.
#[test]
fn undemotable_writer_group_keeps_validator_visible_residual() {
    let bundle = format!(
        r#"{SCOPE_HELPERS}
var ns = {{}}; __export(ns, {{ get: () => get }});
function get() {{ value += 1; return value; }}
var value = 0;
var fill = __commonJS((exports, module) => {{ value = load(); module.exports = 1; }});
var ready = 0;
var load = __commonJS((exports, module) => {{ ready = 1; module.exports = 1; }});
var reset = () => {{ ready = 2; }};
record(fill()); record(ns.get()); reset(); record(ready);
export {{ ns }};
"#
    );
    for pairs in [
        expect_unpack_raw(&bundle),
        expect_unpack(&bundle, "bundle.js"),
    ] {
        assert_eq!(
            pairs
                .iter()
                .filter(|(_, code)| code.contains("ready = 0"))
                .count(),
            1,
            "the state must not fork: {pairs:#?}"
        );
        let findings = validate_output_modules(&pairs);
        assert!(
            findings.len() == 1
                && findings[0].filename == "entry.js"
                && findings[0].kind == OutputFindingKind::AssignToImport,
            "the residual is exactly the entry writer's import assignment: {findings:#?}"
        );
    }
}

/// Synthesized factory caches and guards avoid names declared in the module
/// they are emitted into, for merged and standalone emission alike.
#[test]
fn factory_helpers_avoid_module_declarations() {
    let merged = format!(
        r#"{SCOPE_HELPERS}
var ns = {{}}; __export(ns, {{ get: () => get }});
function get() {{ ready = 5; return load() + __wakaru_load_cache; }}
var __wakaru_load_cache = 40;
var ready = 0;
var load = __commonJS((exports, module) => {{ ready = 1; module.exports = 2; }});
record(ns.get());
export {{ ns }};
"#
    );
    let standalone = format!(
        r#"{SCOPE_HELPERS}
var __wakaru_load_cache = 40;
var __wakaru_init_initialized = 40;
var load = __commonJS((exports, module) => {{ module.exports = __wakaru_load_cache; }});
var init = __esm(() => {{ record(__wakaru_init_initialized); }});
record(load()); init();
"#
    );
    // The factory bodies themselves declare the base name and the next
    // candidate, as a local and as a parameter.
    let body_locals = format!(
        r#"{SCOPE_HELPERS}
var load = __commonJS((exports, module) => {{ var __wakaru_load_cache = 40, __wakaru_load_cache$2 = 1; module.exports = __wakaru_load_cache; }});
var init = __esm(() => {{ var __wakaru_init_initialized = 40; record(((__wakaru_init_initialized$2) => __wakaru_init_initialized$2)(__wakaru_init_initialized)); }});
record(load()); init();
"#
    );
    for (bundle, owner, helper, fresh) in [
        (&merged, "ns.js", "__wakaru_load_cache", "$2"),
        (&standalone, "load.js", "__wakaru_load_cache", "$2"),
        (&standalone, "init.js", "__wakaru_init_initialized", "$2"),
        (&body_locals, "load.js", "__wakaru_load_cache", "$3"),
        (&body_locals, "init.js", "__wakaru_init_initialized", "$3"),
    ] {
        let pairs = expect_unpack_raw(bundle);
        let code = &pairs.iter().find(|(name, _)| name == owner).unwrap().1;
        assert!(
            code.contains(&format!("{helper} = 40"))
                && code.contains(&format!("var {helper}{fresh}")),
            "the helper must take a fresh name next to the user declaration: {code}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
        assert_eq!(
            validate_output_modules(&expect_unpack(bundle, "bundle.js")),
            vec![]
        );
    }
}

/// One factory writing top-level state is still a writer group: the entry
/// declaration moves into the factory and entry reads follow the import.
#[test]
fn single_factory_state_write_moves_entry_declaration() {
    for factory in [
        "var require_lib = __commonJS((exports, module) => { ready = true; module.exports = { read: () => ready }; });
record(require_lib().read()); record(ready);",
        "var init_lib = __esm(() => { ready = true; });
init_lib(); record(ready); record(require_dummy());",
    ] {
        let bundle = format!(
            r#"
var __esm = (fn, value) => () => (fn && (value = fn(fn = 0)), value);
var __commonJS = (cb, mod) => () => (mod || cb((mod = {{ exports: {{}} }}).exports, mod), mod.exports);
var require_dummy = __commonJS((exports, module) => {{ module.exports = {{}}; }});
var ready;
{factory}
"#
        );
        let pairs = expect_unpack_raw(&bundle);
        let entry = &pairs.iter().find(|(name, _)| name == "entry.js").unwrap().1;
        assert!(
            !entry.contains("var ready") && entry.contains("ready"),
            "entry must not fork the factory-owned state: {pairs:#?}"
        );
        assert_eq!(
            pairs
                .iter()
                .filter(|(_, code)| code.contains("var ready"))
                .count(),
            1,
            "the state must be declared exactly once: {pairs:#?}"
        );
        assert_eq!(validate_output_modules(&pairs), vec![]);
        assert_eq!(
            validate_output_modules(&expect_unpack(&bundle, "bundle.js")),
            vec![]
        );
    }
}

/// A top-level initialization assignment is part of the mutable binding's
/// ownership unit. If support writers make a standalone factory own the
/// declaration, leaving the initializer in entry.js creates an assignment to
/// an immutable synthesized import.
#[test]
fn standalone_factory_owns_top_level_state_initializer() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var first = y(() => { firstValue = 1; });
var second = y(() => { secondValue = 2; });
var third = y(() => { thirdValue = 3; });
var fourth = y(() => { fourthValue = 4; });
var ready = typeof window !== "undefined";
var state;
state = ready ? getComputedStyle(document.documentElement) : undefined;
function readState() { return state; }
function writeState(value) { state = value; }
var init_config = y(() => { use(ready, readState, writeState); });
init_config();
console.log(state);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let owner_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("export function init_config"))
        .expect("config factory should own its mutable support closure")
        .1;
    assert!(
        owner_code.contains("var state")
            && owner_code
                .contains("state = ready ? getComputedStyle(document.documentElement) : undefined")
            && owner_code.contains("function writeState")
            && !owner_code.contains("import { state"),
        "the owner must contain the declaration, initializer, and later writer:\n{owner_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        !entry_code.contains("state = ready ?") && !entry_code.contains("var state"),
        "entry must not retain a writer or duplicate declaration:\n{entry_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "relocating the mutable initialization must produce valid ESM"
    );
}

/// A conditional top-level writer is part of the mutable binding's ownership
/// unit exactly like a plain initializer: when a standalone factory owns the
/// declaration, leaving `if (ready) state = ...` in entry.js creates an
/// assignment to an immutable synthesized import.
#[test]
fn standalone_factory_owns_conditional_state_writer() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var first = y(() => { firstValue = 1; });
var second = y(() => { secondValue = 2; });
var third = y(() => { thirdValue = 3; });
var fourth = y(() => { fourthValue = 4; });
var ready = typeof window !== "undefined";
var state;
if (ready) state = getComputedStyle(document.documentElement);
function readState() { return state; }
function writeState(value) { state = value; }
var init_config = y(() => { use(ready, readState, writeState); });
init_config();
console.log(state);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let owner_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("export function init_config"))
        .expect("config factory should own its mutable support closure")
        .1;
    assert!(
        owner_code.contains("var state")
            && owner_code.contains("if (ready) state = getComputedStyle(document.documentElement)")
            && !owner_code.contains("import { state"),
        "the owner must contain the declaration and the conditional writer:\n{owner_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        !entry_code.contains("state = getComputedStyle") && !entry_code.contains("var state"),
        "entry must not retain a writer or duplicate declaration:\n{entry_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "relocating the conditional writer must produce valid ESM"
    );
}

/// When a top-level writer of factory-owned state cannot be relocated (here it
/// reads `flags`, an entry-owned binding nothing exports), the ownership split
/// must be cancelled as a unit: the factory group stays in entry.js instead of
/// leaving the writer behind as an assignment to an immutable import.
#[test]
fn unrelocatable_state_writer_demotes_the_factory_group() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var first = y(() => { firstValue = 1; });
var second = y(() => { secondValue = 2; });
var third = y(() => { thirdValue = 3; });
var fourth = y(() => { fourthValue = 4; });
var flags = readFlags();
flags.checked = true;
var state;
state = flags.enabled ? getComputedStyle(document.documentElement) : undefined;
function readState() { return state; }
function writeState(value) { state = value; }
var init_config = y(() => { use(readState, writeState); });
init_config();
console.log(state, flags);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("var state")
            && entry_code.contains("state = flags.enabled ?")
            && entry_code.contains("init_config")
            && !entry_code.contains("import { state"),
        "the demoted group must stay in entry with its writer:\n{entry_code}"
    );
    assert!(
        !raw_pairs
            .iter()
            .any(|(name, code)| name != "entry.js" && code.contains("init_config")),
        "no other module may claim the demoted factory: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "cancelling the split must produce valid ESM"
    );
}

/// A `for ... in` / `for ... of` assignment head writes its existing binding
/// even though SWC represents that target as a pattern rather than an
/// `AssignExpr`. Those writers must follow state owned by a standalone factory
/// just like ordinary assignment statements.
#[test]
fn standalone_factory_owns_for_head_state_writers() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var first = y(() => { firstValue = 1; });
var second = y(() => { secondValue = 2; });
var third = y(() => { thirdValue = 3; });
var fourth = y(() => { fourthValue = 4; });
var state;
for (state of globalThis.values) consume(state);
var key;
for (key in globalThis.values) consume(key);
function readState() { return state; }
function writeState(value) { state = value; }
function readKey() { return key; }
function writeKey(value) { key = value; }
var init_config = y(() => { use(readState, writeState, readKey, writeKey); });
init_config();
console.log(state, key);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let owner_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("export function init_config"))
        .expect("config factory should own its mutable support closure")
        .1;
    assert!(
        owner_code.contains("var state")
            && owner_code.contains("for (state of globalThis.values)")
            && owner_code.contains("var key")
            && owner_code.contains("key in globalThis.values"),
        "for-head writers must move with their declarations:\n{owner_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        !entry_code.contains("state of globalThis.values")
            && !entry_code.contains("key in globalThis.values"),
        "entry must not retain a writer of relocated state:\n{entry_code}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "relocating for-head writers must produce valid ESM"
    );
}

/// Demotion closure must use the references of top-level writer statements
/// already scheduled for relocation. Otherwise a writer can move into group A
/// while its dependency's group B is demoted back to entry, leaving an
/// unresolved binding in A.
#[test]
fn demotion_cascades_through_relocated_writer_dependencies() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var first = y(() => { firstValue = 1; });
var second = y(() => { secondValue = 2; });
var third = y(() => { thirdValue = 3; });
var fourth = y(() => { fourthValue = 4; });
var flags = readFlags();
flags.checked = true;
var stateB;
stateB = flags.enabled ? getComputedStyle(document.documentElement) : undefined;
function readB() { return stateB; }
function writeB(value) { stateB = value; }
var init_b = y(() => { use(readB, writeB); });
var stateA;
if (globalThis.ready) stateA = stateB;
function readA() { return stateA; }
function writeA(value) { stateA = value; }
var init_a = y(() => { use(readA, writeA); });
init_a();
init_b();
console.log(stateA, stateB, flags);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("var stateA")
            && entry_code.contains("var stateB")
            && entry_code.contains("stateA = stateB")
            && entry_code.contains("function init_a")
            && entry_code.contains("function init_b"),
        "both dependent ownership groups must demote together:\n{entry_code}"
    );
    assert!(
        !raw_pairs.iter().any(|(name, code)| {
            name != "entry.js" && (code.contains("init_a") || code.contains("init_b"))
        }),
        "no standalone module may retain either demoted group: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "cascading demotion must not leave an unresolved cross-group reference"
    );
}

/// The support declarations adopted by a standalone group participate in its
/// emitted dependency surface too. Their references must therefore drive the
/// same demotion closure as factory bodies and relocated writer statements.
#[test]
fn demotion_cascades_through_owned_support_dependencies() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var first = y(() => { firstValue = 1; });
var second = y(() => { secondValue = 2; });
var third = y(() => { thirdValue = 3; });
var fourth = y(() => { fourthValue = 4; });
var flags = readFlags();
flags.checked = true;
var stateB;
stateB = flags.enabled ? getComputedStyle(document.documentElement) : undefined;
function readB() { return stateB; }
function writeB(value) { stateB = value; }
var init_b = y(() => { use(readB, writeB); });
var stateA;
function readA() { return stateA === stateB; }
function writeA(value) { stateA = value; }
var init_a = y(() => { use(readA, writeA); });
init_a();
init_b();
console.log(stateA, stateB, flags);
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("var stateA")
            && entry_code.contains("var stateB")
            && entry_code.contains("stateA === stateB")
            && entry_code.contains("function init_a")
            && entry_code.contains("function init_b"),
        "a support-declaration dependency must demote both groups:\n{entry_code}"
    );
    assert!(
        !raw_pairs.iter().any(|(name, code)| {
            name != "entry.js" && (code.contains("init_a") || code.contains("init_b"))
        }),
        "no standalone module may retain either demoted group: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "support-dependency demotion must not leave an unresolved reference"
    );
}

/// A lazy factory claimed by a scope module relocates its support-declaration
/// closure — including passive state declarations that the adoption pass
/// cannot claim (they are not function-shaped). The entry copy of such a
/// declaration must be dropped, not left behind as a silently forked binding.
#[test]
fn scope_claimed_factory_state_is_not_forked_into_the_entry() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_state = y(() => { shared = { count: 0 }; });
var shared;
function read() { return shared; }
function write(value) { shared = value; }
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { marker: () => marker, read: () => read, write: () => write });
var marker = "writer";
init_state();
console.log(marker, shared);
export { ns_writer };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let owner_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function init_state"))
        .expect("the claiming scope module should exist")
        .1;
    assert!(
        owner_code.contains("var shared"),
        "the claiming module must own the factory state declaration:\n{owner_code}"
    );
    let raw_entry = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        !raw_entry.contains("var shared"),
        "entry must not keep a dead duplicate of relocated factory state:\n{raw_entry}"
    );

    // The full pipeline additionally dedups the synthesized imports, so the
    // entry read resolves through one unaliased live import of the owner's
    // single mutable binding.
    let decompiled = expect_unpack(bundle, "bundle.js");
    let entry_code = &decompiled
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("shared")
            && !entry_code.contains("shared as ")
            && !entry_code.contains("let shared")
            && !entry_code.contains("var shared"),
        "entry reads must resolve through an unaliased import of the owner's state:\n{entry_code}"
    );
    assert_eq!(
        validate_output_modules(&decompiled),
        vec![],
        "relocated factory state must produce a valid module graph"
    );
}

/// Multiple pre-boundary support writers for state seeded by one lazy factory
/// must merge just like writers discovered during the initial partition.
#[test]
fn adopted_conflicting_scope_writers_merge_with_shared_init_factory() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_state = y(() => { sharedA = 1; sharedB = 2; });
var sharedA;
var sharedB;
function readA() { return sharedA; }
function writeA(value) { sharedA = value; }
function readB() { return sharedB; }
function writeB(value) { sharedB = value; }
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { markerA: () => markerA, readA: () => readA, writeA: () => writeA });
var markerA = "a";
var ns_b = {};
__export(ns_b, { markerB: () => markerB, readB: () => readB, writeB: () => writeB });
var markerB = "b";
init_state();
console.log(markerA, markerB, readA(), readB());
export { ns_a, ns_b };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let combined = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function writeA") && code.contains("function writeB"))
        .expect("adopted writers should merge into one module")
        .1;
    assert!(
        combined.contains("var sharedA")
            && combined.contains("var sharedB")
            && combined.contains("export function init_state")
            && !combined.contains("import { sharedA")
            && !combined.contains("import { sharedB"),
        "the combined module must own both mutable bindings and their initializer:\n{combined}"
    );
    assert_eq!(
        validate_output_modules(&raw_pairs),
        vec![],
        "merged adopted writers must not assign to imports"
    );
}

/// Merged factories adopt top-level declarations that their init bodies read.
/// When the adopted binding shares a `var` statement with an unrelated
/// declarator, only the adopted declarator belongs in the merged module.
/// Emitting the sibling without following its dependencies can leave a
/// dangling reference in the recovered module.
#[test]
fn merged_factory_filters_unowned_siblings_from_mixed_declaration() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var other_dep = { count: 0 };
var seed_a = 1, seed_b = 2, wide_w = other_dep.count;
var init_state = y(() => { shared = seed_a + seed_b; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { read: () => read, write: () => write });
var shared;
function read() { return shared; }
function write(value) { shared = value; }
init_state();
console.log(wide_w);
export { ns_writer };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let writer_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function write"))
        .expect("scope writer module should exist")
        .1;
    assert!(
        writer_code.contains("var seed_a = 1, seed_b = 2")
            && !writer_code.contains("wide_w")
            && !writer_code.contains("other_dep"),
        "merged module should emit all adopted declarators but not their sibling:\n{writer_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("other_dep") && entry_code.contains("wide_w = other_dep.count"),
        "unowned sibling and its dependency should remain in entry:\n{entry_code}"
    );
}

/// Inline ESM export declarations use a different AST wrapper than ordinary
/// declarations. Merged factories should still adopt the referenced
/// declarators without pulling unrelated exported siblings into the module.
#[test]
fn merged_factory_adopts_inline_exported_mixed_declaration() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var other_dep = { count: 0 };
export var seed_a = 1, seed_b = 2, wide_w = other_dep.count;
var init_state = y(() => { shared = seed_a + seed_b; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_writer = {};
__export(ns_writer, { read: () => read, write: () => write });
var shared;
function read() { return shared; }
function write(value) { shared = value; }
init_state();
console.log(wide_w);
export { ns_writer };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    let writer_code = &raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function write"))
        .expect("scope writer module should exist")
        .1;
    assert!(
        writer_code.contains("var seed_a = 1, seed_b = 2")
            && !writer_code.contains("wide_w")
            && !writer_code.contains("other_dep"),
        "merged module should unwrap and filter the inline export declaration:\n{writer_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("other_dep") && entry_code.contains("wide_w = other_dep.count"),
        "unowned exported sibling and its dependency should remain in entry:\n{entry_code}"
    );
}

/// If a lazy init factory seeds mutable state written by multiple scope
/// modules, those writer modules must merge into one synthetic module. Keeping
/// them split would force at least one scope module to assign to an imported
/// binding, which is invalid ESM.
#[test]
fn conflicting_scope_writers_merge_with_shared_init_factory() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_state = y(() => { sharedA = 1; sharedB = 2; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { readA: () => readA, writeA: () => writeA });
var sharedA;
function readA() { return sharedA; }
function writeA(value) { sharedA = value; }
var ns_b = {};
__export(ns_b, { readB: () => readB, writeB: () => writeB });
var sharedB;
function readB() { return sharedB; }
function writeB(value) { sharedB = value; }
init_state();
console.log(readA(), readB());
export { ns_a, ns_b };
"#;

    let raw_pairs = expect_unpack_raw(bundle);
    assert!(
        raw_pairs.iter().all(|(name, _)| name != "init_state.js"),
        "shared init factory should merge into the combined writer module: {:?}",
        raw_pairs.iter().map(|(name, _)| name).collect::<Vec<_>>()
    );

    let (combined_name, combined_code) = raw_pairs
        .iter()
        .find(|(_, code)| code.contains("function writeA") && code.contains("function writeB"))
        .expect("combined writer module should exist");
    assert!(
        combined_code.contains("var sharedA")
            && combined_code.contains("var sharedB")
            && combined_code.contains("export function init_state")
            && combined_code.contains("sharedA = 1")
            && combined_code.contains("sharedB = 2")
            && combined_code.contains("sharedA = value")
            && combined_code.contains("sharedB = value")
            && combined_code.contains("export var ns_a")
            && combined_code.contains("export var ns_b"),
        "combined module should own both namespaces, mutable state, and init factory:\n{combined_code}"
    );
    assert!(
        !combined_code.contains("import { sharedA") && !combined_code.contains("import { sharedB"),
        "combined writer module must not assign to imported mutable state:\n{combined_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains(&format!("from \"./{combined_name}\""))
            && !entry_code.contains("from \"./init_state.js\""),
        "entry should import init/state references from the combined writer module:\n{entry_code}"
    );
}

/// Split init factories remain callable guarded functions so other modules can
/// trigger the original lazy initializer without running the body at ESM
/// evaluation time.
#[test]
fn standalone_init_factory_preserves_callable_symbol() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_target = y(() => { target = 1; });
var init_other = y(() => { init_target(); other = target + 1; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var mod_exports = {};
__export(mod_exports, { target: () => target, other: () => other });
var target, other;
export { mod_exports };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let target_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_target.js")
        .expect("init_target module should exist")
        .1;
    assert!(
        target_code.contains("export function init_target"),
        "init_target should remain callable/exported:\n{target_code}"
    );
    assert!(
        target_code.contains("__wakaru_init_target_initialized")
            && target_code.contains("target = 1")
            && target_code.contains("export { target"),
        "init_target should remain guarded and export written state:\n{target_code}"
    );

    let other_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_other.js")
        .expect("init_other module should exist")
        .1;
    assert!(
        other_code.contains("import { init_target, target } from \"./init_target.js\"")
            && other_code.contains("init_target()")
            && other_code.contains("other = target + 1"),
        "init_other should import and call init_target:\n{other_code}"
    );
}

#[test]
fn standalone_init_factory_preserves_lazy_body() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_lazy = y(() => { value = compute(); });
function compute() { return 1; }
init_lazy();
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let lazy_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_lazy.js")
        .expect("init_lazy module should exist")
        .1;
    assert!(
        lazy_code.contains("var __wakaru_init_lazy_initialized = false")
            && lazy_code.contains("export function init_lazy")
            && lazy_code.contains("value = compute()"),
        "standalone init factory should preserve a guarded lazy body:\n{lazy_code}"
    );
}

/// Update expressions (count++) that write to a scope-hoisted binding should
/// stay in a standalone lazy factory and export the state they mutate.
#[test]
fn update_expr_write_stays_in_standalone_factory() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var init_counter = y(() => { count++; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var counter_exports = {};
__export(counter_exports, { count: () => count });
var count = 0;
export { counter_exports };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let counter_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_counter.js")
        .expect("init_counter module should exist")
        .1;
    assert!(
        counter_code.contains("count++")
            && counter_code.contains("var count = 0")
            && counter_code.contains("export { count }")
            && counter_code.contains("export function init_counter"),
        "init_counter should contain the guarded count++ and exported state:\n{counter_code}"
    );
}

/// Standalone lazy factories own the top-level state they initialize.  If the
/// state stays in entry.js, the emitted factory body assigns an undeclared ESM
/// binding and Node throws before the bundle can run.
#[test]
fn standalone_factory_exports_written_state_for_later_factories() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var a, b;
var init_a = y(() => { a = 1; });
var init_b = y(() => { init_a(); b = a + 1; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_b();
console.log(b);
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_a_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_a.js")
        .expect("init_a module should exist")
        .1;
    assert!(
        init_a_code.contains("var a") && init_a_code.contains("export { a"),
        "init_a should export its written state:\n{init_a_code}"
    );

    let init_b_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_b.js")
        .expect("init_b module should exist")
        .1;
    assert!(
        init_b_code.contains("import { a, init_a }") && init_b_code.contains("./init_a.js"),
        "init_b should import init_a and state a from init_a:\n{init_b_code}"
    );
    assert!(
        init_b_code.contains("var b") && init_b_code.contains("export { b"),
        "init_b should export its written state:\n{init_b_code}"
    );
}

#[test]
fn standalone_init_factory_decompiles_storage_before_callable_wrapper() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var a;
var init_a = y(() => { a = 1; });
var init_b = y(() => { init_a(); });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_b();
console.log(a);
"#;
    let pairs = expect_unpack(bundle, "bundle.js");

    let init_a_code = &pairs
        .iter()
        .find(|(n, _)| n == "init_a.js")
        .expect("init_a module should exist")
        .1;
    let storage_pos = init_a_code
        .find("let a;")
        .or_else(|| init_a_code.find("var a;"))
        .expect("init_a should declare its written state");
    let wrapper_pos = init_a_code
        .find("export function init_a")
        .expect("init_a should export its callable wrapper");
    assert!(
        storage_pos < wrapper_pos,
        "written state must be declared before the callable init wrapper:\n{init_a_code}"
    );
}

#[test]
fn scope_module_imports_factory_owned_binding_from_mixed_declaration() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
function memoize(fn) { return function() { return fn.apply(this, arguments); }; }
var label = "ok", memo;
var init_memo = y(() => { memo = memoize; });
var init_user = y(() => { init_memo(); cached = useMemo; });
var cached;
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns = {};
__export(ns, { useMemo: () => useMemo });
function useMemo(fn) { return memo(fn); }
var ns_b = {};
__export(ns_b, { other: () => other });
function other() { return label; }
init_user();
console.log(cached(() => label)());
export { ns, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns.js")
        .expect("scope module should exist")
        .1;
    assert!(
        ns_code.contains("import { memo } from \"./init_memo.js\""),
        "scope module should import factory-owned memo binding:\n{ns_code}"
    );
    assert!(
        !ns_code.contains("memo;") && !ns_code.contains("memo,"),
        "scope module must not redeclare factory-owned memo from mixed var decl:\n{ns_code}"
    );
}

#[test]
fn scope_module_imports_callable_commonjs_factory_by_atom() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var m = (q, K) => () => (K || q((K = { exports: {} }).exports, K), K.exports);
var runtime = m((exports, module) => { module.exports = function() { return 1; }; });
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns = {};
__export(ns, { read: () => read });
function read() { return runtime()(); }
var ns_b = {};
__export(ns_b, { other: () => other });
function other() { return 2; }
console.log(ns.read());
export { ns, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns.js")
        .expect("scope module should exist")
        .1;
    assert!(
        ns_code.contains("import { runtime } from \"./runtime.js\""),
        "scope module should import callable CommonJS factory wrapper:\n{ns_code}"
    );
}

#[test]
fn scope_module_imports_factory_owned_support_binding() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
function dispose(value) { return value; }
var reader;
var init_reader = y(() => {
    reader = function(value) { return dispose(value); };
});
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns = {};
__export(ns, { read: () => read });
function read(value) {
    init_reader();
    return dispose(reader(value));
}
var ns_b = {};
__export(ns_b, { other: () => other });
function other() { return 2; }
console.log(ns.read(1));
export { ns, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns.js")
        .expect("scope module should exist")
        .1;
    assert!(
        ns_code.contains("import { dispose, init_reader, reader } from \"./init_reader.js\""),
        "scope module should import support binding owned by init factory:\n{ns_code}"
    );
}

#[test]
fn scope_module_owns_local_support_function_refs() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
function cache(fn) { return fn; }
function readSlot(def) { return def.slot; }
var ns_b = {};
__export(ns_b, { b: () => b, value: () => value });
var value, b;
value = cache(() => 1);
b = readSlot({ get slot() { return value(); } });
export { ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_b_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns_b.js")
        .expect("scope module should exist")
        .1;
    assert!(
        ns_b_code.contains("function cache") && ns_b_code.contains("function readSlot"),
        "scope module should own local support functions it calls:\n{ns_b_code}"
    );
    let entry_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        !entry_code.contains("function cache") && !entry_code.contains("function readSlot"),
        "owned support functions should not remain in entry.js:\n{entry_code}"
    );
}

#[test]
fn scope_module_owns_sibling_helper_from_mixed_lazy_declaration() {
    let bundle = r#"
var wrap = (value) => ({ default: value }), y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var wrapped_exports = {};
__export(wrapped_exports, { wrapped: () => wrapped });
var wrapped = wrap("value");
export { wrapped_exports };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let wrapped_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "wrapped_exports.js")
        .expect("scope module should exist")
        .1;
    assert!(
        wrapped_code.contains("wrap =")
            && wrapped_code.contains("wrapped = wrap")
            && !wrapped_code.contains("y ="),
        "scope module should keep the sibling helper without re-emitting the lazy helper:\n{wrapped_code}"
    );
}

#[test]
fn unowned_mixed_helper_siblings_do_not_leak_to_entry() {
    let bundle = r#"
var wrap = (value) => ({ default: value }), unused = (value) => value, y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var wrapped_exports = {};
__export(wrapped_exports, { wrapped: () => wrapped });
var wrapped = wrap("value");
console.log(wrapped);
export { wrapped_exports };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let wrapped_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "wrapped_exports.js")
        .expect("scope module should exist")
        .1;
    assert!(
        wrapped_code.contains("wrap =") && wrapped_code.contains("wrapped = wrap"),
        "owned mixed-declaration sibling should still move with the scope module:\n{wrapped_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        !entry_code.contains("unused ="),
        "unowned helper siblings from mixed helper declarations should not leak into entry.js:\n{entry_code}"
    );
}

#[test]
fn exported_noop_support_binding_stays_with_scope_module() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var noop = () => {};
var ns_a = {};
__export(ns_a, { run: () => run, noop: () => noop });
function run() { return "a"; }
var ns_b = {};
__export(ns_b, { value: () => value });
noop();
var value = run();
export { ns_a, ns_b };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns_a.js")
        .expect("ns_a module should exist")
        .1;
    assert!(
        ns_a_code.contains("function noop") || ns_a_code.contains("noop ="),
        "exported no-op support binding should be available in ns_a.js:\n{ns_a_code}"
    );

    let ns_b_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns_b.js")
        .expect("ns_b module should exist")
        .1;
    assert!(
        !ns_b_code.contains("noop();") || ns_b_code.contains("import { noop"),
        "a module that still calls noop should import it instead of referencing an invisible entry binding:\n{ns_b_code}"
    );
}

#[test]
fn scope_module_imports_top_level_computed_property_refs() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var keys = {};
__export(keys, { keyFor: () => keyFor });
function keyFor(name) { return "prefix:" + name; }
var prices = {};
__export(prices, { table: () => table });
var table = { [keyFor("sonnet")]: 1 };
export { keys, prices };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let prices_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "prices.js")
        .expect("prices module should exist")
        .1;
    assert!(
        prices_code.contains("import { keyFor } from \"./keys.js\"")
            && prices_code.contains("[keyFor(\"sonnet\")]"),
        "top-level computed property references should import their owner:\n{prices_code}"
    );
}

#[test]
fn scope_module_imports_one_param_commonjs_factory() {
    let bundle = r#"
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[Object.keys(cb)[0]])((mod = { exports: {} }).exports), mod.exports;
};
var require_value = __commonJS({
    "value.js"(exports) { exports.value = "ok"; }
});
var ns_a = {};
__export(ns_a, { value: () => value });
var value = require_value().value;
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let ns_a_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "ns_a.js")
        .expect("scope module should exist")
        .1;
    assert!(
        ns_a_code.contains("import { require_value } from \"./value.js\""),
        "scope module should import one-param CommonJS factory wrapper:\n{ns_a_code}"
    );

    let value_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "value.js")
        .expect("CommonJS module should exist")
        .1;
    assert!(
        value_code.contains("export function require_value()")
            && value_code.contains("var exports = {}")
            && value_code.contains("return exports"),
        "one-param CommonJS factory should remain callable:\n{value_code}"
    );
}

#[test]
fn standalone_factory_exports_destructuring_assignment_writes() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var source = { value: 1 };
var value;
var init_value = y(() => { ({ value } = source); });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_value();
console.log(value);
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_value.js")
        .expect("init_value module should exist")
        .1;
    assert!(
        init_code.contains("export var value") || init_code.contains("value }"),
        "init_value should export destructuring assignment writes:\n{init_code}"
    );
}

/// Copied support declarations can have their own top-level dependencies. The
/// ownership pass must close over those references so copied functions don't
/// read undeclared constants at runtime.
#[test]
fn standalone_factory_closes_over_support_declaration_refs() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var FLAG = "ok";
function helper() { return FLAG; }
var value;
var init_value = y(() => { value = helper; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_value();
console.log(value());
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_value.js")
        .expect("init_value module should exist")
        .1;
    assert!(
        init_code.contains("function helper") && init_code.contains("FLAG = \"ok\""),
        "init_value should include helper and its referenced constant:\n{init_code}"
    );
}

#[test]
fn standalone_factory_adopts_inline_exported_support_declarations() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var other_dep = { count: 0 };
export var seed = 1, unrelated = other_dep.count;
export function helper() { return seed; }
export class Box { value() { return helper(); } }
var result;
var init_result = y(() => { result = new Box().value(); });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_result();
console.log(result, unrelated);
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "init_result.js")
        .expect("init_result module should exist")
        .1;
    assert!(
        init_code.contains("var seed = 1")
            && init_code.contains("function helper")
            && init_code.contains("class Box")
            && !init_code.contains("unrelated")
            && !init_code.contains("other_dep"),
        "standalone factory should adopt the inline exported dependency closure:\n{init_code}"
    );
    assert!(
        !init_code.contains("export var seed"),
        "adopted declaration should use the factory module's generated export list:\n{init_code}"
    );

    let entry_code = &raw_pairs
        .iter()
        .find(|(name, _)| name == "entry.js")
        .expect("entry module should exist")
        .1;
    assert!(
        entry_code.contains("unrelated = other_dep.count"),
        "original exported declaration should remain available to entry:\n{entry_code}"
    );
}

#[test]
fn standalone_factory_keeps_support_declaration_siblings() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var cache_a, cache_b, helper = (value) => {
    var cache = value ? cache_a ??= new WeakMap : cache_b ??= new WeakMap;
    return cache.get(value);
};
var value;
var init_value = y(() => { value = helper({}); });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_value();
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_value.js")
        .expect("init_value module should exist")
        .1;
    assert!(
        init_code.contains("cache_a") && init_code.contains("cache_b"),
        "init_value should keep sibling cache declarators closed over by helper:\n{init_code}"
    );
}

#[test]
fn standalone_factory_keeps_owned_destructuring_declarations() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var { defineProperty: defProp, getOwnPropertyNames: names } = Object;
function helper(target) { return names(target).map((name) => defProp({}, name, { value: true })); }
var value;
var init_value = y(() => { value = helper; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_value();
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_value.js")
        .expect("init_value module should exist")
        .1;
    assert!(
        init_code.contains("defineProperty") && init_code.contains("getOwnPropertyNames"),
        "init_value should keep the destructuring declaration used by helper:\n{init_code}"
    );
    assert!(
        !init_code.contains("Export '"),
        "output should not contain a dangling export diagnostic:\n{init_code}"
    );
}

#[test]
fn arrow_returning_function_without_factories_is_not_helper() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
function encode(q) { return q; }
var cache, template = (q = encode) => function(strings, ...values) { return strings[0]; }, tag;
var init_tag = y(() => { cache = Object.create(null); tag = template(encode); });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y(() => { v5 = 5; });
init_tag();
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    let init_code = &raw_pairs
        .iter()
        .find(|(n, _)| n == "init_tag.js")
        .expect("init_tag module should exist")
        .1;
    assert!(
        init_code.contains("template") && init_code.contains("strings"),
        "template helper should stay with the init module instead of being filtered as a lazy helper:\n{init_code}"
    );
}

/// Factory files in subdirectories should get correct relative import paths.
#[test]
fn factory_in_subdirectory_gets_correct_import_path() {
    let bundle = r#"
var y = (q,K) => () => (q && (K = q(q = 0)), K);
var f1 = y(() => { v1 = 1; });
var f2 = y(() => { v2 = 2; });
var f3 = y(() => { v3 = 3; });
var f4 = y(() => { v4 = 4; });
var f5 = y({"src/consumer.js"(exports, module) { var x = helperFn(1); }});
var defProp = Object.defineProperty;
var __export = (target, all) => {
    for (var name in all)
        defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { greet: () => greet });
function greet() { return "hello"; }
function helperFn(x) { return x + 1; }
export { ns_a };
"#;
    let raw_pairs = expect_unpack_raw(bundle);

    // The factory at src/consumer.js should import with ../ns_a.js, not ./ns_a.js.
    let consumer_code = &raw_pairs
        .iter()
        .find(|(n, _)| n.contains("consumer"))
        .unwrap()
        .1;
    assert!(
        consumer_code.contains("../"),
        "src/consumer.js should use ../ to reach the root-level scope module:\n{consumer_code}"
    );
    assert!(
        !consumer_code.contains("./../"),
        "should not have double-prefixed ./../ path:\n{consumer_code}"
    );
    assert!(
        consumer_code.contains("helperFn"),
        "src/consumer.js should import helperFn:\n{consumer_code}"
    );
}

#[test]
fn plain_code_not_detected_as_esbuild() {
    // No esbuild markers (no lazy-helper arrows, no __export helper).
    // The detector should reject this via the cheap pre-check without
    // cloning or resolving the AST.
    let code = r#"
function greet(name) { return "Hello, " + name + "!"; }
var result = greet("world");
console.log(result);
"#;
    let pairs = expect_unpack(code, "app.js");
    assert_eq!(
        pairs.len(),
        1,
        "plain code should not be detected as esbuild: {:?}",
        pairs.iter().map(|(n, _)| n.as_str()).collect::<Vec<_>>()
    );
}

#[test]
fn webpack_style_bundle_not_detected_as_esbuild() {
    // A webpack-shaped IIFE with __webpack_require__ — no esbuild markers.
    // The esbuild detector's pre-check should reject this immediately.
    let code = r#"
(function(modules) {
    function __webpack_require__(moduleId) {
        var module = { exports: {} };
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        return module.exports;
    }
    __webpack_require__(0);
})([
    function(module, exports, __webpack_require__) {
        var dep = __webpack_require__(1);
        console.log(dep.value);
    },
    function(module, exports) {
        exports.value = 42;
    }
]);
"#;
    let pairs = expect_unpack(code, "bundle.js");
    // Should be detected as webpack4, not esbuild.
    assert!(
        pairs.len() >= 2,
        "webpack4 bundle should be split by webpack4 detector, not esbuild"
    );
}

#[test]
fn esbuild_unpacks_iife_wrapped_browser_bundle() {
    // esbuild --format=iife (the browser default) wraps the entire bundle in a
    // zero-arg arrow IIFE: (() => { ...helpers + factories + entry... })();
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("(() => {{\n{inner}\n}})();\n");
    let pairs = expect_unpack(&bundle, "bundle.js");

    assert!(
        pairs.len() >= 6,
        "expected ≥6 modules (5 factories + entry), got {}: {:?}",
        pairs.len(),
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(
        pairs.iter().any(|(n, _)| n == "entry.js"),
        "missing entry.js"
    );
    assert!(
        pairs.iter().any(|(n, _)| n == "mod_a.js"),
        "missing mod_a.js"
    );
}

#[test]
fn esbuild_unpacks_named_global_iife_bundle() {
    // esbuild --format=iife --global-name=app (and rollup's iife output with a
    // name) assign the IIFE result: var app = (function () { ...; return X; })();
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("var app = (function () {{\n{inner}\nreturn mod_a;\n}})();\n");
    let pairs = expect_unpack(&bundle, "bundle.js");

    assert!(
        pairs.len() >= 6,
        "expected ≥6 modules (5 factories + entry), got {}: {:?}",
        pairs.len(),
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(
        pairs.iter().any(|(n, _)| n == "entry.js"),
        "missing entry.js"
    );
}

#[test]
fn esbuild_named_global_iife_preserves_returned_entry_call() {
    // esbuild 0.28.2 --bundle --format=iife --global-name=App places the
    // CommonJS entry startup in the wrapper's terminal return expression.
    let bundle = r#"
var App = (() => {
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[Object.getOwnPropertyNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var require_entry = __commonJS({
    "entry.js"(exports, module) {
      globalThis.trace = ["loaded"];
      module.exports = 42;
    }
  });
  return require_entry();
})();
"#;
    let pairs = expect_unpack_raw(bundle);

    assert!(
        pairs.len() >= 2,
        "expected entry factory plus startup: {pairs:#?}"
    );
    assert!(
        pairs
            .iter()
            .any(|(_, code)| code.contains("require_entry();")),
        "the terminal return expression must remain evaluated: {pairs:#?}"
    );
}

#[test]
fn esbuild_plain_iife_preserves_terminal_return_side_effect() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("(() => {{\n{inner}\nreturn globalThis.after = 9;\n}})();\n");
    let pairs = expect_unpack_raw(&bundle);

    assert!(
        pairs
            .iter()
            .any(|(_, code)| code.contains("globalThis.after = 9")),
        "unwrapping must retain terminal return-expression effects: {pairs:#?}"
    );
}

#[test]
fn esbuild_unpacks_bang_iife_bundle() {
    // Some minifiers emit !function(){ ... }() instead of a parenthesized IIFE.
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("!function () {{\n{inner}\n}}();\n");
    let pairs = expect_unpack(&bundle, "bundle.js");

    assert!(
        pairs.len() >= 6,
        "expected ≥6 modules (5 factories + entry), got {}: {:?}",
        pairs.len(),
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
}

#[test]
fn esbuild_iife_with_sibling_statements_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!(
        "console.log('before-wrapper');\n(() => {{\n{inner}\n}})();\nconsole.log('after-wrapper');\n"
    );
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "an IIFE with top-level siblings is not a whole-file wrapper: {:?}",
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(pairs[0].1.contains("before-wrapper"));
    assert!(pairs[0].1.contains("after-wrapper"));
}

#[test]
fn esbuild_iife_with_nested_return_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("(() => {{\nif (globalThis.skipBundle) return;\n{inner}\n}})();\n");
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "a wrapper with a function-level return must remain intact: {:?}",
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(pairs[0].1.contains("return"));
}

#[test]
fn esbuild_generator_iife_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("(function* () {{\n{inner}\n}})();\n");
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "calling a generator does not execute its bundle-looking body: {:?}",
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(pairs[0].1.contains("function*"));
}

#[test]
fn esbuild_async_iife_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!("(async function () {{\nawait 0;\n{inner}\n}})();\n");
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "an async IIFE does not share the enclosing module's execution boundary: {:?}",
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(pairs[0].1.contains("async function"));
    assert!(pairs[0].1.contains("await 0"));
}

#[test]
fn esbuild_iife_with_parameter_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle =
        format!("(function (unused = console.log('parameter-default')) {{\n{inner}\n}})();\n");
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "unwrapping a parameterized IIFE could discard parameter initialization: {:?}",
        pairs.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );
    assert!(pairs[0].1.contains("parameter-default"));
}

#[test]
fn esbuild_named_function_iife_self_binding_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle = format!(
        "(function ownWrapper() {{\n{inner}\nglobalThis.kind = typeof ownWrapper;\n}})();\n"
    );
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "a named function expression must keep its self-binding: {pairs:#?}"
    );
    assert!(pairs[0].1.contains("function ownWrapper"));
}

#[test]
fn esbuild_function_iife_arguments_binding_fails_closed() {
    let inner = make_bundle(
        "(q,K)=>()=>(K||q((K={exports:{}}).exports,K),K.exports)",
        "m",
    );
    let bundle =
        format!("(function () {{\n{inner}\nglobalThis.count = arguments.length;\n}})();\n");
    let pairs = expect_unpack_raw(&bundle);

    assert_eq!(
        pairs.len(),
        1,
        "a regular-function IIFE must keep its arguments binding: {pairs:#?}"
    );
    assert!(pairs[0].1.contains("arguments.length"));
}

const ENTRY_OWNED_BINDINGS_BUNDLE: &str = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __esm = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
var ns_lazy = {};
__export(ns_lazy, { value: () => value });
var value;
var init_lazy = __esm(() => {
  value = 42;
});
var ns_a = {};
__export(ns_a, { greet: () => greet, load: () => load });
function greet() {
  entryHelper();
  return "hi";
}
function load() {
  return Promise.resolve().then(() => (init_lazy(), ns_lazy));
}
var ns_main = {};
__export(ns_main, { main: () => main, entryHelper: () => entryHelper });
import { readFileSync } from "fs";
function entryHelper() {
  console.log("helper");
}
async function main() {
  greet();
  console.log((await load()).value);
}
main();
"#;

#[test]
fn scope_module_imports_entry_owned_declaration_and_restored_namespace() {
    // Bun keeps external `import` declarations at their module position, so
    // the last namespace header is followed by an import and its body stays
    // in the entry remainder. `greet` (in ns_a) calls that entry-owned
    // `entryHelper`, and `load` returns the restored lazy namespace object
    // `ns_lazy` through the `import()` lowering. Both need an edge from the
    // scope module to the entry.
    let raw_pairs = expect_unpack_raw(ENTRY_OWNED_BINDINGS_BUNDLE);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a.contains("import { entryHelper, ns_lazy } from \"./entry.js\";"),
        "ns_a.js should import the entry-owned bindings: {ns_a}"
    );
    let entry = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    assert!(
        entry.contains("export { entryHelper, ns_lazy };"),
        "entry.js should export the bindings scope modules import: {entry}"
    );
    assert!(
        entry.contains("function entryHelper()"),
        "entry.js should still own the declaration: {entry}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);

    let normal_pairs = expect_unpack(ENTRY_OWNED_BINDINGS_BUNDLE, "bundle.js");
    assert_eq!(validate_output_modules(&normal_pairs), vec![]);
}

#[test]
fn scope_module_imports_restored_lazy_namespace_without_entry_remainder() {
    // Same bundle without the inline import: the last namespace becomes a
    // regular scope module, so only the lazy namespace object stays in the
    // entry. With startup left to the importer, the consumer can safely
    // import it from there: no scope module invokes the exported functions.
    let bundle = ENTRY_OWNED_BINDINGS_BUNDLE
        .replace("import { readFileSync } from \"fs\";\n", "")
        .replace("\nmain();\n", "\n");
    let raw_pairs = expect_unpack_raw(&bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a.contains("import { ns_lazy } from \"./entry.js\";"),
        "ns_a.js should import the restored namespace: {ns_a}"
    );
    assert!(
        ns_a.contains("import { entryHelper } from \"./ns_main.js\";"),
        "entryHelper lives in the ns_main scope module here: {ns_a}"
    );
    let entry = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    assert!(
        entry.contains("export { ns_lazy };"),
        "entry.js should export the restored namespace: {entry}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);
    assert_eq!(
        validate_output_modules(&expect_unpack(&bundle, "bundle.js")),
        vec![]
    );
}

#[test]
fn eager_read_of_entry_owned_state_gets_no_entry_import() {
    // `shared` stays in the entry (a prelude constant no boundary claims) and
    // ns_a reads it while evaluating. An import edge would make ns_a
    // evaluate before the entry and read `shared` in its TDZ, so the edge is
    // withheld; the graph validator reports the reference instead.
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
const shared = 42;
var ns_a = {};
__export(ns_a, { value: () => value });
const value = shared;
var ns_main = {};
__export(ns_main, { run: () => run });
import { readFileSync } from "fs";
function run() { console.log(value); }
run();
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a.contains("entry.js"),
        "eager entry state must not be imported through a cycle: {ns_a}"
    );
    let entry = &raw_pairs.iter().find(|(n, _)| n == "entry.js").unwrap().1;
    assert!(
        !entry.contains("export { shared }"),
        "entry should not export state nobody can import safely: {entry}"
    );
    let findings = validate_output_modules(&raw_pairs);
    assert_eq!(
        findings
            .iter()
            .map(|f| (f.kind, f.filename.as_str(), f.message.as_str()))
            .collect::<Vec<_>>(),
        vec![(
            OutputFindingKind::UnresolvedReference,
            "ns_a.js",
            "unresolved identifier \"shared\" is declared at module scope only by entry.js, which this module does not import"
        )]
    );
}

#[test]
fn eager_call_of_entry_owned_function_keeps_the_entry_import() {
    // Hoisted function declarations are callable before the entry body runs,
    // so an eager call is safe through the cycle.
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var ns_a = {};
__export(ns_a, { value: () => value });
const value = compute();
var ns_main = {};
__export(ns_main, { run: () => run });
import { readFileSync } from "fs";
function compute() { return 42; }
function run() { console.log(value); }
run();
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a.contains("import { compute } from \"./entry.js\";"),
        "hoisted entry function should be imported: {ns_a}"
    );
    assert_eq!(validate_output_modules(&raw_pairs), vec![]);
}

#[test]
fn written_entry_owned_state_gets_no_entry_import() {
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var counter = 0;
var ns_a = {};
__export(ns_a, { bump: () => bump });
function bump() { counter += 1; return counter; }
var ns_main = {};
__export(ns_main, { run: () => run });
import { readFileSync } from "fs";
function run() { console.log(bump()); }
run();
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a.contains("import { counter }"),
        "a written binding cannot be imported: {ns_a}"
    );
}

/// Bundle where `shared` (entry state) and `compute` (entry function reading
/// it) stay in the entry and ns_a reads through `READ`.
fn entry_state_bundle(read: &str) -> String {
    format!(
        r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {{
  for (var name in all)
    __defProp(target, name, {{ get: all[name], enumerable: true }});
}};
const shared = 42;
var ns_a = {{}};
__export(ns_a, {{ value: () => value }});
const value = {read};
var ns_main = {{}};
__export(ns_main, {{ run: () => run }});
import {{ readFileSync }} from "fs";
function compute() {{ return shared; }}
function pure() {{ return 42; }}
function run() {{ console.log(value); }}
run();
"#
    )
}

fn ns_a_entry_imports(read: &str) -> Vec<String> {
    let raw_pairs = expect_unpack_raw(&entry_state_bundle(read));
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    ns_a.lines()
        .filter(|line| line.contains("./entry.js"))
        .map(str::to_string)
        .collect()
}

#[test]
fn immediately_invoked_bodies_count_as_eager_entry_reads() {
    for read in [
        "(() => shared)()",
        "(function () { return shared; })()",
        "(function () { return shared; }).call(null)",
        "new (function () { this.v = shared; })().v",
    ] {
        assert_eq!(ns_a_entry_imports(read), Vec::<String>::new(), "{read}");
    }
}

#[test]
fn computed_keys_count_as_eager_entry_reads() {
    for read in [
        "class { [shared]() {} }",
        "({ get [shared]() { return 1; } })",
        "({ [shared]() {} })",
        "class { [shared] = 1; }",
    ] {
        assert_eq!(ns_a_entry_imports(read), Vec::<String>::new(), "{read}");
    }
    // The member bodies themselves are still deferred.
    assert_eq!(
        ns_a_entry_imports("class { m() { return shared; } }"),
        vec!["import { shared } from \"./entry.js\";".to_string()]
    );
}

#[test]
fn eagerly_called_entry_function_needs_self_contained_references() {
    // `compute` reads entry state that has not been initialized when ns_a
    // evaluates; `pure` references nothing outside itself.
    assert_eq!(ns_a_entry_imports("compute()"), Vec::<String>::new());
    assert_eq!(
        ns_a_entry_imports("pure()"),
        vec!["import { pure } from \"./entry.js\";".to_string()]
    );
    // Deferred calls to either are fine.
    assert_eq!(
        ns_a_entry_imports("() => compute() + pure()"),
        vec!["import { compute, pure } from \"./entry.js\";".to_string()]
    );
}

#[test]
fn deferred_reference_needs_a_guard_that_nothing_evaluates_early() {
    // A local function called while the module evaluates runs its body
    // early; a getter read on the spot does too. Neither read of `shared` is
    // provably deferred, so no entry edge is added.
    let bundle = entry_state_bundle("read()").replace(
        "const value = read();",
        "function read() { return shared; }\nconst value = read();",
    );
    let raw_pairs = expect_unpack_raw(&bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(!ns_a.contains("entry.js"), "{ns_a}");
    assert_eq!(
        ns_a_entry_imports("({ get v() { return shared; } }).v"),
        Vec::<String>::new()
    );
    // An unguarded deferred reference (object-literal method at top level)
    // has unknown timing and is treated the same way.
    assert_eq!(
        ns_a_entry_imports("{ m() { return shared; } }"),
        Vec::<String>::new()
    );
    // The same body behind a top-level function nobody evaluates early is
    // provably deferred.
    let bundle = entry_state_bundle("null").replace(
        "const value = null;",
        "function read() { return shared; }\nconst value = read;",
    );
    let raw_pairs = expect_unpack_raw(&bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a.contains("entry.js"),
        "aliasing the guard eagerly (`const value = read`) is an eager reference: {ns_a}"
    );
    let bundle = entry_state_bundle("null").replace(
        "const value = null;",
        "export function read() { return shared; }\nconst value = 1;",
    );
    let raw_pairs = expect_unpack_raw(&bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        ns_a.contains("import { shared } from \"./entry.js\";"),
        "{ns_a}"
    );
}

#[test]
fn guard_evaluated_early_by_another_scope_module_blocks_the_edge() {
    // ns_a's `read` is deferred inside ns_a, but ns_b calls it while ns_b
    // evaluates, before the entry initializes `shared`.
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
const shared = 42;
var ns_a = {};
__export(ns_a, { read: () => read });
function read() { return shared; }
var ns_b = {};
__export(ns_b, { early: () => early });
const early = read();
var ns_main = {};
__export(ns_main, { run: () => run });
import { readFileSync } from "fs";
function run() { console.log(early); }
run();
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(!ns_a.contains("entry.js"), "{ns_a}");
}

#[test]
fn namespace_object_read_early_blocks_the_edge() {
    // ns_b reads ns_a's namespace object while evaluating; its getters could
    // hand out `read` and run it before the entry initializes `shared`.
    let bundle = r#"
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
const shared = 42;
var ns_a = {};
__export(ns_a, { read: () => read });
function read() { return shared; }
var ns_b = {};
__export(ns_b, { early: () => early });
const early = ns_a.read();
var ns_main = {};
__export(ns_main, { run: () => run });
import { readFileSync } from "fs";
function run() { console.log(early); }
run();
"#;
    let raw_pairs = expect_unpack_raw(bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(!ns_a.contains("entry.js"), "{ns_a}");
}

#[test]
fn entry_state_stays_unlinked_through_transitive_guard_calls() {
    for body in [
        "function read() { return shared; }\nfunction start() { return read(); }\nconst value = start();",
        "function read() { return shared; }\nfunction middle() { return read(); }\nfunction start() { return middle(); }\nconst value = start();",
        "function read() { return shared; }\nfunction start() { return read(); }\nconst value = ({ get v() { return start(); } }).v;",
    ] {
        let bundle = entry_state_bundle("null").replace("const value = null;", body);
        let raw_pairs = expect_unpack_raw(&bundle);
        let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
        assert!(!ns_a.contains("entry.js"), "{body}\n{ns_a}");
    }
}

#[test]
fn recursive_guards_need_an_early_root_to_block_entry_linkage() {
    for (initializer, expected_import) in [("first(1)", false), ("0", true)] {
        let body = format!(
            "function first(n) {{ return n ? second(n - 1) : 0; }}\n\
             function second(n) {{ return n ? first(n - 1) : shared; }}\nconst value = {initializer};"
        );
        let bundle = entry_state_bundle("null").replace("const value = null;", &body);
        let raw_pairs = expect_unpack_raw(&bundle);
        let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
        assert_eq!(
            ns_a.contains("import { shared } from \"./entry.js\";"),
            expected_import,
            "{body}\n{ns_a}"
        );
    }
}

#[test]
fn namespace_exposure_propagates_through_guard_calls() {
    let bundle = entry_state_bundle("null")
        .replace(
            "__export(ns_a, { value: () => value });",
            "__export(ns_a, { value: () => value, read: () => read });",
        )
        .replace(
            "const value = null;",
            "function read() { return shared; }\nfunction start() { return ns_a.read(); }\nconst value = start();",
        );
    let raw_pairs = expect_unpack_raw(&bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(
        !ns_a.contains("import { shared }"),
        "a transitively exposed namespace must expose its guards too: {ns_a}"
    );
}

#[test]
fn early_guard_with_nested_callback_keeps_unproven_namespace_unlinked() {
    // main now executes in a scope module, reaching load before entry runs.
    // The Promise callback happens later at runtime, but guard reachability
    // deliberately does not infer callback scheduling. Keep the unresolved
    // reference instead of treating a nested callback as a deferral proof.
    let bundle = ENTRY_OWNED_BINDINGS_BUNDLE.replace("import { readFileSync } from \"fs\";\n", "");
    let raw_pairs = expect_unpack_raw(&bundle);
    let ns_a = &raw_pairs.iter().find(|(n, _)| n == "ns_a.js").unwrap().1;
    assert!(!ns_a.contains("import { ns_lazy }"), "{ns_a}");
    let findings = validate_output_modules(&raw_pairs);
    assert!(findings.iter().any(|finding| {
        finding.kind == OutputFindingKind::UnresolvedReference
            && finding.filename == "ns_a.js"
            && finding.message.contains("ns_lazy")
    }));
}
